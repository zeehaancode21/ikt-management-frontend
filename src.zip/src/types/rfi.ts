// export type RfiDiscipline =
//   | "PLUMBING"
//   | "ELECTRICAL"
//   | "CIVIL"
//   | "STRUCTURAL"
//   | "ARCHITECTURAL";

// export type RfiTeamType = "INTERNAL" | "EXTERNAL";

// // Matches backend RfiStatus.java. DRAFT..CANCELLED are the full steel-detailing
// // lifecycle; SENT is kept for backward compatibility with older records.
// // NOTE: RESUBMITTED is a new value required for the "Resubmitted" status
// // action — the backend enum (RfiStatus.java) and any DB check-constraint /
// // column definition mirroring it must be updated to include "RESUBMITTED"
// // before this reaches the API. See rfiApi.ts `resubmitRfi` for the endpoint
// // contract this depends on.
// export type RfiStatus =
//   | "DRAFT"
//   | "SUBMITTED"
//   | "ISSUED"
//   | "AWAITING_RESPONSE"
//   | "RESPONSE_RECEIVED"
//   | "UNDER_REVIEW"
//   | "OUTSTANDING"
//   | "CLOSED"
//   | "REOPENED"
//   | "CANCELLED"
//   | "RESUBMITTED"
//   | "SENT";

// export const RFI_STATUSES: RfiStatus[] = [
//   "DRAFT",
//   "SUBMITTED",
//   "ISSUED",
//   "AWAITING_RESPONSE",
//   "RESPONSE_RECEIVED",
//   "UNDER_REVIEW",
//   "OUTSTANDING",
//   "CLOSED",
//   "REOPENED",
//   "CANCELLED",
//   "RESUBMITTED",
// ];

// export interface RfiAttachment {
//   id: number;
//   filename: string;
//   originalName: string;
//   fileType: string;
//   fileSize: number;
//   uploadedBy: string;
//   uploadedAt: string;
//   senderEmail?: string;
//   senderName?: string;
// }

// // Matches backend RfiTimelineEventDto.java. `type` is one of:
// // RFI_CREATED | EMAIL_SENT | REPLY_RECEIVED | STATUS_CHANGED
// export interface RfiTimelineEvent {
//   type: string;
//   timestamp: string;
//   sender?: string | null;
//   recipient?: string | null;
//   subject?: string | null;
//   message?: string | null;
//   attachments: RfiAttachment[];
//   gmailMessageId?: string | null;
//   gmailThreadId?: string | null;
//   fromStatus?: RfiStatus | null;
//   toStatus?: RfiStatus | null;
//   performedBy?: string | null;
// }

// // Matches backend RfiSyncResultDto.java.
// export interface RfiSyncResult {
//   rfiId: number;
//   rfiNumber: string;
//   success: boolean;
//   newMessagesCount: number;
//   errorMessage?: string | null;
//   updatedRfi?: Rfi;
// }

// export interface Rfi {
//   id: number;
//   projectName: string;
//   rfiNumber: string;
//   discipline: RfiDiscipline;
//   teamType: RfiTeamType;
//   subject: string;
//   generatedEmailSubject: string;
//   emailBody: string;
//   recipientEmail: string;
//   attachment: RfiAttachment;
//   status: RfiStatus;
//   sentBy?: string;
//   createdAt: string;
//   // Reflects Rfi.senderEmail / Rfi.senderName on the backend entity — the
//   // sender actually used as Reply-To, plus the cosmetic display label.
//   senderEmail?: string;
//   senderName?: string;
//   // Gmail thread ID captured at send time; used to fetch/match replies.
//   gmailThreadId?: string | null;
//   // Set/updated by RfiGmailSyncService when a new reply is imported.
//   responseReceivedAt?: string | null;
//   // Optional free-text notes a user can add when reviewing a response.
//   responseNotes?: string | null;
// }

// export const RFI_DISCIPLINES: RfiDiscipline[] = [
//   "PLUMBING",
//   "ELECTRICAL",
//   "CIVIL",
//   "STRUCTURAL",
//   "ARCHITECTURAL",
// ];

// export const RFI_TEAM_TYPES: RfiTeamType[] = ["INTERNAL", "EXTERNAL"];

// // ── RFI Email Contacts (Settings) ─────────────────────────────────────────
// // Matches backend RfiEmailAddressType.java / RfiEmailContact.java (the
// // TABLE-BACKED contact book at /api/rfi-email-contacts, wired into
// // RfiServiceImpl#createAndSendRfi). Backs the "RFI Settings" panel: every
// // "Send To" (TO) and "CC" address ever used on an RFI is recorded
// // automatically, and the user can star any of them as a favorite — only
// // favorited addresses show up in that type's picker on the "Create RFI"
// // form.
// //
// // NOTE: RfiSettingsController also exposes a parallel set of contact
// // endpoints under /api/rfi-settings/contacts/{type}, backed by a JSON blob
// // on RfiSettings rather than this table. RfiServiceImpl's create/send flow
// // only ever reads and writes THIS table (RfiEmailContactRepository), so the
// // /api/rfi-settings/contacts endpoints are currently disconnected from
// // actual RFI sends — don't switch the frontend to them without wiring the
// // backend send path to match, or "favorited" addresses will silently stop
// // tracking what's actually been used.
// export type RfiEmailAddressType = "TO" | "CC";

// export interface RfiEmailContact {
//   id: number;
//   type: RfiEmailAddressType;
//   email: string;
//   favorite: boolean;
//   createdAt: string;
//   lastUsedAt?: string | null;
// }

// // ── RFI Gmail Settings ─────────────────────────────────────────────────
// // The Gmail account RFIs are actually SENT FROM (backend uses the Gmail
// // API with a stored OAuth refresh token). Separate from RfiEmailContact
// // above (the "Send To / CC" address book) and separate from the
// // per-employee senderEmail used as the cosmetic Reply-To on an RFI.
// //
// // Matches backend RfiSettingsDto.java, served from the MERGED
// // RfiSettingsController at GET/POST /api/rfi-settings (see rfiApi.ts).
// // That DTO also carries toContacts/ccContacts, but those mirror the
// // separate, currently-unused contact-blob endpoints described above —
// // this type omits them since nothing here should read from that blob.
// export interface RfiGmailSettings {
//   id?: number;
//   gmailEmail: string;
//   // The user's own Google OAuth Client ID (from their Google Cloud
//   // Console project). Not secret, so the backend does send it back and
//   // it's safe to redisplay/edit here.
//   gmailClientId?: string;
//   // NOTE ON A REAL BACKEND BUG: RfiSettingsService.mapToDto() currently
//   // still includes gmailClientSecret and gmailRefreshToken (AES-encrypted,
//   // but present) in every GET/POST response, despite a code comment
//   // claiming the controller scrubs them — it doesn't. Both are typed here
//   // for completeness of the wire shape, but the frontend should never read
//   // or redisplay them; treat this API as write-only for those two fields
//   // until the backend is fixed to omit them from responses.
//   gmailClientSecret?: string;
//   gmailRefreshToken?: string;
//   // Whether the stored refresh token is currently known to be valid.
//   // Undefined/true = assume connected; explicit false = show "needs
//   // attention" (e.g. after a failed "Check token" call).
//   tokenValid?: boolean;
//   tokenExpiryDate?: string;
// }
export type RfiDiscipline =
  | "PLUMBING"
  | "ELECTRICAL"
  | "CIVIL"
  | "STRUCTURAL"
  | "ARCHITECTURAL";

export type RfiTeamType = "INTERNAL" | "EXTERNAL";

// Matches backend RfiStatus.java. DRAFT..CANCELLED are the full steel-detailing
// lifecycle; SENT is kept for backward compatibility with older records.
// NOTE: RESUBMITTED is a new value required for the "Resubmitted" status
// action — the backend enum (RfiStatus.java) and any DB check-constraint /
// column definition mirroring it must be updated to include "RESUBMITTED"
// before this reaches the API. See rfiApi.ts `resubmitRfi` for the endpoint
// contract this depends on.
export type RfiStatus =
  | "DRAFT"
  | "SUBMITTED"
  | "ISSUED"
  | "AWAITING_RESPONSE"
  | "RESPONSE_RECEIVED"
  | "UNDER_REVIEW"
  | "OUTSTANDING"
  | "CLOSED"
  | "REOPENED"
  | "CANCELLED"
  | "RESUBMITTED"
  | "SENT";

export const RFI_STATUSES: RfiStatus[] = [
  "DRAFT",
  "SUBMITTED",
  "ISSUED",
  "AWAITING_RESPONSE",
  "RESPONSE_RECEIVED",
  "UNDER_REVIEW",
  "OUTSTANDING",
  "CLOSED",
  "REOPENED",
  "CANCELLED",
  "RESUBMITTED",
];

export interface RfiAttachment {
  id: number;
  filename: string;
  originalName: string;
  fileType: string;
  fileSize: number;
  uploadedBy: string;
  uploadedAt: string;
  senderEmail?: string;
  senderName?: string;
}

// Matches backend RfiTimelineEventDto.java. `type` is one of:
// RFI_CREATED | EMAIL_SENT | REPLY_RECEIVED | STATUS_CHANGED
export interface RfiTimelineEvent {
  type: string;
  timestamp: string;
  sender?: string | null;
  recipient?: string | null;
  subject?: string | null;
  message?: string | null;
  attachments: RfiAttachment[];
  gmailMessageId?: string | null;
  gmailThreadId?: string | null;
  fromStatus?: RfiStatus | null;
  toStatus?: RfiStatus | null;
  performedBy?: string | null;
}

// Matches backend RfiSyncResultDto.java.
export interface RfiSyncResult {
  rfiId: number;
  rfiNumber: string;
  success: boolean;
  newMessagesCount: number;
  errorMessage?: string | null;
  updatedRfi?: Rfi;
}

export interface Rfi {
  id: number;
  projectName: string;
  rfiNumber: string;
  discipline: RfiDiscipline;
  teamType: RfiTeamType;
  subject: string;
  generatedEmailSubject: string;
  emailBody: string;
  recipientEmail: string;
  // Comma-separated CC list captured when the RFI was sent.
  ccEmails?: string | null;
  attachment: RfiAttachment;
  status: RfiStatus;
  // Where the logged-in user stands on THIS RFI (filled in by the backend):
  // TO / CC = may change status, reply, resubmit. VIEWER = read-only.
  participantRole?: "TO" | "CC" | "VIEWER";
  canModify?: boolean;
  sentBy?: string;
  createdAt: string;
  // Reflects Rfi.senderEmail / Rfi.senderName on the backend entity — the
  // sender actually used as Reply-To, plus the cosmetic display label.
  senderEmail?: string;
  senderName?: string;
  // Gmail thread ID captured at send time; used to fetch/match replies.
  gmailThreadId?: string | null;
  // Set/updated by RfiGmailSyncService when a new reply is imported.
  responseReceivedAt?: string | null;
  // Optional free-text notes a user can add when reviewing a response.
  responseNotes?: string | null;
}

export const RFI_DISCIPLINES: RfiDiscipline[] = [
  "PLUMBING",
  "ELECTRICAL",
  "CIVIL",
  "STRUCTURAL",
  "ARCHITECTURAL",
];

export const RFI_TEAM_TYPES: RfiTeamType[] = ["INTERNAL", "EXTERNAL"];

// ── RFI Email Contacts (Settings) ─────────────────────────────────────────
// Matches backend EmailContactDto.java, served from the merged
// RfiSettingsController at /api/rfi-settings/contacts/{type}. TO/CC
// addresses now live as JSON in rfi_settings.email_to_contacts /
// email_cc_contacts (RfiSettings#addOrUpdateToContact etc.) rather than a
// separate table — RfiServiceImpl#createAndSendRfi records usage onto the
// SAME row via RfiSettingsService#recordContactUsage, so this is the one
// and only contact store now (the old RfiEmailContact table/entity/
// controller/service have been removed).
//
// NOTE: because contacts live on the rfi_settings row itself, every
// endpoint under /api/rfi-settings/contacts/{type} requires that row to
// already exist — i.e. the user must have saved Gmail settings at least
// once (POST /api/rfi-settings) before contacts can be listed or added.
// Surface that as a "connect Gmail first" state in the Settings UI rather
// than a raw error toast.
//
// NOTE ON SHAPE: EmailContactDto has no `id` or `createdAt` — there's no
// separate row per contact anymore, just an entry in a JSON array. `email`
// (scoped by `type`) is the effective identity for edits/deletes.
export type RfiEmailAddressType = "TO" | "CC";

export interface RfiEmailContact {
  type: RfiEmailAddressType;
  email: string;
  favorite: boolean;
  lastUsedAt?: string | null;
}

// ── RFI Gmail Settings ─────────────────────────────────────────────────
// The Gmail account RFIs are actually SENT FROM (backend uses the Gmail
// API with a stored OAuth refresh token). Separate from RfiEmailContact
// above (the "Send To / CC" address book) and separate from the
// per-employee senderEmail used as the cosmetic Reply-To on an RFI.
//
// Matches backend RfiSettingsDto.java, served from the MERGED
// RfiSettingsController at GET/POST /api/rfi-settings (see rfiApi.ts).
// That DTO also carries toContacts/ccContacts, but those mirror the
// separate, currently-unused contact-blob endpoints described above —
// this type omits them since nothing here should read from that blob.
export interface RfiGmailSettings {
  id?: number;
  gmailEmail: string;
  // The user's own Google OAuth Client ID (from their Google Cloud
  // Console project). Not secret, so the backend does send it back and
  // it's safe to redisplay/edit here.
  gmailClientId?: string;
  // NOTE ON A REAL BACKEND BUG: RfiSettingsService.mapToDto() currently
  // still includes gmailClientSecret and gmailRefreshToken (AES-encrypted,
  // but present) in every GET/POST response, despite a code comment
  // claiming the controller scrubs them — it doesn't. Both are typed here
  // for completeness of the wire shape, but the frontend should never read
  // or redisplay them; treat this API as write-only for those two fields
  // until the backend is fixed to omit them from responses.
  gmailClientSecret?: string;
  gmailRefreshToken?: string;
  // Whether the stored refresh token is currently known to be valid.
  // Undefined/true = assume connected; explicit false = show "needs
  // attention" (e.g. after a failed "Check token" call).
  tokenValid?: boolean;
  tokenExpiryDate?: string;
}