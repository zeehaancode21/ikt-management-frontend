import { useEffect, useState, useCallback, useRef, useMemo, useId } from "react";
import api, { getErrorMessage } from "@/lib/api";
import { groupByYear } from "@/lib/yearGrouping";
import { PageHeader } from "@/components/PageHeader";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectSeparator,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Boxes,
  CheckCircle2,
  PencilRuler,
  Zap,
  Link2,
  Puzzle,
  Clock,
  Filter,
  RotateCcw,
  Star,
  Plus,
  Search,
  Calendar,
  X,
} from "lucide-react";
import "./WorkHoursDashboard.css";

/* ─── Types ─────────────────────────────────────────────── */

interface WorkHoursSummary {
  client: string | null;
  project: string | null;
  hoursByType: Record<string, number>;
  modelingHours: number;
  checkingHours: number;
  drawingGroupHours: number; // E_PLAN + SHOP_DRAWING + LINKING + PART_DRAWING
  totalHours: number;
}

interface ApiListResponse {
  success: boolean;
  data: string[];
  error?: string;
}

/** A single (year, client) pairing returned by the grouped-by-year clients endpoint. */
interface ClientYearOption {
  year: string;
  clientName: string;
}

/** A single (year, project) pairing returned by the grouped-by-year projects endpoint. */
interface ProjectYearOption {
  year: string;
  projectName: string;
}

/**
 * One year's worth of clients/projects, ready to render as a labeled
 * section in a dropdown. Same shape used by the Work Report page's
 * Projects dropdown (see `@/pages/WorkReport`), reused here for both the
 * Client and Project dropdowns so the two pages stay consistent.
 */
type YearGroupedList = { year: string; names: string[] };

/** Groups a flat list of (year, client) pairs — see `groupByYear` in `@/lib/yearGrouping`. */
const groupClientsByYear = (options: ClientYearOption[]): YearGroupedList[] =>
  groupByYear(options.map(({ year, clientName }) => ({ year, name: clientName }))).map(
    ({ year, items }) => ({ year, names: items })
  );

/** Groups a flat list of (year, project) pairs — see `groupByYear` in `@/lib/yearGrouping`. */
const groupProjectsByYear = (options: ProjectYearOption[]): YearGroupedList[] =>
  groupByYear(options.map(({ year, projectName }) => ({ year, name: projectName }))).map(
    ({ year, items }) => ({ year, names: items })
  );

const ALL_VALUE = "__ALL__";

/* ─── Category accents ──────────────────────────────────────
   Reuses the exact hues already used for work-type badges on the
   Work Report page, so the two screens read as one system.        ── */

const ACCENT = {
  modeling: { hex: "#9333ea", bg: "bg-purple-100 dark:bg-purple-500/15", fg: "text-purple-700 dark:text-purple-300" },
  checking: { hex: "#0891b2", bg: "bg-cyan-100 dark:bg-cyan-500/15", fg: "text-cyan-700 dark:text-cyan-300" },
  drawing: { hex: "#2563eb", bg: "bg-blue-100 dark:bg-blue-500/15", fg: "text-blue-700 dark:text-blue-300" },
  total: { hex: "#059669", bg: "bg-emerald-100 dark:bg-emerald-500/15", fg: "text-emerald-700 dark:text-emerald-300" },
  ePlan: { hex: "#2563eb", bg: "bg-blue-100 dark:bg-blue-500/15", fg: "text-blue-700 dark:text-blue-300" },
  shopDrawing: { hex: "#7c3aed", bg: "bg-violet-100 dark:bg-violet-500/15", fg: "text-violet-700 dark:text-violet-300" },
  linking: { hex: "#059669", bg: "bg-emerald-100 dark:bg-emerald-500/15", fg: "text-emerald-700 dark:text-emerald-300" },
  partDrawing: { hex: "#d97706", bg: "bg-amber-100 dark:bg-amber-500/15", fg: "text-amber-700 dark:text-amber-300" },
};

const DRAWING_COMPONENTS: { key: string; label: string; icon: typeof Zap; accent: typeof ACCENT.ePlan }[] = [
  { key: "E_PLAN", label: "E Plan", icon: Zap, accent: ACCENT.ePlan },
  { key: "SHOP_DRAWING", label: "Shop Drawing", icon: PencilRuler, accent: ACCENT.shopDrawing },
  { key: "LINKING", label: "Linking", icon: Link2, accent: ACCENT.linking },
  { key: "PART_DRAWING", label: "Part Drawing", icon: Puzzle, accent: ACCENT.partDrawing },
];

const fmtHours = (n: number) => n.toFixed(2);

/* ─── Favorite-client accent hashing ─────────────────────────
   Picks one of the ACCENT hues deterministically per client name,
   so each favorite chip gets a stable, distinguishable color that
   still belongs to the same palette used for work-type badges.   ── */

const ACCENT_KEYS = Object.keys(ACCENT) as (keyof typeof ACCENT)[];

function hashString(str: string): number {
  let h = 0;
  for (let i = 0; i < str.length; i++) {
    h = (h << 5) - h + str.charCodeAt(i);
    h |= 0;
  }
  return Math.abs(h);
}

function accentForClient(name: string) {
  return ACCENT[ACCENT_KEYS[hashString(name) % ACCENT_KEYS.length]];
}

/* ─── Favorite clients API ─────────────────────────────────────
   Small persistence layer for the "pin this client to my Hours
   dashboard" feature. Mirrors the ApiResponse<T> contract already
   used elsewhere in this app (success / data / error).            ── */

const favoritesApi = {
  async list(): Promise<string[]> {
    const { data } = await api.get<ApiListResponse>("/favorite-clients");
    return data?.success && Array.isArray(data.data) ? data.data : [];
  },
  async add(client: string): Promise<string[]> {
    const { data } = await api.post<ApiListResponse>("/favorite-clients", { client });
    if (!data?.success) throw new Error(data?.error || "Failed to add favorite client");
    return data.data;
  },
  async remove(client: string): Promise<string[]> {
    const { data } = await api.delete<ApiListResponse>(
      `/favorite-clients/${encodeURIComponent(client)}`
    );
    if (!data?.success) throw new Error(data?.error || "Failed to remove favorite client");
    return data.data;
  },
};

/* ─── Count-up hook ─────────────────────────────────────────
   Animates a number from its previous value up to the new target
   whenever the target changes (e.g. filters change, data reloads). */

const useCountUp = (target: number, durationMs = 800) => {
  const [display, setDisplay] = useState(0);
  const fromRef = useRef(0);
  const rafRef = useRef<number>();

  useEffect(() => {
    const prefersReduced =
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

    if (prefersReduced) {
      setDisplay(target);
      return;
    }

    const from = fromRef.current;
    const start = performance.now();

    const tick = (now: number) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / durationMs, 1);
      // easeOutCubic
      const eased = 1 - Math.pow(1 - progress, 3);
      const value = from + (target - from) * eased;
      setDisplay(value);

      if (progress < 1) {
        rafRef.current = requestAnimationFrame(tick);
      } else {
        fromRef.current = target;
      }
    };

    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target]);

  return display;
};

/* ─── Stat card ─────────────────────────────────────────────── */

const StatCard = ({
  label,
  value,
  icon: Icon,
  accent,
  percent,
  index,
  emphasis,
  tooltip,
}: {
  label: string;
  value: number;
  icon: typeof Clock;
  accent: { hex: string; bg: string; fg: string };
  percent: number;
  index: number;
  emphasis?: boolean;
  tooltip?: string;
}) => {
  const animated = useCountUp(value);
  const [barWidth, setBarWidth] = useState(0);
  const [showTooltip, setShowTooltip] = useState(false);
  const tooltipId = useId();

  useEffect(() => {
    // Defer to next tick so the CSS transition actually animates the width.
    const id = window.setTimeout(() => setBarWidth(Math.max(percent, value > 0 ? 3 : 0)), 60);
    return () => window.clearTimeout(id);
  }, [percent, value]);

  // The visual body below animates and re-renders every frame while the
  // count-up plays, which would make a screen reader re-announce garbage
  // mid-animation. Instead we hide that body from assistive tech and give
  // the card itself a single, stable accessible name with the resting value.
  const accessibleSummary = `${label}: ${fmtHours(value)} hours, ${percent.toFixed(0)} percent${
    tooltip ? `. ${tooltip}` : ""
  }`;

  return (
    <div className="whd-card-outer" style={{ ["--whd-delay" as string]: `${index * 70}ms` }}>
      {tooltip && showTooltip && (
        <div id={tooltipId} role="tooltip" className="whd-tooltip whd-mono">
          {tooltip}
          <span className="whd-tooltip-arrow" aria-hidden="true" />
        </div>
      )}

      <div
        className={`whd-card rounded-xl border border-border bg-card p-5 shadow-sm ${
          emphasis ? "ring-1 ring-primary/30 whd-card-emphasis" : ""
        }`}
        style={{ ["--whd-accent" as string]: accent.hex }}
        role="group"
        aria-label={accessibleSummary}
        aria-describedby={tooltip && showTooltip ? tooltipId : undefined}
        tabIndex={tooltip ? 0 : undefined}
        onMouseEnter={() => tooltip && setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
        onFocus={() => tooltip && setShowTooltip(true)}
        onBlur={() => setShowTooltip(false)}
      >
        <span className="whd-corner tl" aria-hidden="true" />
        <span className="whd-corner tr" aria-hidden="true" />
        <span className="whd-corner bl" aria-hidden="true" />
        <span className="whd-corner br" aria-hidden="true" />

        <div className="whd-card-body" aria-hidden="true">
          <div className="flex items-center justify-between">
            <span className="whd-label text-sm text-muted-foreground">{label}</span>
            <span className={`whd-icon-chip flex h-9 w-9 items-center justify-center rounded-full ${accent.bg} ${accent.fg}`}>
              <Icon className="h-[18px] w-[18px]" />
            </span>
          </div>

          <div className="mt-3 flex items-baseline gap-1.5">
            <span className="whd-mono whd-figure text-2xl font-semibold tracking-tight">{fmtHours(animated)}</span>
            <span className="whd-mono text-[11px] text-muted-foreground">hrs</span>
          </div>

          <div className="mt-3 flex items-center gap-2">
            <div className="whd-bar-track flex-1">
              <div className="whd-bar-fill" style={{ width: `${barWidth}%` }} />
            </div>
            <span className="whd-mono whd-share-label text-[11px] text-muted-foreground w-8 text-right">
              {percent.toFixed(0)}%
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

/* ─── Skeleton loader ───────────────────────────────────────── */

const SkeletonCard = ({ index }: { index: number }) => (
  <div className="whd-card-outer" style={{ ["--whd-delay" as string]: `${index * 60}ms` }}>
    <div className="whd-skeleton whd-card rounded-xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="whd-skel-bar h-3.5 w-20" />
        <div className="whd-skel-bar h-9 w-9 rounded-full" />
      </div>
      <div className="whd-skel-bar mt-4 h-6 w-24" />
      <div className="whd-skel-bar mt-4 h-1.5 w-full" />
    </div>
  </div>
);

/* ─── Title block ─────────────────────────────────────────────
   A live "drawing" title block: instead of decorative text, its four
   cells are literally the current query state (client / project /
   scale / rev date), so the blueprint conceit is doing real work. */

const TitleBlock = ({
  client,
  project,
}: {
  client: string;
  project: string;
}) => {
  const revDate = new Date().toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "2-digit",
  });

  return (
    <div className="whd-title-block whd-mono">
      <div className="whd-title-cell">
        <span className="whd-title-cell-key">Client</span>
        <span className="whd-title-cell-value">{client}</span>
      </div>
      <div className="whd-title-cell">
        <span className="whd-title-cell-key">Project</span>
        <span className="whd-title-cell-value">{project}</span>
      </div>
      <div className="whd-title-cell">
        <span className="whd-title-cell-key">Scale</span>
        <span className="whd-title-cell-value">NOT TO SCALE</span>
      </div>
      <div className="whd-title-cell">
        <span className="whd-title-cell-key">Rev</span>
        <span className="whd-title-cell-value">{revDate}</span>
      </div>
    </div>
  );
};

/* ─── Favorite client chip ─────────────────────────────────────
   Small clickable, drafting-accented chip. Hovering reveals a
   quick "×" to unfavorite without opening the manage popup.       ── */

const FavoriteChip = ({
  client,
  active,
  busy,
  onSelect,
  onRemove,
}: {
  client: string;
  active: boolean;
  busy: boolean;
  onSelect: () => void;
  onRemove: () => void;
}) => {
  const accent = accentForClient(client);
  return (
    <div className="whd-fav-chip-wrap">
      <button
        type="button"
        className={`whd-fav-chip ${active ? "whd-fav-chip--active" : ""}`}
        style={{ ["--whd-fav-accent" as string]: accent.hex }}
        onClick={onSelect}
        aria-pressed={active}
        title={client}
      >
        <Star className="whd-fav-chip-star h-3 w-3" fill="currentColor" aria-hidden="true" />
        <span className="whd-fav-chip-label">{client}</span>
      </button>
      <button
        type="button"
        className="whd-fav-chip-remove"
        title={`Remove ${client} from favorites`}
        aria-label={`Remove ${client} from favorites`}
        onClick={(e) => {
          e.stopPropagation();
          onRemove();
        }}
        disabled={busy}
      >
        {busy ? <span className="whd-fav-spinner whd-fav-spinner--sm" aria-hidden="true" /> : <X className="h-3 w-3" aria-hidden="true" />}
      </button>
    </div>
  );
};

/* ─── Main page ─────────────────────────────────────────────── */

const WorkHoursDashboard = () => {
  // Clients, grouped by year (newest first, alphabetical within a year) —
  // the same shape/behavior as the Work Report "Projects" dropdown.
  const [clientGroups, setClientGroups] = useState<YearGroupedList[]>([]);
  const [projectsCache, setProjectsCache] = useState<Record<string, YearGroupedList[]>>({});

  const [selectedClient, setSelectedClient] = useState<string>(ALL_VALUE);
  const [selectedProject, setSelectedProject] = useState<string>(ALL_VALUE);

  const [loadingClients, setLoadingClients] = useState(true);
  const [loadingProjects, setLoadingProjects] = useState(false);

  const [summary, setSummary] = useState<WorkHoursSummary | null>(null);
  const [loadingSummary, setLoadingSummary] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [spinning, setSpinning] = useState(false);

  /* ── Favorite clients state ────────────────────────────────── */
  const [favoriteClients, setFavoriteClients] = useState<string[]>([]);
  const [loadingFavorites, setLoadingFavorites] = useState(true);
  const [togglingClient, setTogglingClient] = useState<string | null>(null);
  const [favError, setFavError] = useState("");
  const [manageOpen, setManageOpen] = useState(false);
  const [favSearch, setFavSearch] = useState("");
  const manageBtnRef = useRef<HTMLButtonElement>(null);

  const projectSelectId = useId();
  const favClientsLabelId = useId();
  const favModalTitleId = useId();
  const favModalDescId = useId();
  const favSearchInputId = useId();

  /* Fetch client list, grouped by year, once — reuses the same
     grouped-by-year endpoint pattern as the Work Report Projects
     dropdown, just scoped to clients instead of one client's projects. */
  useEffect(() => {
    api
      .get<{ success: boolean; data: ClientYearOption[] }>("/project-status/grouped-by-year")
      .then(({ data }) => {
        const options = data?.success && Array.isArray(data?.data) ? data.data : [];
        setClientGroups(groupClientsByYear(options));
      })
      .catch(() => {
        setClientGroups([]);
      })
      .finally(() => setLoadingClients(false));
  }, []);

  /* Fetch favorite clients once */
  useEffect(() => {
    favoritesApi
      .list()
      .then(setFavoriteClients)
      .catch(() => setFavoriteClients([]))
      .finally(() => setLoadingFavorites(false));
  }, []);

  /* Fetch projects whenever the selected client changes — grouped by
     year, same endpoint and grouping logic the Work Report Projects
     dropdown uses, so a project stays reachable under every year it has
     activity in instead of the dropdown being narrowed to one year. */
  useEffect(() => {
    if (selectedClient === ALL_VALUE) {
      setSelectedProject(ALL_VALUE);
      return;
    }

    setSelectedProject(ALL_VALUE);

    if (projectsCache[selectedClient] !== undefined) return;

    setLoadingProjects(true);
    api
      .get<{ success: boolean; data: ProjectYearOption[] }>(
        `/project-status/client/${encodeURIComponent(selectedClient)}/grouped-by-year`
      )
      .then(({ data }) => {
        const options = data?.success && Array.isArray(data?.data) ? data.data : [];
        setProjectsCache((prev) => ({ ...prev, [selectedClient]: groupProjectsByYear(options) }));
      })
      .catch(() => {
        setProjectsCache((prev) => ({ ...prev, [selectedClient]: [] }));
      })
      .finally(() => setLoadingProjects(false));
  }, [selectedClient, projectsCache]);

  /* Fetch the aggregated summary whenever filters change */
  const loadSummary = useCallback(async () => {
    setLoadingSummary(true);
    setError(null);

    try {
      const params = new URLSearchParams();
      if (selectedClient !== ALL_VALUE) params.set("client", selectedClient);
      if (selectedProject !== ALL_VALUE) params.set("project", selectedProject);

      const { data } = await api.get<WorkHoursSummary>(
        `/reports/summary${params.toString() ? `?${params.toString()}` : ""}`
      );
      setSummary(data);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoadingSummary(false);
    }
  }, [selectedClient, selectedProject]);

  useEffect(() => {
    loadSummary();
  }, [loadSummary]);

  const clearFilters = () => {
    setSelectedClient(ALL_VALUE);
    setSelectedProject(ALL_VALUE);
  };

  const handleRefresh = () => {
    setSpinning(true);
    loadSummary();
    window.setTimeout(() => setSpinning(false), 550);
  };

  /* ── Favorite clients: toggle add/remove, persisted to the DB ── */
  const toggleFavorite = useCallback(
    async (client: string) => {
      if (togglingClient) return;
      const isFav = favoriteClients.includes(client);
      const previous = favoriteClients;

      setTogglingClient(client);
      setFavError("");
      setFavoriteClients((prev) => (isFav ? prev.filter((c) => c !== client) : [...prev, client]));

      try {
        const updated = isFav ? await favoritesApi.remove(client) : await favoritesApi.add(client);
        setFavoriteClients(updated);
        // If we just unfavorited the client currently selected, fall back to All.
        if (isFav && selectedClient === client) {
          setSelectedClient(ALL_VALUE);
        }
      } catch (err) {
        setFavoriteClients(previous);
        setFavError(getErrorMessage(err));
      } finally {
        setTogglingClient(null);
      }
    },
    [favoriteClients, togglingClient, selectedClient]
  );

  // Total client count across all year groups (de-duplicated), used for the
  // Manage popup's empty state — a client can appear in more than one year.
  const totalClientCount = useMemo(
    () => new Set(clientGroups.flatMap((g) => g.names)).size,
    [clientGroups]
  );

  // Client year-groups filtered by the Manage popup's search box: each
  // group keeps only its matching clients, and empty groups are dropped
  // entirely so the search box also collapses years with no matches.
  const filteredClientGroups = useMemo(() => {
    const q = favSearch.trim().toLowerCase();
    if (!q) return clientGroups;
    return clientGroups
      .map((g) => ({ ...g, names: g.names.filter((c) => c.toLowerCase().includes(q)) }))
      .filter((g) => g.names.length > 0);
  }, [clientGroups, favSearch]);

  const projectGroups = selectedClient !== ALL_VALUE ? projectsCache[selectedClient] ?? [] : [];

  const total = summary?.totalHours ?? 0;
  const pct = (n: number, denom: number) => (denom > 0 ? (n / denom) * 100 : 0);

  /* Closes the manage popup and returns focus to the button that opened
     it, so keyboard users don't get dropped back at the top of the page. */
  const closeManage = useCallback(() => {
    setManageOpen(false);
    requestAnimationFrame(() => manageBtnRef.current?.focus());
  }, []);

  /* Escape closes the manage popup, same as clicking the overlay or the
     close button. Without this, keyboard-only users had no way out. */
  useEffect(() => {
    if (!manageOpen) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeManage();
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [manageOpen, closeManage]);

  return (
    <div className="whd-page">
      <PageHeader
        title="Project Hours Dashboard"
        description="Filter by client and project to see total hours spent on Modeling, Checking, and E Plan + Shop Drawing + Linking + Part Drawing."
      />

      <div className="space-y-4">
        {/* FILTER BAR */}
        <section className="whd-filter-bar rounded-xl border border-border bg-card p-4 shadow-sm">
          <div className="relative flex flex-col gap-3 md:flex-row md:items-end">
            <div className="grid flex-1 gap-3 md:grid-cols-2">
              <div className="space-y-1.5">
                <Label id={favClientsLabelId} className="flex items-center gap-1.5 text-xs">
                  <Star className="h-3.5 w-3.5" aria-hidden="true" /> Client (Favorites)
                </Label>

                <div className="whd-fav-strip" role="group" aria-labelledby={favClientsLabelId}>
                  <button
                    type="button"
                    className={`whd-fav-chip whd-fav-chip--all ${
                      selectedClient === ALL_VALUE ? "whd-fav-chip--active" : ""
                    }`}
                    aria-pressed={selectedClient === ALL_VALUE}
                    onClick={() => setSelectedClient(ALL_VALUE)}
                  >
                    All Clients
                  </button>

                  {loadingFavorites ? (
                    <>
                      <span className="whd-fav-chip whd-fav-chip--skeleton" aria-hidden="true" />
                      <span className="whd-fav-chip whd-fav-chip--skeleton" aria-hidden="true" />
                    </>
                  ) : favoriteClients.length === 0 ? (
                    <span className="whd-fav-empty-hint">No favorites pinned yet</span>
                  ) : (
                    favoriteClients.map((c) => (
                      <FavoriteChip
                        key={c}
                        client={c}
                        active={selectedClient === c}
                        busy={togglingClient === c}
                        onSelect={() => setSelectedClient(c)}
                        onRemove={() => toggleFavorite(c)}
                      />
                    ))
                  )}

                  <button
                    type="button"
                    ref={manageBtnRef}
                    className="whd-fav-manage-btn"
                    onClick={() => setManageOpen(true)}
                    title="Manage favorite clients"
                  >
                    <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                    Manage
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor={projectSelectId} className="flex items-center gap-1.5 text-xs">
                  <Filter className="h-3.5 w-3.5" aria-hidden="true" /> Project
                </Label>
                <Select
                  value={selectedProject}
                  onValueChange={setSelectedProject}
                  disabled={selectedClient === ALL_VALUE || loadingProjects}
                >
                  <SelectTrigger id={projectSelectId}>
                    <SelectValue
                      placeholder={selectedClient === ALL_VALUE ? "Select a client first" : "All projects"}
                    />
                  </SelectTrigger>
                  <SelectContent className="year-grouped-select-content max-h-[320px] overflow-y-auto custom-scrollbar">
                    <SelectItem value={ALL_VALUE}>All Projects</SelectItem>
                    {projectGroups.length > 0 && (
                      <SelectSeparator className="my-1.5" />
                    )}
                    {projectGroups.map((group, idx) => (
                      <SelectGroup key={group.year}>
                        {idx > 0 && <SelectSeparator className="my-1.5" />}
                        <SelectLabel className="year-group-label sticky top-0 z-10 flex items-center gap-1.5 py-1.5 pl-2 pr-2 text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 bg-indigo-50/90 dark:bg-indigo-950/40 backdrop-blur-sm rounded-sm">
                          <Calendar className="h-3 w-3" aria-hidden="true" />
                          {group.year}
                          <span className="ml-auto font-medium text-slate-400 dark:text-slate-500 normal-case tracking-normal">
                            {group.names.length}
                          </span>
                        </SelectLabel>
                        {group.names.map((p) => (
                          <SelectItem key={`${group.year}-${p}`} value={p} className="year-group-item pl-6">
                            {p}
                          </SelectItem>
                        ))}
                      </SelectGroup>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="whd-dim-divider" aria-hidden="true">
              <span className="whd-dim-dot" />
            </div>

            <div className="flex gap-2">
              <Button variant="outline" onClick={clearFilters} className="flex-1 md:flex-none">
                <RotateCcw className="mr-2 h-4 w-4" aria-hidden="true" />
                Clear Filters
              </Button>
              <Button
                variant="outline"
                onClick={handleRefresh}
                className={`whd-refresh-btn ${spinning ? "whd-spinning" : ""}`}
                aria-label="Refresh"
                title="Refresh"
              >
                <RotateCcw className="h-4 w-4" aria-hidden="true" />
              </Button>
            </div>
          </div>
        </section>

        {/* TITLE BLOCK — live readout of the current filter state */}
        <TitleBlock
          client={selectedClient === ALL_VALUE ? "ALL CLIENTS" : selectedClient}
          project={selectedProject === ALL_VALUE ? "ALL PROJECTS" : selectedProject}
        />

        <div className="pt-2" />

        {error ? (
          <div role="alert" className="rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
            {error}
          </div>
        ) : loadingSummary ? (
          <div role="status" aria-live="polite" className="space-y-4">
            <span className="sr-only">Loading hours summary…</span>
            <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4" aria-hidden="true">
              {Array.from({ length: 4 }).map((_, i) => (
                <SkeletonCard key={i} index={i} />
              ))}
            </section>
            <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4" aria-hidden="true">
              {Array.from({ length: 4 }).map((_, i) => (
                <SkeletonCard key={i} index={i + 4} />
              ))}
            </section>
          </div>
        ) : (
          <>
            {/* TOP-LEVEL: three buckets + grand total */}
            <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <StatCard
                label="Modeling"
                value={summary?.modelingHours ?? 0}
                icon={Boxes}
                accent={ACCENT.modeling}
                percent={pct(summary?.modelingHours ?? 0, total)}
                index={0}
              />
              <StatCard
                label="Checking"
                value={summary?.checkingHours ?? 0}
                icon={CheckCircle2}
                accent={ACCENT.checking}
                percent={pct(summary?.checkingHours ?? 0, total)}
                index={1}
              />
              <StatCard
                label="Editing"
                value={summary?.drawingGroupHours ?? 0}
                icon={PencilRuler}
                accent={ACCENT.drawing}
                percent={pct(summary?.drawingGroupHours ?? 0, total)}
                index={2}
                tooltip="E Plan + Shop Drawing + Linking + Part Drawing"
              />
              <StatCard
                label="Total Hours"
                value={total}
                icon={Clock}
                accent={ACCENT.total}
                percent={100}
                index={3}
                emphasis
              />
            </section>

            {/* INDIVIDUAL COMPONENT / CLASS BREAKDOWN */}
            <section>
              <div className="whd-section-label mb-3">
                <h2 className="whitespace-nowrap text-sm text-muted-foreground">
                  Editing Breakdown (Individual)
                </h2>
                <span className="whd-scale-rule" aria-hidden="true" />
              </div>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {DRAWING_COMPONENTS.map(({ key, label, icon, accent }, i) => (
                  <StatCard
                    key={key}
                    label={label}
                    value={summary?.hoursByType?.[key] ?? 0}
                    icon={icon}
                    accent={accent}
                    percent={pct(summary?.hoursByType?.[key] ?? 0, summary?.drawingGroupHours ?? 0)}
                    index={i + 4}
                  />
                ))}
              </div>
            </section>
          </>
        )}
      </div>

      {/* ═══════════ MANAGE FAVORITE CLIENTS POPUP ═══════════ */}
      {manageOpen && (
        <div
          className="whd-fav-overlay"
          onClick={closeManage}
          role="presentation"
        >
          <div
            className="whd-fav-modal whd-mono"
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-modal="true"
            aria-labelledby={favModalTitleId}
            aria-describedby={favModalDescId}
          >
            <span className="whd-corner tl" aria-hidden="true" />
            <span className="whd-corner tr" aria-hidden="true" />
            <span className="whd-corner bl" aria-hidden="true" />
            <span className="whd-corner br" aria-hidden="true" />

            <button
              type="button"
              className="whd-fav-modal-close"
              onClick={closeManage}
              aria-label="Close"
            >
              <X className="h-4 w-4" aria-hidden="true" />
            </button>

            <h3 id={favModalTitleId} className="whd-fav-modal-title">Favorite Clients</h3>
            <p id={favModalDescId} className="whd-fav-modal-subtitle">
              Star the clients you want pinned to this dashboard's filter bar.
            </p>

            <div className="whd-fav-search">
              <Search className="h-3.5 w-3.5" aria-hidden="true" />
              <label htmlFor={favSearchInputId} className="sr-only">Search clients</label>
              <input
                id={favSearchInputId}
                value={favSearch}
                onChange={(e) => setFavSearch(e.target.value)}
                placeholder="Search clients…"
                autoFocus
              />
            </div>

            {favError && <div role="alert" className="whd-fav-error">⚠ {favError}</div>}

            <div className="whd-fav-list">
              {loadingClients ? (
                <div className="whd-fav-loading">Loading clients…</div>
              ) : totalClientCount === 0 ? (
                <div className="whd-fav-loading">No clients found.</div>
              ) : filteredClientGroups.length === 0 ? (
                <div className="whd-fav-loading">No clients match “{favSearch}”.</div>
              ) : (
                filteredClientGroups.map((group) => (
                  <div key={group.year} className="whd-fav-year-group">
                    <div className="whd-fav-year-label year-group-label">
                      <Calendar className="h-3 w-3" aria-hidden="true" />
                      {group.year}
                      <span className="whd-fav-year-count">{group.names.length}</span>
                    </div>
                    {group.names.map((c) => {
                      const isFav = favoriteClients.includes(c);
                      const busy = togglingClient === c;
                      return (
                        <button
                          type="button"
                          key={`${group.year}-${c}`}
                          className={`whd-fav-row year-group-item ${isFav ? "whd-fav-row--active" : ""}`}
                          onClick={() => toggleFavorite(c)}
                          disabled={busy}
                          aria-pressed={isFav}
                        >
                          <span className="whd-fav-row-name">{c}</span>
                          {busy ? (
                            <span className="whd-fav-spinner" aria-hidden="true" />
                          ) : (
                            <Star
                              className={`h-4 w-4 ${isFav ? "whd-fav-star--on" : "whd-fav-star--off"}`}
                              fill={isFav ? "currentColor" : "none"}
                              aria-hidden="true"
                            />
                          )}
                        </button>
                      );
                    })}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WorkHoursDashboard;