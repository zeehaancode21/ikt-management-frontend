import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AnimatedCreateRFIIcon, AnimatedRFISettingIcon, AnimatedRFIsIcon } from "@/components/icons/animatedrfiicons";
import { AnimatedSyncGmailIcon } from "@/components/icons/AnimatedSyncGmailIcon";
import { toast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/Spinner";
import { RfiForm } from "@/components/rfi/RfiForm";
import { RfiList } from "@/components/rfi/RfiList";
import { RfiEmailSettings } from "@/components/rfi/RfiEmailSettings";
import { RfiGmailSettings } from "@/components/rfi/RfiGmailSettings";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  getProjects,
  getRfis,
  getErrorMessage,
  syncAllRfisForProject,
  type ProjectOption,
} from "@/lib/rfiApi";
import type { Rfi, RfiDiscipline, RfiTeamType } from "@/types/rfi";
import { Building, FolderGit2, FileText } from "lucide-react";
import type { CSSProperties } from "react";

const RFI = () => {
  const [projects, setProjects] = useState<ProjectOption[]>([]);
  const [selectedClient, setSelectedClient] = useState<string | null>(null);
  const [selectedProject, setSelectedProject] = useState<string | null>(null);
  const [rfis, setRfis] = useState<Rfi[]>([]);
  const [view, setView] = useState<"settings" | "create" | "history">("create");

  const [loadingRfis, setLoadingRfis] = useState(false);
  const [syncingAll, setSyncingAll] = useState(false);
  const [teamType] = useState<RfiTeamType | "ALL">("ALL");
  const [discipline] = useState<RfiDiscipline | "ALL">("ALL");
  
  const [syncButtonHovered, setSyncButtonHovered] = useState(false);
  const [hoveredTab, setHoveredTab] = useState<"settings" | "create" | "history" | null>(null);

  useEffect(() => {
    getProjects()
      .then((list) => {
        setProjects(list);
        if (list.length > 0 && !selectedClient) {
          const firstClient = list[0].client;
          setSelectedClient(firstClient);
          const firstProjectForClient = list.find((p) => p.client === firstClient);
          if (firstProjectForClient) setSelectedProject(firstProjectForClient.projectName);
        }
      })
      .catch((err) =>
        toast({ title: "Failed to load projects", description: getErrorMessage(err), variant: "destructive" })
      );
  }, [selectedClient]);

  const clients = useMemo(
    () =>
      [...new Set(projects.map((p) => p.client))]
        .filter(Boolean)
        .sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" })),
    [projects]
  );

  const projectsForClient = useMemo(
    () =>
      projects
        .filter((p) => p.client === selectedClient)
        .sort((a, b) => a.projectName.localeCompare(b.projectName, undefined, { sensitivity: "base" })),
    [projects, selectedClient]
  );

  const handleClientChange = (client: string) => {
    setSelectedClient(client);
    const firstProjectForClient = projects.find((p) => p.client === client);
    setSelectedProject(firstProjectForClient ? firstProjectForClient.projectName : null);
  };

  const loadRfis = useCallback(() => {
    if (!selectedProject) return;
    setLoadingRfis(true);
    getRfis(selectedProject, teamType, discipline)
      .then(setRfis)
      .catch((err) =>
        toast({ title: "Failed to load RFIs", description: getErrorMessage(err), variant: "destructive" })
      )
      .finally(() => setLoadingRfis(false));
  }, [selectedProject, teamType, discipline]);

  useEffect(() => {
    loadRfis();
  }, [loadRfis]);

  const handleSyncAll = async () => {
    if (!selectedProject) return;
    setSyncingAll(true);
    try {
      const results = await syncAllRfisForProject(selectedProject);
      const successCount = results.filter((r) => r.success).length;
      const newMessages = results.reduce((sum, r) => sum + (r.newMessagesCount ?? 0), 0);
      toast({
        title: `Sync complete — ${successCount}/${results.length} RFIs checked`,
        description: newMessages > 0 ? `${newMessages} new message(s) imported.` : "No new replies.",
        className: "bg-emerald-600 text-white border-none shadow-xl",
      });
      loadRfis();
    } catch (err) {
      toast({ title: "Sync failed", description: getErrorMessage(err), variant: "destructive" });
    } finally {
      setSyncingAll(false);
    }
  };

  const selectedProjectInfo = projects.find((p) => p.projectName === selectedProject);

  return (
    <div className="flex h-screen w-full flex-col overflow-hidden bg-background p-2 sm:p-3 gap-2">
      <style>{`
        @keyframes rfi-toolbar-fade-in {
          0%   { opacity: 0; transform: translateY(-4px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        .rfi-toolbar-enter { animation: rfi-toolbar-fade-in 320ms cubic-bezier(0.16, 1, 0.3, 1) both; }

        @keyframes rfi-header-fade-in {
          0%   { opacity: 0; transform: translateY(4px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        .rfi-header-enter { animation: rfi-header-fade-in 360ms cubic-bezier(0.16, 1, 0.3, 1) both; animation-delay: 60ms; }

        .rfi-tabs-list {
          position: relative;
          gap: 2px;
          border: 1px solid hsl(var(--border) / 0.7);
          background: hsl(var(--muted) / 0.55);
          backdrop-filter: blur(6px);
        }

        .rfi-tabs-trigger {
          position: relative;
          overflow: hidden;
          gap: 6px;
          transition: color 220ms ease, transform 180ms ease;
        }
        .rfi-tabs-trigger:hover { transform: translateY(-1px); }
        .rfi-tabs-trigger:active { transform: translateY(0) scale(0.96); }

        .rfi-tabs-trigger::before {
          content: '';
          position: absolute;
          inset: 0;
          border-radius: inherit;
          background: linear-gradient(135deg, var(--tab-accent), var(--tab-accent-dark));
          transform: scaleX(0);
          transform-origin: center;
          transition: transform 320ms cubic-bezier(0.4, 0, 0.2, 1);
          z-index: -1;
        }
        .rfi-tabs-trigger[data-state="active"]::before {
          transform: scaleX(1);
        }

        @keyframes rfi-tab-pop {
          0%   { transform: scale(0.92); }
          55%  { transform: scale(1.04); }
          100% { transform: scale(1); }
        }
        @keyframes rfi-tab-glow {
          0%, 100% { box-shadow: 0 4px 14px -4px var(--tab-glow-soft); }
          50%      { box-shadow: 0 4px 18px -2px var(--tab-glow-strong), 0 0 0 3px var(--tab-glow-soft); }
        }
        .rfi-tabs-trigger[data-state="active"] {
          color: #fff !important;
          animation: rfi-tab-pop 260ms cubic-bezier(0.34, 1.56, 0.64, 1),
                     rfi-tab-glow 2.6s ease-in-out 260ms infinite;
        }
        .rfi-tabs-trigger[data-state="active"] svg {
          animation: rfi-tab-icon-wiggle 380ms ease;
        }
        @keyframes rfi-tab-icon-wiggle {
          0%   { transform: rotate(0deg) scale(0.8); }
          50%  { transform: rotate(-10deg) scale(1.2); }
          100% { transform: rotate(0deg) scale(1); }
        }

        .rfi-tab-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          flex-shrink: 0;
          background: var(--tab-accent);
          animation: rfi-tab-dot-beep 1.8s ease-in-out infinite;
        }
        @keyframes rfi-tab-dot-beep {
          0%, 100% { transform: scale(1); opacity: 1; box-shadow: 0 0 0 0 var(--tab-glow-soft); }
          50%      { transform: scale(1.2); opacity: 0.8; box-shadow: 0 0 5px 2px var(--tab-glow-strong); }
        }

        .rfi-sync-btn { transition: transform 160ms ease, box-shadow 200ms ease; }
        .rfi-sync-btn:hover:not(:disabled) { transform: translateY(-1px); }
        .rfi-sync-btn:active:not(:disabled) { transform: translateY(0) scale(0.96); }
      `}</style>

      <div className="flex shrink-0 items-center justify-between rfi-toolbar-enter">
        <Tabs value={view} onValueChange={(v) => setView(v as "settings" | "create" | "history")} className="w-fit">
          <TabsList className="rfi-tabs-list">
            <TabsTrigger
              value="settings"
              className="rfi-tabs-trigger data-[state=active]:bg-transparent data-[state=active]:shadow-none"
              onMouseEnter={() => setHoveredTab("settings")}
              onMouseLeave={() => setHoveredTab(null)}
              style={{
                "--tab-accent": "#0d9488",
                "--tab-accent-dark": "#0f766e",
                "--tab-glow-soft": "rgba(13,148,136,0.35)",
                "--tab-glow-strong": "rgba(13,148,136,0.6)",
              } as CSSProperties}
            >
              <span className="rfi-tab-dot" aria-hidden="true" />
              <AnimatedRFISettingIcon
                size="sm"
                className="h-3.5 w-3.5"
                isParentHovered={hoveredTab === "settings" || view === "settings"}
              />
              Settings
            </TabsTrigger>
            <TabsTrigger
              value="create"
              className="rfi-tabs-trigger data-[state=active]:bg-transparent data-[state=active]:shadow-none"
              onMouseEnter={() => setHoveredTab("create")}
              onMouseLeave={() => setHoveredTab(null)}
              style={{
                "--tab-accent": "#2563eb",
                "--tab-accent-dark": "#1d4ed8",
                "--tab-glow-soft": "rgba(37,99,235,0.35)",
                "--tab-glow-strong": "rgba(37,99,235,0.6)",
              } as CSSProperties}
            >
              <span className="rfi-tab-dot" aria-hidden="true" />
              <AnimatedCreateRFIIcon
                size="sm"
                className="h-3.5 w-3.5"
                isParentHovered={hoveredTab === "create" || view === "create"}
              />
              Create RFI
            </TabsTrigger>
            <TabsTrigger
              value="history"
              className="rfi-tabs-trigger data-[state=active]:bg-transparent data-[state=active]:shadow-none"
              onMouseEnter={() => setHoveredTab("history")}
              onMouseLeave={() => setHoveredTab(null)}
              style={{
                "--tab-accent": "#9333ea",
                "--tab-accent-dark": "#7e22ce",
                "--tab-glow-soft": "rgba(147,51,234,0.35)",
                "--tab-glow-strong": "rgba(147,51,234,0.6)",
              } as CSSProperties}
            >
              <span className="rfi-tab-dot" aria-hidden="true" />
              <AnimatedRFIsIcon
                size="sm"
                className="h-3.5 w-3.5"
                isParentHovered={hoveredTab === "history" || view === "history"}
              />
              RFI's
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {view === "history" && (
          <Button
            type="button"
            size="sm"
            variant="outline"
            className="rfi-sync-btn h-7 gap-1.5 text-[11px]"
            disabled={syncingAll || !selectedProject}
            onClick={handleSyncAll}
            onMouseEnter={() => setSyncButtonHovered(true)}
            onMouseLeave={() => setSyncButtonHovered(false)}
            title="Check Gmail for new replies across all RFIs in this project"
          >
            <AnimatedSyncGmailIcon
              size="sm"
              isParentHovered={syncButtonHovered && !syncingAll}
              className={syncingAll ? "animate-spin" : ""}
            />
            {syncingAll ? "Syncing..." : "Sync Gmail"}
          </Button>
        )}
      </div>

      <header className="rfi-header-enter flex shrink-0 items-center justify-between gap-2 rounded-lg border border-border/80 bg-card/60 px-3 py-1.5 shadow-sm backdrop-blur-md">
        <div className="flex items-center gap-2">
          <div className="flex h-6 w-6 items-center justify-center rounded bg-primary/10 text-primary">
            <FileText className="h-3.5 w-3.5" />
          </div>
          <h1 className="text-xs font-bold uppercase tracking-wider text-foreground">Target Project</h1>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <Building className="h-3 w-3 text-muted-foreground hidden sm:inline-block" />
            <Select value={selectedClient ?? ""} onValueChange={handleClientChange}>
              <SelectTrigger className="h-6 w-[130px] sm:w-[150px] text-[11px] border-border/80 bg-background/80">
                <SelectValue placeholder="Select Client" />
              </SelectTrigger>
              <SelectContent>
                {clients.map((client) => (
                  <SelectItem key={client} value={client} className="text-xs">
                    {client}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-1">
            <FolderGit2 className="h-3 w-3 text-muted-foreground hidden sm:inline-block" />
            <Select value={selectedProject ?? ""} onValueChange={setSelectedProject} disabled={!selectedClient}>
              <SelectTrigger className="h-6 w-[140px] sm:w-[160px] text-[11px] border-border/80 bg-background/80">
                <SelectValue placeholder="Select Project" />
              </SelectTrigger>
              <SelectContent>
                {projectsForClient.map((p) => (
                  <SelectItem key={p.id} value={p.projectName} className="text-xs">
                    {p.projectName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </header>

      <div className="flex-1 min-h-0 flex flex-col gap-2 overflow-hidden">
        <div className="flex-1 min-h-0 overflow-hidden">
          {view === "settings" ? (
            <div className="flex h-full min-h-0 flex-col gap-2 overflow-hidden">
              <RfiGmailSettings />
              <RfiEmailSettings />
            </div>
          ) : view === "create" ? (
            <RfiForm
              projectName={selectedProject}
              initialRecipientEmail={selectedProjectInfo?.rfiRecipientEmail ?? ""}
              initialCcEmails={selectedProjectInfo?.rfiCcEmails ?? ""}
              onSent={() => {
                loadRfis();
                getProjects().then(setProjects).catch(() => {});
              }}
            />
          ) : (
            <div className="h-full overflow-auto">
              <RfiList projectName={selectedProject} rfis={rfis} loading={loadingRfis} onRefresh={loadRfis} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RFI;