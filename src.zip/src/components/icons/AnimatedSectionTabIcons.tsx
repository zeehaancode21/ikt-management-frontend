import type { CSSProperties } from "react";
import { AnimatedIconBase, type IconSize } from "./AnimatedIconbase";
import { useTheme } from "@/context/ThemeContext";

/**
 * Tab-strip icons for SectionTabs (Admin Console / Media Hub and
 * Employee Hub / Dashboard).
 *
 * Each one shows its still PNG from public/icons/ and plays its GIF while the
 * tab is hovered (SectionTabs passes `isParentHovered`).
 *
 * Theme handling:
 *   • light theme, inactive tab → original artwork colours
 *   • dark theme, inactive tab  → recoloured to white
 *   • active tab (coloured gradient background) → always white, both themes
 * A white background baked into the PNG/GIF is removed automatically
 * (whiteBackground="auto"), so no white box shows on the coloured tab.
 *
 * File names (public/icons/) — on a case-sensitive host (Linux/Vercel/Netlify)
 * the case must match the file exactly. Change them here if yours differ.
 */
const ICON_FILES = {
  adminConsole: { png: "/icons/adminconsole.png", gif: "/icons/adminconsole.gif" },
  mediaHub: { png: "/icons/media.png", gif: "/icons/media.gif" },
  employeeHub: { png: "/icons/employeehub.png", gif: "/icons/employeehub.gif" },
  dashboard: { png: "/icons/dashboard.png", gif: "/icons/dashboard.gif" },
} as const;

export interface AnimatedSectionTabIconProps {
  size?: IconSize;
  className?: string;
  /** Hover state of the tab this icon sits in. */
  isParentHovered?: boolean;
  /** Pass true for the active tab so the artwork turns white on its gradient. */
  forceWhite?: boolean;
  disabled?: boolean;
  style?: CSSProperties;
  ariaLabel?: string;
}

interface SectionTabIconOptions {
  /** Extra classes to override the size, e.g. "!w-6 !h-6" (24px). */
  sizeClass?: string;
  /** Scale the animated layer if the GIF has more padding than the PNG. */
  animatedScale?: number;
  /**
   * false = never turn the artwork into a flat white silhouette in dark
   * mode / on the active tab. Use it for detailed, multi-colour icons that
   * turn into a blob when recoloured.
   */
  recolor?: boolean;
}

const createSectionTabIcon = (
  files: { png: string; gif: string },
  defaultLabel: string,
  displayName: string,
  options: SectionTabIconOptions = {}
) => {
  const { sizeClass = "", animatedScale = 1, recolor = true } = options;
  const Icon = ({
    size = "xl",
    className = "",
    isParentHovered = false,
    forceWhite = false,
    disabled = false,
    style,
    ariaLabel = defaultLabel,
  }: AnimatedSectionTabIconProps) => {
    const { theme } = useTheme();

    // Active tab (coloured gradient background): instead of forcing the
    // artwork to flat white — which leaves only the darkest strokes of the
    // animation visible — show it in its ORIGINAL colours on a small white
    // chip. A white background baked into the GIF/PNG then blends into the
    // chip, so nothing needs to be knocked out and no detail is lost.
    // Negative margin keeps the tab's size unchanged.
    const onChip = forceWhite && !disabled;

    return (
      <span
        role="img"
        aria-label={ariaLabel}
        className={`inline-flex shrink-0 rounded-md transition-colors duration-200 ${
          onChip ? "bg-white p-[2px] -m-[2px] shadow-sm" : ""
        }`}
        style={{ opacity: disabled ? 0.5 : 1, ...style }}
      >
        <AnimatedIconBase
          className={`${sizeClass} ${className}`}
          size={size}
          animatedScale={animatedScale}
          pngSrc={files.png}
          animatedSrc={files.gif}
          alt=""
          triggerParentHover
          isParentHovered={!disabled && isParentHovered}
          whiteBackground={onChip ? false : "auto"}
          forceWhite={!onChip && recolor && theme === "dark"}
        />
      </span>
    );
  };
  Icon.displayName = displayName;
  return Icon;
};

export const AnimatedAdminConsoleTabIcon = createSectionTabIcon(
  ICON_FILES.adminConsole, "Admin Console", "AnimatedAdminConsoleTabIcon"
);
export const AnimatedMediaHubTabIcon = createSectionTabIcon(
  ICON_FILES.mediaHub, "Media Hub", "AnimatedMediaHubTabIcon"
);
// Employee Hub artwork is detailed: draw it larger and keep its own colours
// (no flat-white recolour) so it stays clear in both themes.
export const AnimatedEmployeeHubTabIcon = createSectionTabIcon(
  ICON_FILES.employeeHub, "Employee Hub", "AnimatedEmployeeHubTabIcon",
  { sizeClass: "!w-6 !h-6", recolor: false }
);
export const AnimatedDashboardTabIcon = createSectionTabIcon(
  ICON_FILES.dashboard, "Dashboard", "AnimatedDashboardTabIcon"
);