import { useEffect, useState } from "react";
import type { CSSProperties, HTMLAttributes } from "react";

export type IconSize = "sm" | "md" | "lg" | "xl" | "2xl";

export const sizeMap: Record<IconSize, string> = {
  sm: "w-3 h-3", // 12px
  md: "w-3.5 h-3.5", // 14px
  lg: "w-4 h-4", // 16px
  xl: "w-5 h-5", // 20px
  "2xl": "w-8 h-8", // 32px
};

// Recolors an already-correct <img> to solid white (transparent PNG).
const WHITE_FILTER = "brightness(0) invert(1)";

// For an animation with an OPAQUE WHITE background baked into its frames
// (typical Icons8 GIF exports) we remove the white with an SVG colour-matrix
// filter that turns "near-white" into transparent (alpha derived from
// brightness) while keeping the artwork's own colours. Unlike
// mix-blend-mode, a CSS filter works no matter what the icon is nested in —
// wrappers with transform / opacity / filter (e.g. the theme-toggle
// cross-fade) start isolated stacking contexts in which blend modes have
// nothing to blend with, which is what left a whiter box behind the icon.
const KNOCKOUT_FILTER_ID = "aib-white-knockout";
// Light mode: knock out white, keep original colours.
const WHITE_KNOCKOUT_LIGHT = `url(#${KNOCKOUT_FILTER_ID})`;
// Dark mode: knock out white, then recolour the remaining artwork to white.
const WHITE_KNOCKOUT_FILTER = `url(#${KNOCKOUT_FILTER_ID}) brightness(0) invert(1)`;

const ensureKnockoutFilter = () => {
  if (typeof document === "undefined") return;
  if (document.getElementById(`${KNOCKOUT_FILTER_ID}-svg`)) return;
  const svgNS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(svgNS, "svg");
  svg.setAttribute("id", `${KNOCKOUT_FILTER_ID}-svg`);
  svg.setAttribute("width", "0");
  svg.setAttribute("height", "0");
  svg.setAttribute("aria-hidden", "true");
  svg.style.position = "absolute";
  svg.style.pointerEvents = "none";
  // alpha = 20 - 6.667*(R+G+B): white -> 0, anything ≤ ~95% brightness -> 1.
  // The result is then intersected with the original alpha so frames that
  // were already transparent stay transparent.
  svg.innerHTML = `
    <defs>
      <filter id="${KNOCKOUT_FILTER_ID}" color-interpolation-filters="sRGB"
              x="0" y="0" width="100%" height="100%">
        <feColorMatrix type="matrix" result="k"
          values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  -6.667 -6.667 -6.667 0 20"/>
        <feComposite in="k" in2="SourceAlpha" operator="in"/>
      </filter>
    </defs>`;
  document.body.appendChild(svg);
};

// ── Automatic background detection ───────────────────────────────────────
// Looks at the four corner pixels of the animated file once (cached per src):
//   "transparent" → real alpha channel, nothing to remove
//   "white"       → opaque white background baked into the frames
//   "other"       → some other opaque colour (left untouched)
// This lets the same icon code do the right thing in light AND dark mode
// whatever the file turns out to contain.
type BgKind = "transparent" | "white" | "other";
const bgKindCache = new Map<string, Promise<BgKind>>();

const detectBackground = (src: string): Promise<BgKind> => {
  const cached = bgKindCache.get(src);
  if (cached) return cached;

  const promise = new Promise<BgKind>((resolve) => {
    const img = new Image();
    img.onload = () => {
      try {
        const w = img.naturalWidth;
        const h = img.naturalHeight;
        if (!w || !h) return resolve("white");
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d", { willReadFrequently: true });
        if (!ctx) return resolve("white");
        ctx.drawImage(img, 0, 0);
        const corners: Array<[number, number]> = [
          [0, 0],
          [w - 1, 0],
          [0, h - 1],
          [w - 1, h - 1],
        ];
        const kinds = corners.map(([x, y]) => {
          const [r, g, b, a] = ctx.getImageData(x, y, 1, 1).data;
          if (a < 16) return "transparent" as const;
          if (a >= 240 && r >= 235 && g >= 235 && b >= 235) return "white" as const;
          return "other" as const;
        });
        const kind: BgKind = kinds.includes("white")
          ? "white"
          : kinds.every((k) => k === "transparent")
          ? "transparent"
          : "other";
        console.debug(`[AnimatedIconBase] ${src} background detected: ${kind}`);
        resolve(kind);
      } catch {
        // Could not read pixels — assume the common case (white background).
        resolve("white");
      }
    };
    img.onerror = () => resolve("white");
    img.src = src;
  });

  bgKindCache.set(src, promise);
  return promise;
};

// ── Reliable white-background removal for the still icon ────────────────
// The still icon is drawn once to an off-screen canvas; any near-white
// pixel is made fully transparent, and the result (a real transparent
// PNG, as a data URL) is cached and reused as the image's actual src.
// This replaces an earlier approach that used mix-blend-mode: that trick
// only works if there is something painted directly behind the icon
// within the same CSS stacking context — but several places wrap this
// icon in an element with its own `opacity` or `transform` (e.g. the
// day/night cross-fade), which always starts a new, empty stacking
// context. Inside one of those, mix-blend-mode has nothing to blend
// against and silently does nothing, leaving the white square visible.
// Processing actual pixels sidesteps that entirely — it works the same
// regardless of what CSS is wrapped around the icon.
const WHITE_THRESHOLD = 235;
const knockoutCache = new Map<string, Promise<string>>();

const knockOutWhiteBackground = (src: string): Promise<string> => {
  const cached = knockoutCache.get(src);
  if (cached) return cached;

  const promise = new Promise<string>((resolve) => {
    const img = new Image();
    img.onload = () => {
      try {
        const w = img.naturalWidth;
        const h = img.naturalHeight;
        if (!w || !h) return resolve(src);
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d");
        if (!ctx) return resolve(src);
        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, w, h);
        const data = imageData.data;
        for (let i = 0; i < data.length; i += 4) {
          if (
            data[i] >= WHITE_THRESHOLD &&
            data[i + 1] >= WHITE_THRESHOLD &&
            data[i + 2] >= WHITE_THRESHOLD
          ) {
            data[i + 3] = 0;
          }
        }
        ctx.putImageData(imageData, 0, 0);
        resolve(canvas.toDataURL("image/png"));
      } catch {
        // Cross-origin or another canvas read failure — fall back to the
        // original file untouched rather than breaking the icon.
        resolve(src);
      }
    };
    img.onerror = () => resolve(src);
    img.src = src;
  });

  knockoutCache.set(src, promise);
  return promise;
};

// ── Animated file loading ────────────────────────────────────────────────
// Download the animated file (GIF) once and keep the bytes in memory. Every
// hover then gets its own fresh blob: URL, which makes the browser start the
// animation from frame 1 each time. (Re-using the same URL lets browsers
// share one decoded image, so a GIF that plays once — or was already played —
// just shows its last frame on later hovers, i.e. "it doesn't animate".)
// This is the same technique used by AnimatedMessageIcon / AnimatedChecklistIcon.
const animBlobCache = new Map<string, Promise<Blob>>();

const guessMime = (src: string): string => {
  const ext = src.split("?")[0].split(".").pop()?.toLowerCase();
  if (ext === "gif") return "image/gif";
  if (ext === "webp") return "image/webp";
  if (ext === "png") return "image/png";
  return "image/gif";
};

const getAnimatedBlob = (src: string): Promise<Blob> => {
  const cached = animBlobCache.get(src);
  if (cached) return cached;

  const promise = fetch(src)
    .then(async (res) => {
      if (!res.ok) throw new Error(`Failed to load ${src} (${res.status})`);
      const blob = await res.blob();
      // A missing file is often answered with the app's index.html (status
      // 200) by the dev server — that is not an image.
      if (blob.type && !blob.type.startsWith("image/")) {
        throw new Error(
          `${src} returned "${blob.type}" instead of an image — check the file exists in public/icons/ and the name matches.`
        );
      }
      return blob.type ? blob : new Blob([blob], { type: guessMime(src) });
    })
    .catch((err) => {
      animBlobCache.delete(src); // allow a retry on the next hover
      throw err;
    });

  animBlobCache.set(src, promise);
  return promise;
};

interface AnimatedIconBaseProps extends HTMLAttributes<HTMLSpanElement> {
  className?: string;
  size?: IconSize;
  pngSrc: string;
  /** Path of the animated file — a .gif (or .webp) in public/icons/. */
  animatedSrc: string;
  alt: string;
  triggerParentHover?: boolean;
  isParentHovered?: boolean;
  forceWhite?: boolean;
  /**
   * Set to true when the animated file (gif) has an opaque white background
   * baked into its frames. The background is then knocked out in BOTH themes
   * so only the artwork shows on the coloured tile:
   *   • light mode → SVG alpha filter (white vanishes, artwork keeps
   *     its colours)
   *   • dark mode (forceWhite) → artwork becomes solid white, background
   *     becomes transparent (see WHITE_KNOCKOUT_FILTER)
   * Leave it false for animations that are already transparent.
   * Pass "auto" to let the component inspect the animated file and choose
   * (white background → knocked out, transparent → plain white/original).
   */
  whiteBackground?: boolean | "auto";
  /**
   * Some animated files have extra padding around the artwork compared to the
   * still PNG, so the icon looks smaller when it swaps on hover. Use a value
   * above 1 (e.g. 1.2) to scale the animated layer up to match the PNG.
   */
  animatedScale?: number;
}

export const AnimatedIconBase = ({
  className = "",
  size = "md",
  pngSrc,
  animatedSrc,
  alt,
  triggerParentHover = false,
  isParentHovered = false,
  forceWhite = false,
  whiteBackground = false,
  animatedScale = 1,
  ...props
}: AnimatedIconBaseProps) => {
  useEffect(() => {
    ensureKnockoutFilter();
  }, []);

  const [ownHover, setOwnHover] = useState(false);
  const [animUrl, setAnimUrl] = useState<string | null>(null);
  const [animLoaded, setAnimLoaded] = useState(false);

  const active = triggerParentHover ? isParentHovered : ownHover;

  // ── background detection (only when whiteBackground === "auto") ──────────
  // Detected separately for the still PNG and the animated GIF — they are
  // often exported differently (e.g. a transparent PNG paired with a GIF
  // that has a baked-in white frame), so one detector can't cover both.
  const [detectedBg, setDetectedBg] = useState<BgKind | null>(null);
  useEffect(() => {
    if (whiteBackground !== "auto") return;
    let cancelled = false;
    detectBackground(animatedSrc).then((kind) => {
      if (!cancelled) setDetectedBg(kind);
    });
    return () => {
      cancelled = true;
    };
  }, [whiteBackground, animatedSrc]);

  const [detectedPngBg, setDetectedPngBg] = useState<BgKind | null>(null);
  useEffect(() => {
    if (whiteBackground !== "auto") return;
    let cancelled = false;
    detectBackground(pngSrc).then((kind) => {
      if (!cancelled) setDetectedPngBg(kind);
    });
    return () => {
      cancelled = true;
    };
  }, [whiteBackground, pngSrc]);

  // Until detection finishes we don't know which filter to use, so the
  // animated layer stays hidden (the still PNG remains visible meanwhile).
  // Otherwise a white-background GIF could flash as a white box in dark mode.
  const bgReady = whiteBackground !== "auto" || detectedBg !== null;

  const bgMode: BgKind =
    whiteBackground === "auto"
      ? detectedBg ?? "transparent"
      : whiteBackground
      ? "white"
      : "transparent";

  const pngBgMode: BgKind =
    whiteBackground === "auto"
      ? detectedPngBg ?? "transparent"
      : whiteBackground
      ? "white"
      : "transparent";

  // Once we know the still icon has a baked-in white background, process
  // it into a real transparent image (see knockOutWhiteBackground above).
  // Until that finishes, the original file is shown as-is.
  const [processedPngUrl, setProcessedPngUrl] = useState<string | null>(null);
  useEffect(() => {
    if (pngBgMode !== "white") {
      setProcessedPngUrl(null);
      return;
    }
    let cancelled = false;
    knockOutWhiteBackground(pngSrc).then((url) => {
      if (!cancelled) setProcessedPngUrl(url);
    });
    return () => {
      cancelled = true;
    };
  }, [pngBgMode, pngSrc]);

  const effectivePngSrc =
    pngBgMode === "white" && processedPngUrl ? processedPngUrl : pngSrc;

  // Warm the cache once so the first hover animates instantly.
  useEffect(() => {
    getAnimatedBlob(animatedSrc).catch(() => {});
  }, [animatedSrc]);

  // On every hover-in, build a fresh blob: URL so the GIF restarts at frame 1.
  useEffect(() => {
    if (!active) return;
    let cancelled = false;
    let url: string | null = null;

    getAnimatedBlob(animatedSrc)
      .then((blob) => {
        if (cancelled) return;
        url = URL.createObjectURL(blob);
        setAnimUrl(url);
      })
      .catch((err) => {
        // Animated file missing/failed — the static PNG simply stays visible.
        console.warn("[AnimatedIconBase]", err);
      });

    return () => {
      cancelled = true;
      setAnimUrl(null);
      setAnimLoaded(false);
      if (url) URL.revokeObjectURL(url);
    };
  }, [active, animatedSrc]);

  // Still picture: the background is now genuinely transparent (see
  // effectivePngSrc above), so all that's left is the optional white
  // recolor — a plain CSS filter, which (unlike mix-blend-mode) works
  // correctly no matter what the icon is nested inside.
  const pngStyle: CSSProperties = {};
  if (forceWhite && (pngBgMode === "white" || pngBgMode === "transparent")) {
    pngStyle.filter = WHITE_FILTER;
  }
  // pngBgMode === "other": opaque non-white background — leave as is.

  // Animated layer.
  const animatedStyle: CSSProperties = {};
  if (bgMode === "white") {
    animatedStyle.filter = forceWhite
      ? WHITE_KNOCKOUT_FILTER
      : WHITE_KNOCKOUT_LIGHT;
  } else if (bgMode === "transparent" && forceWhite) {
    animatedStyle.filter = WHITE_FILTER;
  }
  // bgMode === "other": opaque non-white background — leave the artwork as is
  // rather than producing a white box.
  if (animatedScale !== 1) {
    animatedStyle.transform = `scale(${animatedScale})`;
  }

  const showAnimated = active && animLoaded && bgReady;

  return (
    <span
      className={`relative inline-block shrink-0 ${sizeMap[size]} ${className}`}
      onMouseEnter={() => {
        if (!triggerParentHover) setOwnHover(true);
      }}
      onMouseLeave={() => {
        if (!triggerParentHover) setOwnHover(false);
      }}
      {...props}
    >
      <img
        src={effectivePngSrc}
        alt={alt}
        style={pngStyle}
        className={`absolute inset-0 h-full w-full object-contain transition-opacity duration-150 ${
          showAnimated ? "opacity-0" : "opacity-100"
        }`}
      />
      {active && animUrl && (
        <img
          src={animUrl}
          alt=""
          aria-hidden="true"
          onLoad={() => setAnimLoaded(true)}
          onError={() => console.warn(`[AnimatedIconBase] ${animatedSrc} could not be decoded`)}
          style={animatedStyle}
          className={`absolute inset-0 h-full w-full object-contain transition-opacity duration-150 ${
            showAnimated ? "opacity-100" : "opacity-0"
          }`}
        />
      )}
    </span>
  );
};