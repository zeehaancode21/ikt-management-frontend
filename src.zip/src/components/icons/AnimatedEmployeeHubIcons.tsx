import { useEffect, useState } from "react";
import type { CSSProperties } from "react";
import { sizeMap, type IconSize } from "./AnimatedIconbase";

/**
 * Base animated employee hub icon component factory
 */
const createAnimatedEmployeeHubIcon = (
  pngSrc: string,
  gifSrc: string,
  componentName: string,
  ariaLabelDefault: string
) => {
  const WHITE_FILTER = "brightness(0) invert(1)";
  const WHITE_KNOCKOUT_FILTER = "grayscale(1) invert(1) brightness(6)";

  const useIsDarkMode = () => {
    const [isDark, setIsDark] = useState(
      () => typeof document !== "undefined" && document.documentElement.classList.contains("dark")
    );

    useEffect(() => {
      const el = document.documentElement;
      const update = () => setIsDark(el.classList.contains("dark"));
      update();
      const observer = new MutationObserver(update);
      observer.observe(el, { attributes: true, attributeFilter: ["class"] });
      return () => observer.disconnect();
    }, []);

    return isDark;
  };

  let gifBlobPromise: Promise<Blob> | null = null;
  const getGifBlob = (): Promise<Blob> => {
    if (!gifBlobPromise) {
      gifBlobPromise = fetch(gifSrc)
        .then(async (res) => {
          if (!res.ok) throw new Error(`Failed to load ${gifSrc} (${res.status})`);
          const blob = await res.blob();
          if (blob.type && !blob.type.startsWith("image/")) {
            throw new Error(`${gifSrc} returned "${blob.type}" instead of an image`);
          }
          return blob.type ? blob : new Blob([blob], { type: "image/gif" });
        })
        .catch((err) => {
          gifBlobPromise = null;
          throw err;
        });
    }
    return gifBlobPromise;
  };

  interface AnimatedEmployeeHubIconProps {
    size?: IconSize;
    className?: string;
    isParentHovered?: boolean;
    triggerParentHover?: boolean;
    disabled?: boolean;
    forceWhite?: boolean;
    style?: CSSProperties;
    ariaLabel?: string;
  }

  const AnimatedIcon = ({
    size = "md",
    className = "",
    isParentHovered = false,
    triggerParentHover = false,
    disabled = false,
    forceWhite = false,
    style = {},
    ariaLabel = ariaLabelDefault,
  }: AnimatedEmployeeHubIconProps) => {
    const isDark = useIsDarkMode();
    const white = forceWhite || isDark;

    const [animUrl, setAnimUrl] = useState<string | null>(null);
    const [animLoaded, setAnimLoaded] = useState(false);

    const active = !disabled && (isParentHovered || triggerParentHover);

    useEffect(() => {
      getGifBlob().catch(() => {});
    }, []);

    useEffect(() => {
      if (!active) return;
      let cancelled = false;
      let url: string | null = null;

      getGifBlob()
        .then((blob) => {
          if (cancelled) return;
          url = URL.createObjectURL(blob);
          setAnimUrl(url);
        })
        .catch((err) => {
          console.warn(`[${componentName}]`, err);
        });

      return () => {
        cancelled = true;
        setAnimUrl(null);
        setAnimLoaded(false);
        if (url) URL.revokeObjectURL(url);
      };
    }, [active]);

    // Active tab (coloured gradient background): show the artwork in its
    // ORIGINAL colours on a small white chip instead of recolouring it to
    // flat white / blending it into the gradient (which left only the
    // darkest strokes visible). A white background baked into the PNG/GIF
    // blends into the chip. Negative margin keeps the tab size unchanged.
    const onChip = forceWhite && !disabled;

    const pngStyleObj: CSSProperties | undefined =
      !onChip && white ? { filter: WHITE_FILTER } : undefined;

    const gifStyleObj: CSSProperties = onChip
      ? {}
      : white
      ? { filter: WHITE_KNOCKOUT_FILTER, mixBlendMode: "screen" }
      : { mixBlendMode: "multiply" };

    return (
      <span
        role="img"
        aria-label={ariaLabel}
        className={`relative inline-block shrink-0 ${sizeMap[size]} ${className} ${
          onChip ? "rounded-md bg-white shadow-sm ring-2 ring-white" : ""
        }`}
        style={{ opacity: disabled ? 0.5 : 1, ...style }}
      >
        <img
          src={pngSrc}
          alt=""
          style={pngStyleObj}
          className={`absolute inset-0 h-full w-full object-contain transition-opacity duration-150 select-none pointer-events-none ${
            active && animLoaded ? "opacity-0" : "opacity-100"
          }`}
          draggable={false}
        />
        {active && animUrl && (
          <img
            src={animUrl}
            alt=""
            aria-hidden="true"
            onLoad={() => setAnimLoaded(true)}
            onError={() => console.warn(`[${componentName}] ${gifSrc} could not be decoded`)}
            style={gifStyleObj}
            className={`absolute inset-0 h-full w-full object-contain transition-opacity duration-150 select-none pointer-events-none ${
              animLoaded ? "opacity-100" : "opacity-0"
            }`}
            draggable={false}
          />
        )}
      </span>
    );
  };

  AnimatedIcon.displayName = componentName;
  return AnimatedIcon;
};

// ─────────────────────────────────────────────────────────────────────────────
// Create Employee Hub Animated Icons
// ─────────────────────────────────────────────────────────────────────────────

export const AnimatedEmployeeHubIcon = createAnimatedEmployeeHubIcon(
  "/icons/employeehub.png",
  "/icons/employeehub.gif",
  "AnimatedEmployeeHubIcon",
  "Employee Hub"
);

export const AnimatedDashboard1Icon = createAnimatedEmployeeHubIcon(
  "/icons/dashboard1.png",
  "/icons/dashboard1.gif",
  "AnimatedDashboard1Icon",
  "Dashboard"
);

export const AnimatedReportIcon = createAnimatedEmployeeHubIcon(
  "/icons/report.png",
  "/icons/report.gif",
  "AnimatedReportIcon",
  "Report"
);

export const AnimatedLeavePortalIcon = createAnimatedEmployeeHubIcon(
  "/icons/leaveportal.png",
  "/icons/leaveportal.gif",
  "AnimatedLeavePortalIcon",
  "Leave Portal"
);

export const AnimatedLeaveIcon = createAnimatedEmployeeHubIcon(
  "/icons/leave.png",
  "/icons/leave.gif",
  "AnimatedLeaveIcon",
  "Leave"
);

export const AnimatedWeekendIcon = createAnimatedEmployeeHubIcon(
  "/icons/weekend.png",
  "/icons/weekend.gif",
  "AnimatedWeekendIcon",
  "Weekend Entries"
);

export default {
  AnimatedEmployeeHubIcon,
  AnimatedDashboard1Icon,
  AnimatedReportIcon,
  AnimatedLeavePortalIcon,
  AnimatedLeaveIcon,
  AnimatedWeekendIcon,
};