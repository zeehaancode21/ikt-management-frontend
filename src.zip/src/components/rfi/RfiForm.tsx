// import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
// import { Button } from "@/components/ui/button";
// import { Input } from "@/components/ui/input";
// import { Label } from "@/components/ui/label";
// import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
// import { Checkbox } from "@/components/ui/checkbox";
// import { Badge } from "@/components/ui/badge";
// import { toast } from "@/hooks/use-toast";
// import { Textarea } from "@/components/ui/textarea";
// import {
//   Send,
//   X,
//   Check,
//   FileCheck,
//   Mail,
//   UploadCloud,
//   CheckCircle2,
//   AlertCircle,
//   Pencil,
//   RotateCcw,
//   Loader2,
//   Star,
//   ChevronDown,
//   Plus,
// } from "lucide-react";
// import { AnimatedUploadIcon } from "@/components/icons/AnimatedUploadIcon";
// import { AnimatedChecklistIcon } from "@/components/icons/Animatedchecklisticon";
// import {
//   RFI_DISCIPLINES,
//   RFI_TEAM_TYPES,
//   type RfiDiscipline,
//   type RfiEmailContact,
//   type RfiTeamType,
// } from "@/types/rfi";
// import {
//   createRfi,
//   getEmployees,
//   getErrorMessage,
//   getFavoriteRfiEmailContacts,
//   previewRfiEmail,
//   type EmployeeOption,
// } from "@/lib/rfiApi";
// import { useAuth } from "@/context/AuthContext";
// import {
//   getDisciplineTheme,
//   getDisciplineIcon,
//   getTeamTypeTheme,
//   getTeamTypeIcon,
//   RfiCircleIcon,
// } from "@/lib/Rfivisuals";

// // ─────────────────────────────────────────────────────────────────────
// // Types & Constants
// // ─────────────────────────────────────────────────────────────────────

// type SendState = "idle" | "sending" | "success" | "error";

// interface Props {
//   projectName: string | null;
//   initialRecipientEmail: string;
//   // Comma-separated CC addresses from the project's most recently sent RFI
//   // (ProjectStatus.rfiCcEmails). Defaults the CC field the same way
//   // initialRecipientEmail already defaults the To field — "whatever I used
//   // last time", empty if this project has no prior RFI.
//   initialCcEmails?: string;
//   onSent: () => void;
// }

// const DEFAULT_DISCIPLINE: RfiDiscipline =
//   (RFI_DISCIPLINES.find((d) => d.toLowerCase().includes("structural")) ??
//     RFI_DISCIPLINES[0]) as RfiDiscipline;

// // Small, deterministic confetti burst used on successful send — kept to a
// // tight, brand-aligned palette (success green + two accent tones) rather
// // than a full rainbow, so it reads as a polished confirmation rather than
// // a party popper.
// const CONFETTI_COLORS = ["#10b981", "#34d399", "#38bdf8", "#a78bfa"];
// const CONFETTI_PIECES = Array.from({ length: 10 }, (_, i) => ({
//   angle: (360 / 10) * i,
//   color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
//   delay: (i % 3) * 40,
//   distance: 30 + (i % 4) * 6,
// }));

// // ─────────────────────────────────────────────────────────────────────
// // Helper Functions
// // ─────────────────────────────────────────────────────────────────────

// function formatDisplayName(username: string): string {
//   if (!username) return "";
//   return username
//     .replace(/([A-Z])/g, " $1")
//     .replace(/_/g, " ")
//     .trim()
//     .split(" ")
//     .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
//     .join(" ");
// }

// // ─────────────────────────────────────────────────────────────────────
// // Component
// // ─────────────────────────────────────────────────────────────────────

// export const RfiForm = ({ projectName, initialRecipientEmail, initialCcEmails, onSent }: Props) => {
//   const { name: authName } = useAuth();

//   // ── Form State ──────────────────────────────────────────────────────
//   const [discipline, setDiscipline] = useState<RfiDiscipline>(DEFAULT_DISCIPLINE);
//   const [teamType, setTeamType] = useState<RfiTeamType>("EXTERNAL");
//   const [subject, setSubject] = useState("");
//   const [file, setFile] = useState<File | null>(null);
//   const [isDragging, setIsDragging] = useState(false);
//   const [recipientEmail, setRecipientEmail] = useState(initialRecipientEmail);
//   const [employees, setEmployees] = useState<EmployeeOption[]>([]);

//   // ── Email Body State ────────────────────────────────────────────────
//   const [emailBody, setEmailBody] = useState("");
//   const [emailBodyDraft, setEmailBodyDraft] = useState("");
//   const [isEditingBody, setIsEditingBody] = useState(false);
//   const [isBodyCustomized, setIsBodyCustomized] = useState(false);
//   const [isBodyPreviewLoading, setIsBodyPreviewLoading] = useState(false);

//   // ── CC & Recipient Picker State ─────────────────────────────────────
//   const [favoriteToContacts, setFavoriteToContacts] = useState<RfiEmailContact[]>([]);
//   const [favoriteCcContacts, setFavoriteCcContacts] = useState<RfiEmailContact[]>([]);
//   const [ccPickerTab, setCcPickerTab] = useState<"favorites" | "employees">("favorites");
//   const [ccEmails, setCcEmails] = useState<string[]>(
//     (initialCcEmails ?? "")
//       .split(/[,;]/)
//       .map((e) => e.trim())
//       .filter(Boolean)
//   );
//   const [ccInput, setCcInput] = useState("");
//   // Removed: toPickerTab - Now only showing favorites, no employees tab needed
//   const [isToPickerOpen, setIsToPickerOpen] = useState(false);
//   const [isCcPickerOpen, setIsCcPickerOpen] = useState(false);

//   // ── Send State & UI ─────────────────────────────────────────────────
//   const [sendState, setSendState] = useState<SendState>("idle");
//   const [shakeKey, setShakeKey] = useState(0);
//   const [launchKey, setLaunchKey] = useState(0);
//   const [isHeaderHovered, setIsHeaderHovered] = useState(false);
//   const [isUploadHovered, setIsUploadHovered] = useState(false);

//   // ── Refs ────────────────────────────────────────────────────────────
//   const fileInputRef = useRef<HTMLInputElement>(null);
//   const successTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
//   const bodyPreviewTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

//   // ── Computed Values ─────────────────────────────────────────────────
//   const currentEmployee = useMemo(() => {
//     if (!authName || employees.length === 0) return null;
//     const normalized = authName.trim().toLowerCase();
//     return (
//       employees.find((e) => e.username.trim().toLowerCase() === normalized) ??
//       employees.find((e) => formatDisplayName(e.username).trim().toLowerCase() === normalized) ??
//       employees.find((e) => normalized.includes(e.username.trim().toLowerCase())) ??
//       null
//     );
//   }, [authName, employees]);

//   const isInternal = teamType === "INTERNAL";
//   const selectedTheme = getDisciplineTheme(discipline);
//   const isBusy = sendState === "sending" || sendState === "success";

//   // ── Effects ─────────────────────────────────────────────────────────

//   // Load employees and email contacts on mount
//   useEffect(() => {
//     getEmployees()
//       .then(setEmployees)
//       .catch((err) =>
//         toast({
//           title: "Failed to load sender list",
//           description: getErrorMessage(err),
//           variant: "destructive",
//         })
//       );
//   }, []);

//   // Fetch favorite CC/To contacts. These are strictly the addresses starred
//   // in RFI Settings — no "all sent-to history" tab here anymore, so the
//   // star/favorite picker on this form can only ever show what's actually
//   // been kept as a favorite (see RfiEmailSettings.tsx).
//   useEffect(() => {
//     getFavoriteRfiEmailContacts("TO")
//       .then(setFavoriteToContacts)
//       .catch((err) =>
//         toast({
//           title: "Failed to load favorite Send To addresses",
//           description: getErrorMessage(err),
//           variant: "destructive",
//         })
//       );
//     getFavoriteRfiEmailContacts("CC")
//       .then(setFavoriteCcContacts)
//       .catch((err) =>
//         toast({
//           title: "Failed to load favorite CC addresses",
//           description: getErrorMessage(err),
//           variant: "destructive",
//         })
//       );
//   }, []);

//   // Update recipient email when prop changes
//   useEffect(() => {
//     setRecipientEmail(initialRecipientEmail);
//   }, [initialRecipientEmail]);

//   // Default CC to whatever was CC'd on this project's most recently sent
//   // RFI (ProjectStatus.rfiCcEmails) — same idea as recipientEmail above.
//   // Empty/undefined just means "no prior RFI on this project yet", so CC
//   // starts empty, exactly like the To field does in that case.
//   useEffect(() => {
//     setCcEmails(
//       (initialCcEmails ?? "")
//         .split(/[,;]/)
//         .map((e) => e.trim())
//         .filter(Boolean)
//     );
//   }, [initialCcEmails]);

//   // Debounced email body preview fetch
//   useEffect(() => {
//     if (!projectName || isBodyCustomized || isEditingBody) return;

//     if (bodyPreviewTimerRef.current) clearTimeout(bodyPreviewTimerRef.current);
//     const delay = emailBody ? 400 : 0;
//     bodyPreviewTimerRef.current = setTimeout(() => {
//       setIsBodyPreviewLoading(true);
//       previewRfiEmail(projectName, subject)
//         .then((preview) => setEmailBody(preview.emailBody))
//         .catch((err) => {
//           console.error("Failed to load default RFI email body:", getErrorMessage(err));
//         })
//         .finally(() => setIsBodyPreviewLoading(false));
//     }, delay);

//     return () => {
//       if (bodyPreviewTimerRef.current) clearTimeout(bodyPreviewTimerRef.current);
//     };
//   }, [projectName, subject, isBodyCustomized, isEditingBody, emailBody]);

//   // Reset upload hover when file is selected
//   useEffect(() => {
//     setIsUploadHovered(false);
//   }, [file]);

//   // Cleanup timers on unmount
//   useEffect(() => {
//     return () => {
//       if (successTimerRef.current) clearTimeout(successTimerRef.current);
//       if (bodyPreviewTimerRef.current) clearTimeout(bodyPreviewTimerRef.current);
//     };
//   }, []);

//   // ── Event Handlers ──────────────────────────────────────────────────

//   const startEditingBody = () => {
//     setEmailBodyDraft(emailBody);
//     setIsEditingBody(true);
//   };

//   const saveBodyEdit = () => {
//     setEmailBody(emailBodyDraft);
//     setIsBodyCustomized(true);
//     setIsEditingBody(false);
//   };

//   const cancelBodyEdit = () => setIsEditingBody(false);

//   const resetBodyToDefault = () => {
//     setIsBodyCustomized(false);
//     setIsEditingBody(false);
//     if (!projectName) return;
//     setIsBodyPreviewLoading(true);
//     previewRfiEmail(projectName, subject)
//       .then((preview) => setEmailBody(preview.emailBody))
//       .catch(() => undefined)
//       .finally(() => setIsBodyPreviewLoading(false));
//   };

//   const addCcEmail = (raw: string) => {
//     const trimmed = raw.trim();
//     if (!trimmed) return;
//     setCcEmails((prev) => (prev.some((c) => c.toLowerCase() === trimmed.toLowerCase()) ? prev : [...prev, trimmed]));
//     setCcInput("");
//   };

//   const removeCcEmail = (email: string) =>
//     setCcEmails((prev) => prev.filter((c) => c.toLowerCase() !== email.toLowerCase()));

//   const toggleCcFavorite = (email: string) =>
//     setCcEmails((prev) =>
//       prev.some((c) => c.toLowerCase() === email.toLowerCase())
//         ? prev.filter((c) => c.toLowerCase() !== email.toLowerCase())
//         : [...prev, email]
//     );

//   const triggerShake = () => setShakeKey((k) => k + 1);

//   const failValidation = (title: string) => {
//     triggerShake();
//     toast({ title, variant: "destructive" });
//   };

//   const acceptFile = (selected: File | null) => {
//     if (!selected) return setFile(null);
//     if (selected.type !== "application/pdf") {
//       toast({
//         title: "Only PDF files are allowed",
//         description: `"${selected.name}" isn't a PDF.`,
//         variant: "destructive",
//       });
//       return;
//     }
//     setFile(selected);
//   };

//   const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) =>
//     acceptFile(e.target.files?.[0] ?? null);

//   const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
//     e.preventDefault();
//     setIsDragging(false);
//     acceptFile(e.dataTransfer.files?.[0] ?? null);
//   };

//   const clearFile = () => {
//     setFile(null);
//     if (fileInputRef.current) fileInputRef.current.value = "";
//   };

//   const resetForm = () => {
//     setDiscipline(DEFAULT_DISCIPLINE);
//     setTeamType("EXTERNAL");
//     setSubject("");
//     setFile(null);
//     if (fileInputRef.current) fileInputRef.current.value = "";
//     setEmailBody("");
//     setEmailBodyDraft("");
//     setIsEditingBody(false);
//     setIsBodyCustomized(false);
//     setCcEmails([]);
//     setCcInput("");
//   };

//   const handleSubmit = async (e: React.FormEvent) => {
//     e.preventDefault();
//     if (sendState === "sending" || sendState === "success") return;
//     if (!projectName) return failValidation("Select a project first");
//     if (!discipline) return failValidation("Discipline is required");
//     if (!subject.trim()) return failValidation("Subject is required");
//     if (!file) return failValidation("A PDF attachment is required");
//     if (!recipientEmail.trim()) return failValidation("Recipient email is required");
//     if (!currentEmployee || !currentEmployee.email) {
//       return failValidation("Your account isn't linked to an employee email — contact an admin");
//     }

//     const senderEmail = currentEmployee.email;
//     const senderName = currentEmployee.username;
//     const finalEmailBody = isEditingBody ? emailBodyDraft : emailBody;

//     setLaunchKey((k) => k + 1);
//     setSendState("sending");
//     try {
//       // Fold any CC text still sitting in the input (not yet turned into a chip
// // via Enter/,/;) into the outgoing list, so clicking Send never silently
// // drops a half-entered address. De-dupes case-insensitively.
// const pendingCc = ccInput.trim();
// const ccEmailsToSend = Array.from(
//   new Map(
//     [...ccEmails, ...(pendingCc ? [pendingCc] : [])]
//       .map((e) => e.trim())
//       .filter(Boolean)
//       .map((e) => [e.toLowerCase(), e] as const)
//   ).values()
// );

// const created = await createRfi(projectName, {
//   discipline,
//   teamType,
//   subject: subject.trim(),
//   emailBody: finalEmailBody.trim() ? finalEmailBody : undefined,
//   attachment: file,
//   senderEmail,
//   senderName: senderName ? formatDisplayName(senderName) : undefined,
//   recipientEmail: recipientEmail.trim(),
//   ccEmails: ccEmailsToSend,
// });
//       toast({
//         title: `${created.rfiNumber} sent successfully!`,
//         description: `Emailed to ${created.recipientEmail}`,
//         className: "bg-emerald-600 text-white border-none shadow-xl",
//       });
//       setSendState("success");
//       successTimerRef.current = setTimeout(() => {
//         resetForm();
//         setSendState("idle");
//         onSent();
//       }, 1200);
//     } catch (err) {
//       triggerShake();
//       setSendState("error");
//       toast({
//         title: "Failed to send RFI",
//         description: getErrorMessage(err),
//         variant: "destructive",
//       });
//       successTimerRef.current = setTimeout(() => setSendState("idle"), 900);
//     }
//   };

//   // ─────────────────────────────────────────────────────────────────────
//   // Render
//   // ─────────────────────────────────────────────────────────────────────

//   return (
//     <form
//       onSubmit={handleSubmit}
//       className="rfi-form-enter relative flex max-h-[85vh] w-full flex-col overflow-hidden rounded-2xl border border-border/60 bg-background/95 p-4 shadow-2xl shadow-black/5 backdrop-blur-xl transition-all duration-300 sm:p-5"
//     >
//       <style>{`
//         .rfi-tight-container, .rfi-tight-container * {
//           scrollbar-width: none;
//           -ms-overflow-style: none;
//         }
//         .rfi-tight-container::-webkit-scrollbar, .rfi-tight-container *::-webkit-scrollbar {
//           display: none;
//         }

//         @keyframes rfi-pop {
//           0%   { transform: scale(0.8) translateY(2px); opacity: 0; }
//           60%  { transform: scale(1.05) translateY(-1px); opacity: 1; }
//           100% { transform: scale(1) translateY(0); opacity: 1; }
//         }
//         .animate-rfi-pop { animation: rfi-pop 0.2s cubic-bezier(0.34, 1.56, 0.64, 1) both; }

//         @keyframes rfi-form-fade-in {
//           0%   { opacity: 0; transform: translateY(6px) scale(0.995); }
//           100% { opacity: 1; transform: translateY(0) scale(1); }
//         }
//         .rfi-form-enter { animation: rfi-form-fade-in 320ms cubic-bezier(0.16, 1, 0.3, 1) both; }

//         @keyframes rfi-section-fade-in {
//           0%   { opacity: 0; transform: translateY(8px); }
//           100% { opacity: 1; transform: translateY(0); }
//         }
//         .rfi-section-enter {
//           animation: rfi-section-fade-in 380ms cubic-bezier(0.16, 1, 0.3, 1) both;
//           animation-delay: var(--rfi-delay, 0ms);
//         }

//         @keyframes rfi-header-sheen {
//           0%   { background-position: 0% 50%; }
//           100% { background-position: 200% 50%; }
//         }
//         .rfi-header-bar {
//           background: linear-gradient(90deg,
//             hsl(var(--primary) / 0.15),
//             hsl(var(--primary)),
//             hsl(var(--primary) / 0.15));
//           background-size: 200% 100%;
//           animation: rfi-header-sheen 5s ease-in-out infinite;
//         }

//         .rfi-circle-icon {
//           transition: transform 180ms cubic-bezier(0.34, 1.56, 0.64, 1), background-color 200ms ease,
//             color 200ms ease, border-color 200ms ease, box-shadow 200ms ease;
//         }

//         .rfi-tile {
//           transition: transform 160ms ease, border-color 200ms ease, background-color 200ms ease,
//             color 200ms ease, box-shadow 250ms ease;
//         }
//         .rfi-tile:hover { transform: translateY(-1px); }
//         .rfi-tile:hover .rfi-circle-icon { transform: scale(1.08); }
//         .rfi-tile:active { transform: translateY(0) scale(0.97); }

//         @keyframes rfi-tile-glow {
//           0%, 100% { box-shadow: 0 0 0 1px var(--tile-ring), 0 0 6px 0 var(--tile-ring); }
//           50%      { box-shadow: 0 0 0 1px var(--tile-ring), 0 0 13px 2px var(--tile-ring); }
//         }
//         .rfi-tile-selected { animation: rfi-tile-glow 2.4s ease-in-out infinite; }
//         .rfi-tile-selected .rfi-circle-icon { transform: scale(1.1); }

//         @keyframes rfi-ring-pulse {
//           0%, 100% { box-shadow: 0 0 0 2px var(--tile-ring), 0 0 0 0 var(--tile-ring); }
//           50%      { box-shadow: 0 0 0 2px var(--tile-ring), 0 0 0 5px transparent; }
//         }
//         .rfi-team-selected .rfi-circle-icon { animation: rfi-ring-pulse 2.4s ease-in-out infinite; }
//         .rfi-team-btn { transition: transform 160ms ease, background-color 200ms ease, box-shadow 200ms ease; }
//         .rfi-team-btn:hover { transform: translateY(-1px); }
//         .rfi-team-btn:hover .rfi-circle-icon { transform: scale(1.08); }
//         .rfi-team-btn:active { transform: translateY(0) scale(0.96); }
//         .rfi-team-btn:active .rfi-circle-icon { transform: scale(0.94); }

//         @keyframes rfi-launch-ring {
//           0%   { transform: scale(0.7); opacity: 0.55; }
//           100% { transform: scale(1.8); opacity: 0; }
//         }
//         .rfi-launch-ring {
//           position: absolute;
//           inset: 0;
//           border-radius: inherit;
//           border: 2px solid rgba(255, 255, 255, 0.7);
//           animation: rfi-launch-ring 600ms ease-out forwards;
//           pointer-events: none;
//         }

//         .rfi-launch-track {
//           position: relative;
//           display: inline-block;
//           width: 30px;
//           height: 14px;
//         }
//         .rfi-launch-trail {
//           position: absolute;
//           top: 50%;
//           left: 0;
//           height: 2px;
//           width: 0;
//           border-radius: 9999px;
//           background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.95));
//           transform: translateY(-50%);
//           animation: rfi-trail-grow 1.15s cubic-bezier(0.45, 0, 0.55, 1) infinite;
//         }
//         @keyframes rfi-trail-grow {
//           0%   { left: 0; width: 0; opacity: 0; }
//           12%  { opacity: 0.9; }
//           78%  { left: 6px; width: 22px; opacity: 0.9; }
//           100% { left: 30px; width: 0; opacity: 0; }
//         }
//         .rfi-launch-plane {
//           position: absolute;
//           top: 50%;
//           left: 0;
//           transform: translateY(-50%) rotate(-8deg);
//           animation: rfi-plane-fly 1.15s cubic-bezier(0.45, 0, 0.55, 1) infinite;
//         }
//         @keyframes rfi-plane-fly {
//           0%   { transform: translate(-2px, -50%) rotate(-8deg) scale(0.85); opacity: 0; }
//           14%  { opacity: 1; transform: translate(2px, -50%) rotate(-8deg) scale(1); }
//           50%  { transform: translate(15px, -55%) rotate(-4deg) scale(1.02); }
//           86%  { opacity: 1; }
//           100% { transform: translate(32px, -50%) rotate(-8deg) scale(0.9); opacity: 0; }
//         }

//         @keyframes rfi-dot-bounce {
//           0%, 80%, 100% { opacity: 0.25; transform: translateY(0); }
//           40%           { opacity: 1; transform: translateY(-1.5px); }
//         }
//         .rfi-dot { display: inline-block; animation: rfi-dot-bounce 1.2s ease-in-out infinite; }
//         .rfi-dot:nth-of-type(1) { animation-delay: 0ms; }
//         .rfi-dot:nth-of-type(2) { animation-delay: 150ms; }
//         .rfi-dot:nth-of-type(3) { animation-delay: 300ms; }
        
//         .rfi-send-overlay {
//           position: absolute;
//           inset: 0;
//           border-radius: inherit;
//           transition: opacity 300ms ease;
//           pointer-events: none;
//         }
//         .rfi-send-overlay-success {
//           background: linear-gradient(135deg, #059669 0%, #10b981 55%, #34d399 100%);
//         }
//         .rfi-send-overlay-error {
//           background: linear-gradient(135deg, #b91c1c 0%, #ef4444 55%, #f87171 100%);
//         }

//         @keyframes rfi-confetti {
//           0%   { transform: translate(-50%, -50%) rotate(var(--angle)) translateY(0) scale(1); opacity: 1; }
//           100% { transform: translate(-50%, -50%) rotate(var(--angle)) translateY(calc(-1 * var(--dist))) scale(0); opacity: 0; }
//         }
//         .rfi-confetti-dot {
//           position: absolute;
//           top: 50%;
//           left: 50%;
//           width: 5px;
//           height: 5px;
//           border-radius: 9999px;
//           background: var(--dot-color);
//           animation: rfi-confetti 650ms ease-out forwards;
//           animation-delay: var(--delay);
//           pointer-events: none;
//         }

//         @keyframes rfi-shake {
//           10%, 90% { transform: translateX(-1px); }
//           20%, 80% { transform: translateX(2px); }
//           30%, 50%, 70% { transform: translateX(-4px); }
//           40%, 60% { transform: translateX(4px); }
//         }
//         .rfi-shake { animation: rfi-shake 420ms cubic-bezier(0.36, 0.07, 0.19, 0.97) both; }

//         .rfi-send {
//           position: relative;
//           isolation: isolate;
//           overflow: hidden;
//           background: linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--primary) / 0.8) 100%);
//           background-size: 200% 200%;
//           transition: background-position 0.25s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.25s ease, transform 0.2s ease;
//         }
//         .rfi-send:hover:not(:disabled) {
//           background-position: 100% 100%;
//           box-shadow: 0 6px 18px -4px hsl(var(--primary) / 0.5);
//           transform: translateY(-1px);
//         }
//         .rfi-send:active:not(:disabled) {
//           transform: translateY(0) scale(0.99);
//         }
//         .rfi-send-plane {
//           transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
//         }
//         .rfi-send:hover:not(:disabled) .rfi-send-plane {
//           transform: translateX(3px) translateY(-1px) rotate(-10deg);
//         }

//         .rfi-drag-active {
//           border-color: hsl(var(--primary));
//           background: hsl(var(--primary) / 0.08);
//         }
//       `}</style>

//       {/* Header */}
//       <div
//         className="mb-1.5 flex w-fit shrink-0 cursor-default items-center gap-1.5 py-0.5 pr-2"
//         onMouseEnter={() => setIsHeaderHovered(true)}
//         onMouseLeave={() => setIsHeaderHovered(false)}
//       >
//         <AnimatedChecklistIcon
//           size="md"
//           className="text-primary"
//           triggerParentHover
//           isParentHovered={isHeaderHovered}
//         />
//         <h2 className="text-xs font-bold tracking-tight text-foreground">New RFI</h2>
//       </div>

//       <div className="rfi-header-bar mb-2 h-[2px] w-full shrink-0 rounded-full opacity-80" />

//       {/* Main Form Fields Container (Scrollable if height constrained) */}
//       <div
//         key={shakeKey}
//         className={`rfi-tight-container flex-1 overflow-y-auto space-y-3.5 pr-0.5 pb-2 ${
//           shakeKey ? "rfi-shake" : ""
//         }`}
//       >
//         {/* Send To Row */}
//         <div className="rfi-section-enter" style={{ "--rfi-delay": "140ms" } as CSSProperties}>
//           <section className="space-y-1">
//             <Label
//               htmlFor="rfi-recipient"
//               className="text-[10.5px] font-bold uppercase tracking-wider text-muted-foreground"
//             >
//               Send To <span className="text-destructive">*</span>
//             </Label>
//             <div className="flex items-center gap-1">
//               <Input
//                 id="rfi-recipient"
//                 type="email"
//                 value={recipientEmail}
//                 onChange={(e) => setRecipientEmail(e.target.value)}
//                 placeholder="reviewer@client.com — or pick a favorite"
//                 disabled={isBusy}
//                 className="h-9 flex-1 text-xs border-border/70 bg-background/60 focus-visible:bg-background"
//               />
//               <Popover open={isToPickerOpen} onOpenChange={setIsToPickerOpen}>
//                 <PopoverTrigger asChild>
//                   <Button
//                     type="button"
//                     variant="outline"
//                     size="icon"
//                     disabled={isBusy}
//                     title="Pick a Send To address"
//                     className="h-9 w-9 shrink-0 border-border/70 bg-background/60"
//                   >
//                     <Star className="h-3.5 w-3.5 text-amber-500" />
//                   </Button>
//                 </PopoverTrigger>
//                 <PopoverContent align="end" className="w-64 p-1.5">
//                   {/* Only show favorites - no employees tab */}
//                   {favoriteToContacts.length === 0 ? (
//                     <p className="px-1.5 py-2 text-[11px] text-muted-foreground">
//                       No favorites yet — star a Send To address in RFI Settings, or just type a new one above.
//                     </p>
//                   ) : (
//                     <ul className="max-h-48 space-y-0.5 overflow-y-auto">
//                       {favoriteToContacts.map((c) => (
//                         <li key={c.email}>
//                           <button
//                             type="button"
//                             onClick={() => {
//                               setRecipientEmail(c.email);
//                               setIsToPickerOpen(false);
//                             }}
//                             className="flex w-full items-center gap-1.5 rounded-md px-1.5 py-1 text-left text-[11px] font-medium text-foreground transition-colors hover:bg-accent/60"
//                           >
//                             <Star className="h-3 w-3 shrink-0 fill-amber-400 text-amber-500" />
//                             <span className="truncate">{c.email}</span>
//                           </button>
//                         </li>
//                       ))}
//                     </ul>
//                   )}
//                 </PopoverContent>
//               </Popover>
//             </div>
//           </section>
//         </div>

//         {/* CC Row */}
//         <section className="space-y-1 rfi-section-enter" style={{ "--rfi-delay": "160ms" } as CSSProperties}>
//           <Label className="text-[10.5px] font-bold uppercase tracking-wider text-muted-foreground">CC</Label>
//           <div className="flex flex-wrap items-center gap-1 rounded-md border border-border/70 bg-background/60 p-1.5 focus-within:bg-background">
//             {ccEmails.map((email) => (
//               <Badge
//                 key={email}
//                 variant="secondary"
//                 className="flex items-center gap-1 rounded-full py-0.5 pl-2 pr-1 text-[10.5px] font-medium"
//               >
//                 <span className="max-w-[160px] truncate">{email}</span>
//                 <button
//                   type="button"
//                   disabled={isBusy}
//                   onClick={() => removeCcEmail(email)}
//                   className="rounded-full p-0.5 text-muted-foreground/70 hover:bg-destructive/10 hover:text-destructive disabled:pointer-events-none"
//                 >
//                   <X className="h-2.5 w-2.5" />
//                 </button>
//               </Badge>
//             ))}
//             <input
//               id="rfi-cc"
//               type="email"
//               value={ccInput}
//               onChange={(e) => setCcInput(e.target.value)}
//               onKeyDown={(e) => {
//                 if (e.key === "Enter" || e.key === "," || e.key === ";") {
//                   e.preventDefault();
//                   addCcEmail(ccInput);
//                 } else if (e.key === "Backspace" && !ccInput && ccEmails.length > 0) {
//                   removeCcEmail(ccEmails[ccEmails.length - 1]);
//                 }
//               }}
//               placeholder={ccEmails.length === 0 ? "cc@client.com — press Enter to add" : "Add another…"}
//               disabled={isBusy}
//               className="h-6 min-w-[140px] flex-1 border-none bg-transparent text-xs outline-none placeholder:text-muted-foreground/60"
//             />
//             {ccInput.trim() && (
//               <button
//                 type="button"
//                 disabled={isBusy}
//                 onClick={() => addCcEmail(ccInput)}
//                 title="Add CC address"
//                 className="rounded-full p-1 text-primary transition-colors hover:bg-primary/10"
//               >
//                 <Plus className="h-3 w-3" />
//               </button>
//             )}

//             <Popover open={isCcPickerOpen} onOpenChange={setIsCcPickerOpen}>
//               <PopoverTrigger asChild>
//                 <button
//                   type="button"
//                   disabled={isBusy}
//                   title="Pick CC addresses"
//                   className="ml-auto flex shrink-0 items-center gap-0.5 rounded-full border border-border/70 bg-background px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground disabled:pointer-events-none disabled:opacity-50"
//                 >
//                   <Star className="h-2.5 w-2.5 text-amber-500" />
//                   Pick CC
//                   <ChevronDown className="h-2.5 w-2.5" />
//                 </button>
//               </PopoverTrigger>
//               <PopoverContent align="end" className="w-64 p-1.5">
//                 <div className="mb-1.5 flex gap-1 rounded-md bg-muted/50 p-0.5">
//                   <button
//                     type="button"
//                     onClick={() => setCcPickerTab("favorites")}
//                     className={[
//                       "flex-1 rounded-sm px-1.5 py-1 text-[10.5px] font-semibold transition-colors",
//                       ccPickerTab === "favorites"
//                         ? "bg-background text-foreground shadow-sm"
//                         : "text-muted-foreground hover:text-foreground",
//                     ].join(" ")}
//                   >
//                     Favorites
//                   </button>
//                   <button
//                     type="button"
//                     onClick={() => setCcPickerTab("employees")}
//                     className={[
//                       "flex-1 rounded-sm px-1.5 py-1 text-[10.5px] font-semibold transition-colors",
//                       ccPickerTab === "employees"
//                         ? "bg-background text-foreground shadow-sm"
//                         : "text-muted-foreground hover:text-foreground",
//                     ].join(" ")}
//                   >
//                     Employees
//                   </button>
//                 </div>

//                 {ccPickerTab === "employees" ? (
//                   (() => {
//                     const employeesWithEmail = employees.filter(
//                       (emp): emp is EmployeeOption & { email: string } => !!emp.email
//                     );
//                     if (employeesWithEmail.length === 0) {
//                       return <p className="px-1.5 py-2 text-[11px] text-muted-foreground">No employees found.</p>;
//                     }
//                     return (
//                       <ul className="max-h-48 space-y-0.5 overflow-y-auto">
//                         {employeesWithEmail.map((emp) => {
//                           const checked = ccEmails.some((e) => e.toLowerCase() === emp.email.toLowerCase());
//                           return (
//                             <li key={emp.id}>
//                               <label className="flex cursor-pointer items-center gap-1.5 rounded-md px-1.5 py-1 text-[11px] font-medium text-foreground transition-colors hover:bg-accent/60">
//                                 <Checkbox
//                                   checked={checked}
//                                   onCheckedChange={() => toggleCcFavorite(emp.email)}
//                                   className="h-3.5 w-3.5"
//                                 />
//                                 <span className="flex min-w-0 flex-col">
//                                   <span className="truncate">{formatDisplayName(emp.username)}</span>
//                                   <span className="truncate text-[10px] font-normal text-muted-foreground">
//                                     {emp.email}
//                                   </span>
//                                 </span>
//                               </label>
//                             </li>
//                           );
//                         })}
//                       </ul>
//                     );
//                   })()
//                 ) : (
//                   (() => {
//                     const list = favoriteCcContacts;
//                     if (list.length === 0) {
//                       return (
//                         <p className="px-1.5 py-2 text-[11px] text-muted-foreground">
//                           No favorites yet — star an employee's CC address in RFI Settings.
//                         </p>
//                       );
//                     }
//                     return (
//                       <ul className="max-h-48 space-y-0.5 overflow-y-auto">
//                         {list.map((c) => {
//                           const checked = ccEmails.some((e) => e.toLowerCase() === c.email.toLowerCase());
//                           return (
//                             <li key={c.email}>
//                               <label className="flex cursor-pointer items-center gap-1.5 rounded-md px-1.5 py-1 text-[11px] font-medium text-foreground transition-colors hover:bg-accent/60">
//                                 <Checkbox
//                                   checked={checked}
//                                   onCheckedChange={() => toggleCcFavorite(c.email)}
//                                   className="h-3.5 w-3.5"
//                                 />
//                                 {c.favorite && (
//                                   <Star className="h-3 w-3 shrink-0 fill-amber-400 text-amber-500" />
//                                 )}
//                                 <span className="truncate">{c.email}</span>
//                               </label>
//                             </li>
//                           );
//                         })}
//                       </ul>
//                     );
//                   })()
//                 )}
//               </PopoverContent>
//             </Popover>
//           </div>
//         </section>

//         {/* Top Split: Discipline + Team Scope */}
//         <div
//           className="grid grid-cols-1 gap-3 lg:grid-cols-12 rfi-section-enter"
//           style={{ "--rfi-delay": "40ms" } as CSSProperties}
//         >
//           {/* Discipline Grid */}
//           <section className="space-y-1 lg:col-span-8">
//             <div className="flex items-center justify-between">
//               <Label className="flex items-center gap-1 text-[10.5px] font-bold uppercase tracking-wider text-muted-foreground">
//                 <span>Discipline</span>
//                 <span className="text-destructive">*</span>
//               </Label>
//               <span
//                 className="text-[11px] font-bold tracking-wide transition-colors duration-300"
//                 style={{ color: selectedTheme.accent }}
//               >
//                 {discipline}
//               </span>
//             </div>

//             <div className="flex flex-wrap gap-1">
//               {RFI_DISCIPLINES.map((d) => {
//                 const Icon = getDisciplineIcon(d);
//                 const theme = getDisciplineTheme(d);
//                 const selected = discipline === d;
//                 return (
//                   <button
//                     key={d}
//                     type="button"
//                     aria-pressed={selected}
//                     disabled={isBusy}
//                     onClick={() => setDiscipline(d)}
//                     style={
//                       selected
//                         ? ({
//                             "--tile-ring": theme.ring,
//                             borderColor: theme.accent,
//                             backgroundColor: `${theme.accent}1A`,
//                             color: theme.accent,
//                           } as CSSProperties)
//                         : undefined
//                     }
//                     className={[
//                       "rfi-tile relative flex shrink-0 items-center gap-1 rounded-full border px-2 py-1 h-7 disabled:opacity-60 disabled:pointer-events-none",
//                       "focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring",
//                       selected
//                         ? "rfi-tile-selected font-semibold"
//                         : "border-border/70 bg-background/60 text-muted-foreground hover:border-primary/40 hover:bg-accent/40 hover:text-foreground",
//                     ].join(" ")}
//                   >
//                     <RfiCircleIcon icon={Icon} theme={theme} size={16} filled={selected} />
//                     <span className="whitespace-nowrap text-[10px] font-semibold leading-none">{d}</span>
//                     {selected && (
//                       <span
//                         className="animate-rfi-pop absolute -right-0.5 -top-0.5 flex h-2 w-2 items-center justify-center rounded-full text-white"
//                         style={{ backgroundColor: theme.accent }}
//                       >
//                         <Check className="h-1 w-1" strokeWidth={5} />
//                       </span>
//                     )}
//                   </button>
//                 );
//               })}
//             </div>
//           </section>

//           {/* Team Scope Switcher — compact chips, same visual language as
//               the Discipline row above (rfi-tile / rfi-tile-selected). */}
//           <section className="space-y-1 lg:col-span-4">
//             <div className="flex items-center justify-between">
//               <Label className="text-[10.5px] font-bold uppercase tracking-wider text-muted-foreground">
//                 Team Scope
//               </Label>
//               <span
//                 className="text-[11px] font-bold tracking-wide transition-colors duration-300"
//                 style={{ color: getTeamTypeTheme(teamType).accent }}
//               >
//                 {teamType === "INTERNAL" ? "Internal" : "External"}
//               </span>
//             </div>

//             <div className="flex gap-1">
//               {RFI_TEAM_TYPES.map((type) => {
//                 const Icon = getTeamTypeIcon(type);
//                 const theme = getTeamTypeTheme(type);
//                 const selected = teamType === type;
//                 return (
//                   <button
//                     key={type}
//                     type="button"
//                     aria-pressed={selected}
//                     disabled={isBusy}
//                     onClick={() => setTeamType(type)}
//                     style={
//                       selected
//                         ? ({
//                             "--tile-ring": theme.ring,
//                             borderColor: theme.accent,
//                             backgroundColor: `${theme.accent}1A`,
//                             color: theme.accent,
//                           } as CSSProperties)
//                         : undefined
//                     }
//                     className={[
//                       "rfi-tile relative flex flex-1 shrink-0 items-center justify-center gap-1 rounded-full border px-2 py-1 h-7 disabled:opacity-60 disabled:pointer-events-none",
//                       "focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring",
//                       selected
//                         ? "rfi-tile-selected font-semibold"
//                         : "border-border/70 bg-background/60 text-muted-foreground hover:border-primary/40 hover:bg-accent/40 hover:text-foreground",
//                     ].join(" ")}
//                   >
//                     <RfiCircleIcon icon={Icon} theme={theme} size={14} filled={selected} />
//                     <span className="whitespace-nowrap text-[10px] font-semibold leading-none">
//                       {type === "INTERNAL" ? "Internal" : "External"}
//                     </span>
//                     {selected && (
//                       <span
//                         className="animate-rfi-pop absolute -right-0.5 -top-0.5 flex h-2 w-2 items-center justify-center rounded-full text-white"
//                         style={{ backgroundColor: theme.accent }}
//                       >
//                         <Check className="h-1 w-1" strokeWidth={5} />
//                       </span>
//                     )}
//                   </button>
//                 );
//               })}
//             </div>
//           </section>
//         </div>

//         {/* Subject Input */}
//         <section className="space-y-1 rfi-section-enter" style={{ "--rfi-delay": "90ms" } as CSSProperties}>
//           <div className="flex items-center justify-between">
//             <Label
//               htmlFor="rfi-subject"
//               className="text-[10.5px] font-bold uppercase tracking-wider text-muted-foreground"
//             >
//               Subject Line <span className="text-destructive">*</span>
//             </Label>
//             <span className="text-[9.5px] font-mono text-muted-foreground/70">{subject.length}/200</span>
//           </div>
//           <Input
//             id="rfi-subject"
//             value={subject}
//             onChange={(e) => setSubject(e.target.value)}
//             placeholder="e.g. Structural Beam Connection Drawing Specs"
//             maxLength={200}
//             disabled={isBusy}
//             className="h-9 text-xs border-border/70 bg-background/60 focus-visible:bg-background"
//           />
//         </section>

//         {/* Email Body */}
//         <section className="space-y-1 rfi-section-enter" style={{ "--rfi-delay": "115ms" } as CSSProperties}>
//           <div className="flex items-center justify-between gap-2">
//             <Label className="flex items-center gap-1.5 text-[10.5px] font-bold uppercase tracking-wider text-muted-foreground">
//               <span>Email Body</span>
//               {isBodyPreviewLoading && (
//                 <Loader2 className="h-2.5 w-2.5 animate-spin text-muted-foreground/60" />
//               )}
//               {isBodyCustomized && !isEditingBody && (
//                 <span className="rounded-full bg-primary/10 px-1.5 py-[1px] text-[9px] font-semibold normal-case tracking-normal text-primary">
//                   Edited
//                 </span>
//               )}
//             </Label>

//             {!isEditingBody ? (
//               <div className="flex items-center gap-1">
//                 {isBodyCustomized && (
//                   <button
//                     type="button"
//                     disabled={isBusy}
//                     onClick={resetBodyToDefault}
//                     className="flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground transition-colors hover:bg-accent/60 hover:text-foreground disabled:pointer-events-none disabled:opacity-50"
//                   >
//                     <RotateCcw className="h-2.5 w-2.5" />
//                     Reset
//                   </button>
//                 )}
//                 <button
//                   type="button"
//                   disabled={isBusy}
//                   onClick={startEditingBody}
//                   className="flex items-center gap-1 rounded-md border border-border/70 bg-background/60 px-2 py-0.5 text-[10px] font-semibold text-muted-foreground transition-colors hover:border-primary/40 hover:bg-accent/50 hover:text-foreground disabled:pointer-events-none disabled:opacity-50"
//                 >
//                   <Pencil className="h-2.5 w-2.5" />
//                   Edit
//                 </button>
//               </div>
//             ) : (
//               <div className="flex items-center gap-1">
//                 <button
//                   type="button"
//                   onClick={cancelBodyEdit}
//                   className="flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground transition-colors hover:bg-accent/60 hover:text-foreground"
//                 >
//                   <X className="h-2.5 w-2.5" />
//                   Cancel
//                 </button>
//                 <button
//                   type="button"
//                   onClick={saveBodyEdit}
//                   className="flex items-center gap-1 rounded-md bg-primary px-2 py-0.5 text-[10px] font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
//                 >
//                   <Check className="h-2.5 w-2.5" />
//                   Save
//                 </button>
//               </div>
//             )}
//           </div>

//           {!isEditingBody ? (
//             <div
//               onClick={() => !isBusy && startEditingBody()}
//               className="max-h-28 cursor-text overflow-y-auto whitespace-pre-wrap rounded-md border border-border/70 bg-background/60 px-3 py-2 text-[11px] leading-relaxed text-foreground/80 transition-colors hover:border-primary/40 hover:bg-accent/20"
//             >
//               {emailBody || (isBodyPreviewLoading ? "Loading default email body…" : "—")}
//             </div>
//           ) : (
//             <Textarea
//               autoFocus
//               value={emailBodyDraft}
//               onChange={(e) => setEmailBodyDraft(e.target.value)}
//               rows={5}
//               disabled={isBusy}
//               placeholder="Email body sent along with the attachment…"
//               className="max-h-40 min-h-[80px] resize-y text-[11px] leading-relaxed border-primary/40 bg-background focus-visible:ring-1 focus-visible:ring-primary/50"
//             />
//           )}
//         </section>

//         {/* Attachment Upload Zone */}
//         <section className="space-y-1 rfi-section-enter" style={{ "--rfi-delay": "190ms" } as CSSProperties}>
//           <Label className="text-[10.5px] font-bold uppercase tracking-wider text-muted-foreground">
//             Attachment (PDF) <span className="text-destructive">*</span>
//           </Label>
//           <input
//             id="rfi-attachment"
//             ref={fileInputRef}
//             type="file"
//             accept="application/pdf,.pdf"
//             onChange={handleFileChange}
//             disabled={isBusy}
//             className="hidden"
//           />
//           {!file ? (
//             <label
//               htmlFor="rfi-attachment"
//               onDragOver={(e) => {
//                 e.preventDefault();
//                 setIsDragging(true);
//               }}
//               onDragLeave={(e) => {
//                 if (!e.currentTarget.contains(e.relatedTarget as Node | null)) setIsDragging(false);
//               }}
//               onDrop={handleDrop}
//               onMouseEnter={() => setIsUploadHovered(true)}
//               onMouseLeave={() => setIsUploadHovered(false)}
//               className={[
//                 "group relative flex h-16 cursor-pointer flex-col items-center justify-center gap-0.5 rounded-lg border border-dashed px-2 text-center transition-all duration-200",
//                 isBusy ? "pointer-events-none opacity-60" : "",
//                 isDragging
//                   ? "rfi-drag-active border-primary"
//                   : "border-border/60 bg-background/30 hover:border-primary/50 hover:bg-accent/20",
//               ].join(" ")}
//             >
//               <AnimatedUploadIcon
//                 size="md"
//                 className="transition-transform duration-200 group-hover:-translate-y-0.5"
//                 triggerParentHover
//                 isParentHovered={isUploadHovered || isDragging}
//               />
//               <span className="text-[11px] font-medium text-foreground">
//                 <span className="text-primary font-semibold hover:underline">Click to upload</span> or drag a PDF
//                 here
//               </span>
//               <span className="text-[9.5px] text-muted-foreground/70">Max one file · PDF only</span>
//             </label>
//           ) : (
//             <div className="animate-rfi-pop flex h-11 items-center justify-between rounded-lg border border-primary/40 bg-primary/10 px-3 shadow-sm">
//               <div className="flex items-center gap-2 truncate">
//                 <FileCheck className="h-4 w-4 text-primary shrink-0" />
//                 <span className="truncate text-[11px] font-semibold text-foreground">{file.name}</span>
//               </div>
//               <Button
//                 type="button"
//                 variant="ghost"
//                 size="icon"
//                 disabled={isBusy}
//                 onClick={clearFile}
//                 className="h-5 w-5 rounded-full text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors"
//               >
//                 <X className="h-3.5 w-3.5" />
//               </Button>
//             </div>
//           )}
//         </section>
//       </div>

//       {/* Sticky Bottom Action Bar */}
//       <div className="sticky bottom-0 z-20 pt-3 mt-1 border-t border-border/60 bg-background/95 backdrop-blur-md">
//         <Button
//           type="submit"
//           disabled={sendState === "sending" || sendState === "success"}
//           className="rfi-send h-11 w-full rounded-lg text-xs font-bold uppercase tracking-wider text-white shadow-md hover:-translate-y-0 disabled:opacity-100"
//         >
//           <span
//             className={`rfi-send-overlay ${
//               sendState === "success"
//                 ? "rfi-send-overlay-success opacity-100"
//                 : sendState === "error"
//                   ? "rfi-send-overlay-error opacity-100"
//                   : "opacity-0"
//             }`}
//             aria-hidden
//           />

//           {sendState === "sending" && <span key={`launch-${launchKey}`} className="rfi-launch-ring" aria-hidden />}

//           {sendState === "success" &&
//             CONFETTI_PIECES.map((p, i) => (
//               <span
//                 key={i}
//                 className="rfi-confetti-dot"
//                 style={
//                   {
//                     "--angle": `${p.angle}deg`,
//                     "--dist": `${p.distance}px`,
//                     "--delay": `${p.delay}ms`,
//                     "--dot-color": p.color,
//                   } as CSSProperties
//                 }
//               />
//             ))}

//           <span className="relative z-10 inline-flex items-center justify-center gap-1.5">
//             {sendState === "sending" && (
//               <>
//                 <span className="rfi-launch-track" aria-hidden>
//                   <span className="rfi-launch-trail" />
//                   <Send className="rfi-launch-plane h-3.5 w-3.5" />
//                 </span>
//                 <span>
//                   Transmitting
//                   <span className="rfi-dot">.</span>
//                   <span className="rfi-dot">.</span>
//                   <span className="rfi-dot">.</span>
//                 </span>
//               </>
//             )}
//             {sendState === "success" && (
//               <>
//                 <CheckCircle2 className="h-3.5 w-3.5 animate-rfi-pop" />
//                 <span>Sent!</span>
//               </>
//             )}
//             {sendState === "error" && (
//               <>
//                 <AlertCircle className="h-3.5 w-3.5 animate-rfi-pop" />
//                 <span>Failed — Try Again</span>
//               </>
//             )}
//             {sendState === "idle" && (
//               <>
//                 <Send className="rfi-send-plane h-3 w-3" />
//                 <span>Submit RFI</span>
//               </>
//             )}
//           </span>
//         </Button>

//         <div className="flex items-center justify-center gap-1.5 text-[10px] text-muted-foreground/80 mt-1.5">
//           <Mail className="h-3 w-3 text-emerald-500" />
//           <span>Instant notification dispatched to recipient</span>
//         </div>
//       </div>
//     </form>
//   );
// };
import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Textarea } from "@/components/ui/textarea";
import {
  Send,
  X,
  Check,
  FileCheck,
  Mail,
  UploadCloud,
  CheckCircle2,
  AlertCircle,
  Pencil,
  RotateCcw,
  Loader2,
  Star,
  ChevronDown,
  Plus,
} from "lucide-react";
import { AnimatedUploadIcon } from "@/components/icons/AnimatedUploadIcon";
import { AnimatedChecklistIcon } from "@/components/icons/Animatedchecklisticon";
import {
  RFI_DISCIPLINES,
  RFI_TEAM_TYPES,
  type RfiDiscipline,
  type RfiEmailContact,
  type RfiTeamType,
} from "@/types/rfi";
import {
  createRfi,
  getEmployees,
  getErrorMessage,
  getFavoriteRfiEmailContacts,
  previewRfiEmail,
  type EmployeeOption,
} from "@/lib/rfiApi";
import { useAuth } from "@/context/AuthContext";
import {
  getDisciplineTheme,
  getDisciplineIcon,
  getTeamTypeTheme,
  getTeamTypeIcon,
  RfiCircleIcon,
} from "@/lib/Rfivisuals";

// ─────────────────────────────────────────────────────────────────────
// Types & Constants
// ─────────────────────────────────────────────────────────────────────

type SendState = "idle" | "sending" | "success" | "error";

interface Props {
  projectName: string | null;
  initialRecipientEmail: string;
  // Comma-separated CC addresses from the project's most recently sent RFI
  // (ProjectStatus.rfiCcEmails). Defaults the CC field the same way
  // initialRecipientEmail already defaults the To field — "whatever I used
  // last time", empty if this project has no prior RFI.
  initialCcEmails?: string;
  onSent: () => void;
}

const DEFAULT_DISCIPLINE: RfiDiscipline =
  (RFI_DISCIPLINES.find((d) => d.toLowerCase().includes("structural")) ??
    RFI_DISCIPLINES[0]) as RfiDiscipline;

// Small, deterministic confetti burst used on successful send — kept to a
// tight, brand-aligned palette (success green + two accent tones) rather
// than a full rainbow, so it reads as a polished confirmation rather than
// a party popper.
const CONFETTI_COLORS = ["#10b981", "#34d399", "#38bdf8", "#a78bfa"];
const CONFETTI_PIECES = Array.from({ length: 10 }, (_, i) => ({
  angle: (360 / 10) * i,
  color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
  delay: (i % 3) * 40,
  distance: 30 + (i % 4) * 6,
}));

// ─────────────────────────────────────────────────────────────────────
// Helper Functions
// ─────────────────────────────────────────────────────────────────────

function formatDisplayName(username: string): string {
  if (!username) return "";
  return username
    .replace(/([A-Z])/g, " $1")
    .replace(/_/g, " ")
    .trim()
    .split(" ")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(" ");
}

// ─────────────────────────────────────────────────────────────────────
// Component
// ─────────────────────────────────────────────────────────────────────

export const RfiForm = ({ projectName, initialRecipientEmail, initialCcEmails, onSent }: Props) => {
  const { name: authName } = useAuth();

  // ── Form State ──────────────────────────────────────────────────────
  const [discipline, setDiscipline] = useState<RfiDiscipline>(DEFAULT_DISCIPLINE);
  const [teamType, setTeamType] = useState<RfiTeamType>("EXTERNAL");
  const [subject, setSubject] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [recipientEmail, setRecipientEmail] = useState(initialRecipientEmail);
  const [employees, setEmployees] = useState<EmployeeOption[]>([]);

  // ── Email Body State ────────────────────────────────────────────────
  const [emailBody, setEmailBody] = useState("");
  const [emailBodyDraft, setEmailBodyDraft] = useState("");
  const [isEditingBody, setIsEditingBody] = useState(false);
  const [isBodyCustomized, setIsBodyCustomized] = useState(false);
  const [isBodyPreviewLoading, setIsBodyPreviewLoading] = useState(false);

  // ── CC & Recipient Picker State ─────────────────────────────────────
  const [favoriteToContacts, setFavoriteToContacts] = useState<RfiEmailContact[]>([]);
  const [favoriteCcContacts, setFavoriteCcContacts] = useState<RfiEmailContact[]>([]);
  const [ccPickerTab, setCcPickerTab] = useState<"favorites" | "employees">("favorites");
  const [ccEmails, setCcEmails] = useState<string[]>(
    (initialCcEmails ?? "")
      .split(/[,;]/)
      .map((e) => e.trim())
      .filter(Boolean)
  );
  const [ccInput, setCcInput] = useState("");
  // Removed: toPickerTab - Now only showing favorites, no employees tab needed
  const [isToPickerOpen, setIsToPickerOpen] = useState(false);
  const [isCcPickerOpen, setIsCcPickerOpen] = useState(false);

  // ── Send State & UI ─────────────────────────────────────────────────
  const [sendState, setSendState] = useState<SendState>("idle");
  const [shakeKey, setShakeKey] = useState(0);
  const [launchKey, setLaunchKey] = useState(0);
  const [isHeaderHovered, setIsHeaderHovered] = useState(false);
  const [isUploadHovered, setIsUploadHovered] = useState(false);

  // ── Refs ────────────────────────────────────────────────────────────
  const fileInputRef = useRef<HTMLInputElement>(null);
  const successTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const bodyPreviewTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // True once the first default body has loaded (used to debounce later refetches only).
  const bodyLoadedRef = useRef(false);

  // ── Computed Values ─────────────────────────────────────────────────
  const currentEmployee = useMemo(() => {
    if (!authName || employees.length === 0) return null;
    const normalized = authName.trim().toLowerCase();
    return (
      employees.find((e) => e.username.trim().toLowerCase() === normalized) ??
      employees.find((e) => formatDisplayName(e.username).trim().toLowerCase() === normalized) ??
      employees.find((e) => normalized.includes(e.username.trim().toLowerCase())) ??
      null
    );
  }, [authName, employees]);

  const isInternal = teamType === "INTERNAL";
  const selectedTheme = getDisciplineTheme(discipline);
  const isBusy = sendState === "sending" || sendState === "success";

  // ── Effects ─────────────────────────────────────────────────────────

  // Load employees and email contacts on mount
  useEffect(() => {
    getEmployees()
      .then(setEmployees)
      .catch((err) =>
        toast({
          title: "Failed to load sender list",
          description: getErrorMessage(err),
          variant: "destructive",
        })
      );
  }, []);

  // Fetch favorite CC/To contacts. These are strictly the addresses starred
  // in RFI Settings — no "all sent-to history" tab here anymore, so the
  // star/favorite picker on this form can only ever show what's actually
  // been kept as a favorite (see RfiEmailSettings.tsx).
  useEffect(() => {
    getFavoriteRfiEmailContacts("TO")
      .then(setFavoriteToContacts)
      .catch((err) =>
        toast({
          title: "Failed to load favorite Send To addresses",
          description: getErrorMessage(err),
          variant: "destructive",
        })
      );
    getFavoriteRfiEmailContacts("CC")
      .then(setFavoriteCcContacts)
      .catch((err) =>
        toast({
          title: "Failed to load favorite CC addresses",
          description: getErrorMessage(err),
          variant: "destructive",
        })
      );
  }, []);

  // Update recipient email when prop changes
  useEffect(() => {
    setRecipientEmail(initialRecipientEmail);
  }, [initialRecipientEmail]);

  // Default CC to whatever was CC'd on this project's most recently sent
  // RFI (ProjectStatus.rfiCcEmails) — same idea as recipientEmail above.
  // Empty/undefined just means "no prior RFI on this project yet", so CC
  // starts empty, exactly like the To field does in that case.
  useEffect(() => {
    setCcEmails(
      (initialCcEmails ?? "")
        .split(/[,;]/)
        .map((e) => e.trim())
        .filter(Boolean)
    );
  }, [initialCcEmails]);

  // Debounced email body preview fetch.
  // NOTE: emailBody must NOT be a dependency here — this effect sets it, which used to
  // re-trigger the effect and fetch the same preview a second time on every load.
  useEffect(() => {
    if (!projectName || isBodyCustomized || isEditingBody) return;

    if (bodyPreviewTimerRef.current) clearTimeout(bodyPreviewTimerRef.current);
    const delay = bodyLoadedRef.current ? 400 : 0;
    bodyPreviewTimerRef.current = setTimeout(() => {
      setIsBodyPreviewLoading(true);
      previewRfiEmail(projectName, subject)
        .then((preview) => {
          bodyLoadedRef.current = true;
          setEmailBody(preview.emailBody);
        })
        .catch((err) => {
          console.error("Failed to load default RFI email body:", getErrorMessage(err));
        })
        .finally(() => setIsBodyPreviewLoading(false));
    }, delay);

    return () => {
      if (bodyPreviewTimerRef.current) clearTimeout(bodyPreviewTimerRef.current);
    };
  }, [projectName, subject, isBodyCustomized, isEditingBody]);

  // Reset upload hover when file is selected
  useEffect(() => {
    setIsUploadHovered(false);
  }, [file]);

  // Cleanup timers on unmount
  useEffect(() => {
    return () => {
      if (successTimerRef.current) clearTimeout(successTimerRef.current);
      if (bodyPreviewTimerRef.current) clearTimeout(bodyPreviewTimerRef.current);
    };
  }, []);

  // ── Event Handlers ──────────────────────────────────────────────────

  const startEditingBody = () => {
    setEmailBodyDraft(emailBody);
    setIsEditingBody(true);
  };

  const saveBodyEdit = () => {
    setEmailBody(emailBodyDraft);
    setIsBodyCustomized(true);
    setIsEditingBody(false);
  };

  const cancelBodyEdit = () => setIsEditingBody(false);

  const resetBodyToDefault = () => {
    setIsBodyCustomized(false);
    setIsEditingBody(false);
    if (!projectName) return;
    setIsBodyPreviewLoading(true);
    previewRfiEmail(projectName, subject)
      .then((preview) => setEmailBody(preview.emailBody))
      .catch(() => undefined)
      .finally(() => setIsBodyPreviewLoading(false));
  };

  const addCcEmail = (raw: string) => {
    const trimmed = raw.trim();
    if (!trimmed) return;
    setCcEmails((prev) => (prev.some((c) => c.toLowerCase() === trimmed.toLowerCase()) ? prev : [...prev, trimmed]));
    setCcInput("");
  };

  const removeCcEmail = (email: string) =>
    setCcEmails((prev) => prev.filter((c) => c.toLowerCase() !== email.toLowerCase()));

  const toggleCcFavorite = (email: string) =>
    setCcEmails((prev) =>
      prev.some((c) => c.toLowerCase() === email.toLowerCase())
        ? prev.filter((c) => c.toLowerCase() !== email.toLowerCase())
        : [...prev, email]
    );

  const triggerShake = () => setShakeKey((k) => k + 1);

  const failValidation = (title: string) => {
    triggerShake();
    toast({ title, variant: "destructive" });
  };

  const acceptFile = (selected: File | null) => {
    if (!selected) return setFile(null);
    if (selected.type !== "application/pdf") {
      toast({
        title: "Only PDF files are allowed",
        description: `"${selected.name}" isn't a PDF.`,
        variant: "destructive",
      });
      return;
    }
    setFile(selected);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) =>
    acceptFile(e.target.files?.[0] ?? null);

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    acceptFile(e.dataTransfer.files?.[0] ?? null);
  };

  const clearFile = () => {
    setFile(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const resetForm = () => {
    setDiscipline(DEFAULT_DISCIPLINE);
    setTeamType("EXTERNAL");
    setSubject("");
    setFile(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
    setEmailBody("");
    setEmailBodyDraft("");
    setIsEditingBody(false);
    setIsBodyCustomized(false);
    setCcEmails([]);
    setCcInput("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (sendState === "sending" || sendState === "success") return;
    if (!projectName) return failValidation("Select a project first");
    if (!discipline) return failValidation("Discipline is required");
    if (!subject.trim()) return failValidation("Subject is required");
    if (!file) return failValidation("A PDF attachment is required");
    if (!recipientEmail.trim()) return failValidation("Recipient email is required");
    if (!currentEmployee || !currentEmployee.email) {
      return failValidation("Your account isn't linked to an employee email — contact an admin");
    }

    const senderEmail = currentEmployee.email;
    const senderName = currentEmployee.username;
    const finalEmailBody = isEditingBody ? emailBodyDraft : emailBody;

    setLaunchKey((k) => k + 1);
    setSendState("sending");
    try {
      // Fold any CC text still sitting in the input (not yet turned into a chip
// via Enter/,/;) into the outgoing list, so clicking Send never silently
// drops a half-entered address. De-dupes case-insensitively.
const pendingCc = ccInput.trim();
const ccEmailsToSend = Array.from(
  new Map(
    [...ccEmails, ...(pendingCc ? [pendingCc] : [])]
      .map((e) => e.trim())
      .filter(Boolean)
      .map((e) => [e.toLowerCase(), e] as const)
  ).values()
);

const created = await createRfi(projectName, {
  discipline,
  teamType,
  subject: subject.trim(),
  emailBody: finalEmailBody.trim() ? finalEmailBody : undefined,
  attachment: file,
  senderEmail,
  senderName: senderName ? formatDisplayName(senderName) : undefined,
  recipientEmail: recipientEmail.trim(),
  ccEmails: ccEmailsToSend,
});
      toast({
        title: `${created.rfiNumber} sent successfully!`,
        description: `Emailed to ${created.recipientEmail}`,
        className: "bg-emerald-600 text-white border-none shadow-xl",
      });
      setSendState("success");
      successTimerRef.current = setTimeout(() => {
        resetForm();
        setSendState("idle");
        onSent();
      }, 1200);
    } catch (err) {
      triggerShake();
      setSendState("error");
      toast({
        title: "Failed to send RFI",
        description: getErrorMessage(err),
        variant: "destructive",
      });
      successTimerRef.current = setTimeout(() => setSendState("idle"), 900);
    }
  };

  // ─────────────────────────────────────────────────────────────────────
  // Render
  // ─────────────────────────────────────────────────────────────────────

  return (
    <form
      onSubmit={handleSubmit}
      className="rfi-form-enter relative flex max-h-[85vh] w-full flex-col overflow-hidden rounded-2xl border border-border/60 bg-background/95 p-4 shadow-2xl shadow-black/5 backdrop-blur-xl transition-all duration-300 sm:p-5"
    >
      <style>{`
        .rfi-tight-container, .rfi-tight-container * {
          scrollbar-width: none;
          -ms-overflow-style: none;
        }
        .rfi-tight-container::-webkit-scrollbar, .rfi-tight-container *::-webkit-scrollbar {
          display: none;
        }

        @keyframes rfi-pop {
          0%   { transform: scale(0.8) translateY(2px); opacity: 0; }
          60%  { transform: scale(1.05) translateY(-1px); opacity: 1; }
          100% { transform: scale(1) translateY(0); opacity: 1; }
        }
        .animate-rfi-pop { animation: rfi-pop 0.2s cubic-bezier(0.34, 1.56, 0.64, 1) both; }

        @keyframes rfi-form-fade-in {
          0%   { opacity: 0; transform: translateY(6px) scale(0.995); }
          100% { opacity: 1; transform: translateY(0) scale(1); }
        }
        .rfi-form-enter { animation: rfi-form-fade-in 320ms cubic-bezier(0.16, 1, 0.3, 1) both; }

        @keyframes rfi-section-fade-in {
          0%   { opacity: 0; transform: translateY(8px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        .rfi-section-enter {
          animation: rfi-section-fade-in 380ms cubic-bezier(0.16, 1, 0.3, 1) both;
          animation-delay: var(--rfi-delay, 0ms);
        }

        @keyframes rfi-header-sheen {
          0%   { background-position: 0% 50%; }
          100% { background-position: 200% 50%; }
        }
        .rfi-header-bar {
          background: linear-gradient(90deg,
            hsl(var(--primary) / 0.15),
            hsl(var(--primary)),
            hsl(var(--primary) / 0.15));
          background-size: 200% 100%;
          animation: rfi-header-sheen 5s ease-in-out infinite;
        }

        .rfi-circle-icon {
          transition: transform 180ms cubic-bezier(0.34, 1.56, 0.64, 1), background-color 200ms ease,
            color 200ms ease, border-color 200ms ease, box-shadow 200ms ease;
        }

        .rfi-tile {
          transition: transform 160ms ease, border-color 200ms ease, background-color 200ms ease,
            color 200ms ease, box-shadow 250ms ease;
        }
        .rfi-tile:hover { transform: translateY(-1px); }
        .rfi-tile:hover .rfi-circle-icon { transform: scale(1.08); }
        .rfi-tile:active { transform: translateY(0) scale(0.97); }

        @keyframes rfi-tile-glow {
          0%, 100% { box-shadow: 0 0 0 1px var(--tile-ring), 0 0 6px 0 var(--tile-ring); }
          50%      { box-shadow: 0 0 0 1px var(--tile-ring), 0 0 13px 2px var(--tile-ring); }
        }
        .rfi-tile-selected { animation: rfi-tile-glow 2.4s ease-in-out infinite; }
        .rfi-tile-selected .rfi-circle-icon { transform: scale(1.1); }

        @keyframes rfi-ring-pulse {
          0%, 100% { box-shadow: 0 0 0 2px var(--tile-ring), 0 0 0 0 var(--tile-ring); }
          50%      { box-shadow: 0 0 0 2px var(--tile-ring), 0 0 0 5px transparent; }
        }
        .rfi-team-selected .rfi-circle-icon { animation: rfi-ring-pulse 2.4s ease-in-out infinite; }
        .rfi-team-btn { transition: transform 160ms ease, background-color 200ms ease, box-shadow 200ms ease; }
        .rfi-team-btn:hover { transform: translateY(-1px); }
        .rfi-team-btn:hover .rfi-circle-icon { transform: scale(1.08); }
        .rfi-team-btn:active { transform: translateY(0) scale(0.96); }
        .rfi-team-btn:active .rfi-circle-icon { transform: scale(0.94); }

        @keyframes rfi-launch-ring {
          0%   { transform: scale(0.7); opacity: 0.55; }
          100% { transform: scale(1.8); opacity: 0; }
        }
        .rfi-launch-ring {
          position: absolute;
          inset: 0;
          border-radius: inherit;
          border: 2px solid rgba(255, 255, 255, 0.7);
          animation: rfi-launch-ring 600ms ease-out forwards;
          pointer-events: none;
        }

        .rfi-launch-track {
          position: relative;
          display: inline-block;
          width: 30px;
          height: 14px;
        }
        .rfi-launch-trail {
          position: absolute;
          top: 50%;
          left: 0;
          height: 2px;
          width: 0;
          border-radius: 9999px;
          background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.95));
          transform: translateY(-50%);
          animation: rfi-trail-grow 1.15s cubic-bezier(0.45, 0, 0.55, 1) infinite;
        }
        @keyframes rfi-trail-grow {
          0%   { left: 0; width: 0; opacity: 0; }
          12%  { opacity: 0.9; }
          78%  { left: 6px; width: 22px; opacity: 0.9; }
          100% { left: 30px; width: 0; opacity: 0; }
        }
        .rfi-launch-plane {
          position: absolute;
          top: 50%;
          left: 0;
          transform: translateY(-50%) rotate(-8deg);
          animation: rfi-plane-fly 1.15s cubic-bezier(0.45, 0, 0.55, 1) infinite;
        }
        @keyframes rfi-plane-fly {
          0%   { transform: translate(-2px, -50%) rotate(-8deg) scale(0.85); opacity: 0; }
          14%  { opacity: 1; transform: translate(2px, -50%) rotate(-8deg) scale(1); }
          50%  { transform: translate(15px, -55%) rotate(-4deg) scale(1.02); }
          86%  { opacity: 1; }
          100% { transform: translate(32px, -50%) rotate(-8deg) scale(0.9); opacity: 0; }
        }

        @keyframes rfi-dot-bounce {
          0%, 80%, 100% { opacity: 0.25; transform: translateY(0); }
          40%           { opacity: 1; transform: translateY(-1.5px); }
        }
        .rfi-dot { display: inline-block; animation: rfi-dot-bounce 1.2s ease-in-out infinite; }
        .rfi-dot:nth-of-type(1) { animation-delay: 0ms; }
        .rfi-dot:nth-of-type(2) { animation-delay: 150ms; }
        .rfi-dot:nth-of-type(3) { animation-delay: 300ms; }
        
        .rfi-send-overlay {
          position: absolute;
          inset: 0;
          border-radius: inherit;
          transition: opacity 300ms ease;
          pointer-events: none;
        }
        .rfi-send-overlay-success {
          background: linear-gradient(135deg, #059669 0%, #10b981 55%, #34d399 100%);
        }
        .rfi-send-overlay-error {
          background: linear-gradient(135deg, #b91c1c 0%, #ef4444 55%, #f87171 100%);
        }

        @keyframes rfi-confetti {
          0%   { transform: translate(-50%, -50%) rotate(var(--angle)) translateY(0) scale(1); opacity: 1; }
          100% { transform: translate(-50%, -50%) rotate(var(--angle)) translateY(calc(-1 * var(--dist))) scale(0); opacity: 0; }
        }
        .rfi-confetti-dot {
          position: absolute;
          top: 50%;
          left: 50%;
          width: 5px;
          height: 5px;
          border-radius: 9999px;
          background: var(--dot-color);
          animation: rfi-confetti 650ms ease-out forwards;
          animation-delay: var(--delay);
          pointer-events: none;
        }

        @keyframes rfi-shake {
          10%, 90% { transform: translateX(-1px); }
          20%, 80% { transform: translateX(2px); }
          30%, 50%, 70% { transform: translateX(-4px); }
          40%, 60% { transform: translateX(4px); }
        }
        .rfi-shake { animation: rfi-shake 420ms cubic-bezier(0.36, 0.07, 0.19, 0.97) both; }

        .rfi-send {
          position: relative;
          isolation: isolate;
          overflow: hidden;
          background: linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--primary) / 0.8) 100%);
          background-size: 200% 200%;
          transition: background-position 0.25s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.25s ease, transform 0.2s ease;
        }
        .rfi-send:hover:not(:disabled) {
          background-position: 100% 100%;
          box-shadow: 0 6px 18px -4px hsl(var(--primary) / 0.5);
          transform: translateY(-1px);
        }
        .rfi-send:active:not(:disabled) {
          transform: translateY(0) scale(0.99);
        }
        .rfi-send-plane {
          transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
        }
        .rfi-send:hover:not(:disabled) .rfi-send-plane {
          transform: translateX(3px) translateY(-1px) rotate(-10deg);
        }

        .rfi-drag-active {
          border-color: hsl(var(--primary));
          background: hsl(var(--primary) / 0.08);
        }
      `}</style>

      {/* Header */}
      <div
        className="mb-1.5 flex w-fit shrink-0 cursor-default items-center gap-1.5 py-0.5 pr-2"
        onMouseEnter={() => setIsHeaderHovered(true)}
        onMouseLeave={() => setIsHeaderHovered(false)}
      >
        <AnimatedChecklistIcon
          size="md"
          className="text-primary"
          triggerParentHover
          isParentHovered={isHeaderHovered}
        />
        <h2 className="text-xs font-bold tracking-tight text-foreground">New RFI</h2>
      </div>

      <div className="rfi-header-bar mb-2 h-[2px] w-full shrink-0 rounded-full opacity-80" />

      {/* Main Form Fields Container (Scrollable if height constrained) */}
      <div
        key={shakeKey}
        className={`rfi-tight-container flex-1 overflow-y-auto space-y-3.5 pr-0.5 pb-2 ${
          shakeKey ? "rfi-shake" : ""
        }`}
      >
        {/* Send To Row */}
        <div className="rfi-section-enter" style={{ "--rfi-delay": "140ms" } as CSSProperties}>
          <section className="space-y-1">
            <Label
              htmlFor="rfi-recipient"
              className="text-[10.5px] font-bold uppercase tracking-wider text-muted-foreground"
            >
              Send To <span className="text-destructive">*</span>
            </Label>
            <div className="flex items-center gap-1">
              <Input
                id="rfi-recipient"
                type="email"
                value={recipientEmail}
                onChange={(e) => setRecipientEmail(e.target.value)}
                placeholder="reviewer@client.com — or pick a favorite"
                disabled={isBusy}
                className="h-9 flex-1 text-xs border-border/70 bg-background/60 focus-visible:bg-background"
              />
              <Popover open={isToPickerOpen} onOpenChange={setIsToPickerOpen}>
                <PopoverTrigger asChild>
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    disabled={isBusy}
                    title="Pick a Send To address"
                    className="h-9 w-9 shrink-0 border-border/70 bg-background/60"
                  >
                    <Star className="h-3.5 w-3.5 text-amber-500" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-64 p-1.5">
                  {/* Only show favorites - no employees tab */}
                  {favoriteToContacts.length === 0 ? (
                    <p className="px-1.5 py-2 text-[11px] text-muted-foreground">
                      No favorites yet — star a Send To address in RFI Settings, or just type a new one above.
                    </p>
                  ) : (
                    <ul className="max-h-48 space-y-0.5 overflow-y-auto">
                      {favoriteToContacts.map((c) => (
                        <li key={c.email}>
                          <button
                            type="button"
                            onClick={() => {
                              setRecipientEmail(c.email);
                              setIsToPickerOpen(false);
                            }}
                            className="flex w-full items-center gap-1.5 rounded-md px-1.5 py-1 text-left text-[11px] font-medium text-foreground transition-colors hover:bg-accent/60"
                          >
                            <Star className="h-3 w-3 shrink-0 fill-amber-400 text-amber-500" />
                            <span className="truncate">{c.email}</span>
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </PopoverContent>
              </Popover>
            </div>
          </section>
        </div>

        {/* CC Row */}
        <section className="space-y-1 rfi-section-enter" style={{ "--rfi-delay": "160ms" } as CSSProperties}>
          <Label className="text-[10.5px] font-bold uppercase tracking-wider text-muted-foreground">CC</Label>
          <div className="flex flex-wrap items-center gap-1 rounded-md border border-border/70 bg-background/60 p-1.5 focus-within:bg-background">
            {ccEmails.map((email) => (
              <Badge
                key={email}
                variant="secondary"
                className="flex items-center gap-1 rounded-full py-0.5 pl-2 pr-1 text-[10.5px] font-medium"
              >
                <span className="max-w-[160px] truncate">{email}</span>
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() => removeCcEmail(email)}
                  className="rounded-full p-0.5 text-muted-foreground/70 hover:bg-destructive/10 hover:text-destructive disabled:pointer-events-none"
                >
                  <X className="h-2.5 w-2.5" />
                </button>
              </Badge>
            ))}
            <input
              id="rfi-cc"
              type="email"
              value={ccInput}
              onChange={(e) => setCcInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === "," || e.key === ";") {
                  e.preventDefault();
                  addCcEmail(ccInput);
                } else if (e.key === "Backspace" && !ccInput && ccEmails.length > 0) {
                  removeCcEmail(ccEmails[ccEmails.length - 1]);
                }
              }}
              placeholder={ccEmails.length === 0 ? "cc@client.com — press Enter to add" : "Add another…"}
              disabled={isBusy}
              className="h-6 min-w-[140px] flex-1 border-none bg-transparent text-xs outline-none placeholder:text-muted-foreground/60"
            />
            {ccInput.trim() && (
              <button
                type="button"
                disabled={isBusy}
                onClick={() => addCcEmail(ccInput)}
                title="Add CC address"
                className="rounded-full p-1 text-primary transition-colors hover:bg-primary/10"
              >
                <Plus className="h-3 w-3" />
              </button>
            )}

            <Popover open={isCcPickerOpen} onOpenChange={setIsCcPickerOpen}>
              <PopoverTrigger asChild>
                <button
                  type="button"
                  disabled={isBusy}
                  title="Pick CC addresses"
                  className="ml-auto flex shrink-0 items-center gap-0.5 rounded-full border border-border/70 bg-background px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground disabled:pointer-events-none disabled:opacity-50"
                >
                  <Star className="h-2.5 w-2.5 text-amber-500" />
                  Pick CC
                  <ChevronDown className="h-2.5 w-2.5" />
                </button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-64 p-1.5">
                <div className="mb-1.5 flex gap-1 rounded-md bg-muted/50 p-0.5">
                  <button
                    type="button"
                    onClick={() => setCcPickerTab("favorites")}
                    className={[
                      "flex-1 rounded-sm px-1.5 py-1 text-[10.5px] font-semibold transition-colors",
                      ccPickerTab === "favorites"
                        ? "bg-background text-foreground shadow-sm"
                        : "text-muted-foreground hover:text-foreground",
                    ].join(" ")}
                  >
                    Favorites
                  </button>
                  <button
                    type="button"
                    onClick={() => setCcPickerTab("employees")}
                    className={[
                      "flex-1 rounded-sm px-1.5 py-1 text-[10.5px] font-semibold transition-colors",
                      ccPickerTab === "employees"
                        ? "bg-background text-foreground shadow-sm"
                        : "text-muted-foreground hover:text-foreground",
                    ].join(" ")}
                  >
                    Employees
                  </button>
                </div>

                {ccPickerTab === "employees" ? (
                  (() => {
                    const employeesWithEmail = employees.filter(
                      (emp): emp is EmployeeOption & { email: string } => !!emp.email
                    );
                    if (employeesWithEmail.length === 0) {
                      return <p className="px-1.5 py-2 text-[11px] text-muted-foreground">No employees found.</p>;
                    }
                    return (
                      <ul className="max-h-48 space-y-0.5 overflow-y-auto">
                        {employeesWithEmail.map((emp) => {
                          const checked = ccEmails.some((e) => e.toLowerCase() === emp.email.toLowerCase());
                          return (
                            <li key={emp.id}>
                              <label className="flex cursor-pointer items-center gap-1.5 rounded-md px-1.5 py-1 text-[11px] font-medium text-foreground transition-colors hover:bg-accent/60">
                                <Checkbox
                                  checked={checked}
                                  onCheckedChange={() => toggleCcFavorite(emp.email)}
                                  className="h-3.5 w-3.5"
                                />
                                <span className="flex min-w-0 flex-col">
                                  <span className="truncate">{formatDisplayName(emp.username)}</span>
                                  <span className="truncate text-[10px] font-normal text-muted-foreground">
                                    {emp.email}
                                  </span>
                                </span>
                              </label>
                            </li>
                          );
                        })}
                      </ul>
                    );
                  })()
                ) : (
                  (() => {
                    const list = favoriteCcContacts;
                    if (list.length === 0) {
                      return (
                        <p className="px-1.5 py-2 text-[11px] text-muted-foreground">
                          No favorites yet — star an employee's CC address in RFI Settings.
                        </p>
                      );
                    }
                    return (
                      <ul className="max-h-48 space-y-0.5 overflow-y-auto">
                        {list.map((c) => {
                          const checked = ccEmails.some((e) => e.toLowerCase() === c.email.toLowerCase());
                          return (
                            <li key={c.email}>
                              <label className="flex cursor-pointer items-center gap-1.5 rounded-md px-1.5 py-1 text-[11px] font-medium text-foreground transition-colors hover:bg-accent/60">
                                <Checkbox
                                  checked={checked}
                                  onCheckedChange={() => toggleCcFavorite(c.email)}
                                  className="h-3.5 w-3.5"
                                />
                                {c.favorite && (
                                  <Star className="h-3 w-3 shrink-0 fill-amber-400 text-amber-500" />
                                )}
                                <span className="truncate">{c.email}</span>
                              </label>
                            </li>
                          );
                        })}
                      </ul>
                    );
                  })()
                )}
              </PopoverContent>
            </Popover>
          </div>
        </section>

        {/* Top Split: Discipline + Team Scope */}
        <div
          className="grid grid-cols-1 gap-3 lg:grid-cols-12 rfi-section-enter"
          style={{ "--rfi-delay": "40ms" } as CSSProperties}
        >
          {/* Discipline Grid */}
          <section className="space-y-1 lg:col-span-8">
            <div className="flex items-center justify-between">
              <Label className="flex items-center gap-1 text-[10.5px] font-bold uppercase tracking-wider text-muted-foreground">
                <span>Discipline</span>
                <span className="text-destructive">*</span>
              </Label>
              <span
                className="text-[11px] font-bold tracking-wide transition-colors duration-300"
                style={{ color: selectedTheme.accent }}
              >
                {discipline}
              </span>
            </div>

            <div className="flex flex-wrap gap-1">
              {RFI_DISCIPLINES.map((d) => {
                const Icon = getDisciplineIcon(d);
                const theme = getDisciplineTheme(d);
                const selected = discipline === d;
                return (
                  <button
                    key={d}
                    type="button"
                    aria-pressed={selected}
                    disabled={isBusy}
                    onClick={() => setDiscipline(d)}
                    style={
                      selected
                        ? ({
                            "--tile-ring": theme.ring,
                            borderColor: theme.accent,
                            backgroundColor: `${theme.accent}1A`,
                            color: theme.accent,
                          } as CSSProperties)
                        : undefined
                    }
                    className={[
                      "rfi-tile relative flex shrink-0 items-center gap-1 rounded-full border px-2 py-1 h-7 disabled:opacity-60 disabled:pointer-events-none",
                      "focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring",
                      selected
                        ? "rfi-tile-selected font-semibold"
                        : "border-border/70 bg-background/60 text-muted-foreground hover:border-primary/40 hover:bg-accent/40 hover:text-foreground",
                    ].join(" ")}
                  >
                    <RfiCircleIcon icon={Icon} theme={theme} size={16} filled={selected} />
                    <span className="whitespace-nowrap text-[10px] font-semibold leading-none">{d}</span>
                    {selected && (
                      <span
                        className="animate-rfi-pop absolute -right-0.5 -top-0.5 flex h-2 w-2 items-center justify-center rounded-full text-white"
                        style={{ backgroundColor: theme.accent }}
                      >
                        <Check className="h-1 w-1" strokeWidth={5} />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </section>

          {/* Team Scope Switcher — compact chips, same visual language as
              the Discipline row above (rfi-tile / rfi-tile-selected). */}
          <section className="space-y-1 lg:col-span-4">
            <div className="flex items-center justify-between">
              <Label className="text-[10.5px] font-bold uppercase tracking-wider text-muted-foreground">
                Team Scope
              </Label>
              <span
                className="text-[11px] font-bold tracking-wide transition-colors duration-300"
                style={{ color: getTeamTypeTheme(teamType).accent }}
              >
                {teamType === "INTERNAL" ? "Internal" : "External"}
              </span>
            </div>

            <div className="flex gap-1">
              {RFI_TEAM_TYPES.map((type) => {
                const Icon = getTeamTypeIcon(type);
                const theme = getTeamTypeTheme(type);
                const selected = teamType === type;
                return (
                  <button
                    key={type}
                    type="button"
                    aria-pressed={selected}
                    disabled={isBusy}
                    onClick={() => setTeamType(type)}
                    style={
                      selected
                        ? ({
                            "--tile-ring": theme.ring,
                            borderColor: theme.accent,
                            backgroundColor: `${theme.accent}1A`,
                            color: theme.accent,
                          } as CSSProperties)
                        : undefined
                    }
                    className={[
                      "rfi-tile relative flex flex-1 shrink-0 items-center justify-center gap-1 rounded-full border px-2 py-1 h-7 disabled:opacity-60 disabled:pointer-events-none",
                      "focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring",
                      selected
                        ? "rfi-tile-selected font-semibold"
                        : "border-border/70 bg-background/60 text-muted-foreground hover:border-primary/40 hover:bg-accent/40 hover:text-foreground",
                    ].join(" ")}
                  >
                    <RfiCircleIcon icon={Icon} theme={theme} size={14} filled={selected} />
                    <span className="whitespace-nowrap text-[10px] font-semibold leading-none">
                      {type === "INTERNAL" ? "Internal" : "External"}
                    </span>
                    {selected && (
                      <span
                        className="animate-rfi-pop absolute -right-0.5 -top-0.5 flex h-2 w-2 items-center justify-center rounded-full text-white"
                        style={{ backgroundColor: theme.accent }}
                      >
                        <Check className="h-1 w-1" strokeWidth={5} />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </section>
        </div>

        {/* Subject Input */}
        <section className="space-y-1 rfi-section-enter" style={{ "--rfi-delay": "90ms" } as CSSProperties}>
          <div className="flex items-center justify-between">
            <Label
              htmlFor="rfi-subject"
              className="text-[10.5px] font-bold uppercase tracking-wider text-muted-foreground"
            >
              Subject Line <span className="text-destructive">*</span>
            </Label>
            <span className="text-[9.5px] font-mono text-muted-foreground/70">{subject.length}/200</span>
          </div>
          <Input
            id="rfi-subject"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="e.g. Structural Beam Connection Drawing Specs"
            maxLength={200}
            disabled={isBusy}
            className="h-9 text-xs border-border/70 bg-background/60 focus-visible:bg-background"
          />
        </section>

        {/* Email Body */}
        <section className="space-y-1 rfi-section-enter" style={{ "--rfi-delay": "115ms" } as CSSProperties}>
          <div className="flex items-center justify-between gap-2">
            <Label className="flex items-center gap-1.5 text-[10.5px] font-bold uppercase tracking-wider text-muted-foreground">
              <span>Email Body</span>
              {isBodyPreviewLoading && (
                <Loader2 className="h-2.5 w-2.5 animate-spin text-muted-foreground/60" />
              )}
              {isBodyCustomized && !isEditingBody && (
                <span className="rounded-full bg-primary/10 px-1.5 py-[1px] text-[9px] font-semibold normal-case tracking-normal text-primary">
                  Edited
                </span>
              )}
            </Label>

            {!isEditingBody ? (
              <div className="flex items-center gap-1">
                {isBodyCustomized && (
                  <button
                    type="button"
                    disabled={isBusy}
                    onClick={resetBodyToDefault}
                    className="flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground transition-colors hover:bg-accent/60 hover:text-foreground disabled:pointer-events-none disabled:opacity-50"
                  >
                    <RotateCcw className="h-2.5 w-2.5" />
                    Reset
                  </button>
                )}
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={startEditingBody}
                  className="flex items-center gap-1 rounded-md border border-border/70 bg-background/60 px-2 py-0.5 text-[10px] font-semibold text-muted-foreground transition-colors hover:border-primary/40 hover:bg-accent/50 hover:text-foreground disabled:pointer-events-none disabled:opacity-50"
                >
                  <Pencil className="h-2.5 w-2.5" />
                  Edit
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={cancelBodyEdit}
                  className="flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground transition-colors hover:bg-accent/60 hover:text-foreground"
                >
                  <X className="h-2.5 w-2.5" />
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={saveBodyEdit}
                  className="flex items-center gap-1 rounded-md bg-primary px-2 py-0.5 text-[10px] font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
                >
                  <Check className="h-2.5 w-2.5" />
                  Save
                </button>
              </div>
            )}
          </div>

          {!isEditingBody ? (
            <div
              onClick={() => !isBusy && startEditingBody()}
              className="max-h-28 cursor-text overflow-y-auto whitespace-pre-wrap rounded-md border border-border/70 bg-background/60 px-3 py-2 text-[11px] leading-relaxed text-foreground/80 transition-colors hover:border-primary/40 hover:bg-accent/20"
            >
              {emailBody || (isBodyPreviewLoading ? "Loading default email body…" : "—")}
            </div>
          ) : (
            <Textarea
              autoFocus
              value={emailBodyDraft}
              onChange={(e) => setEmailBodyDraft(e.target.value)}
              rows={5}
              disabled={isBusy}
              placeholder="Email body sent along with the attachment…"
              className="max-h-40 min-h-[80px] resize-y text-[11px] leading-relaxed border-primary/40 bg-background focus-visible:ring-1 focus-visible:ring-primary/50"
            />
          )}
        </section>

        {/* Attachment Upload Zone */}
        <section className="space-y-1 rfi-section-enter" style={{ "--rfi-delay": "190ms" } as CSSProperties}>
          <Label className="text-[10.5px] font-bold uppercase tracking-wider text-muted-foreground">
            Attachment (PDF) <span className="text-destructive">*</span>
          </Label>
          <input
            id="rfi-attachment"
            ref={fileInputRef}
            type="file"
            accept="application/pdf,.pdf"
            onChange={handleFileChange}
            disabled={isBusy}
            className="hidden"
          />
          {!file ? (
            <label
              htmlFor="rfi-attachment"
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={(e) => {
                if (!e.currentTarget.contains(e.relatedTarget as Node | null)) setIsDragging(false);
              }}
              onDrop={handleDrop}
              onMouseEnter={() => setIsUploadHovered(true)}
              onMouseLeave={() => setIsUploadHovered(false)}
              className={[
                "group relative flex h-16 cursor-pointer flex-col items-center justify-center gap-0.5 rounded-lg border border-dashed px-2 text-center transition-all duration-200",
                isBusy ? "pointer-events-none opacity-60" : "",
                isDragging
                  ? "rfi-drag-active border-primary"
                  : "border-border/60 bg-background/30 hover:border-primary/50 hover:bg-accent/20",
              ].join(" ")}
            >
              <AnimatedUploadIcon
                size="md"
                className="transition-transform duration-200 group-hover:-translate-y-0.5"
                triggerParentHover
                isParentHovered={isUploadHovered || isDragging}
              />
              <span className="text-[11px] font-medium text-foreground">
                <span className="text-primary font-semibold hover:underline">Click to upload</span> or drag a PDF
                here
              </span>
              <span className="text-[9.5px] text-muted-foreground/70">Max one file · PDF only</span>
            </label>
          ) : (
            <div className="animate-rfi-pop flex h-11 items-center justify-between rounded-lg border border-primary/40 bg-primary/10 px-3 shadow-sm">
              <div className="flex items-center gap-2 truncate">
                <FileCheck className="h-4 w-4 text-primary shrink-0" />
                <span className="truncate text-[11px] font-semibold text-foreground">{file.name}</span>
              </div>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                disabled={isBusy}
                onClick={clearFile}
                className="h-5 w-5 rounded-full text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors"
              >
                <X className="h-3.5 w-3.5" />
              </Button>
            </div>
          )}
        </section>
      </div>

      {/* Sticky Bottom Action Bar */}
      <div className="sticky bottom-0 z-20 pt-3 mt-1 border-t border-border/60 bg-background/95 backdrop-blur-md">
        <Button
          type="submit"
          disabled={sendState === "sending" || sendState === "success"}
          className="rfi-send h-11 w-full rounded-lg text-xs font-bold uppercase tracking-wider text-white shadow-md hover:-translate-y-0 disabled:opacity-100"
        >
          <span
            className={`rfi-send-overlay ${
              sendState === "success"
                ? "rfi-send-overlay-success opacity-100"
                : sendState === "error"
                  ? "rfi-send-overlay-error opacity-100"
                  : "opacity-0"
            }`}
            aria-hidden
          />

          {sendState === "sending" && <span key={`launch-${launchKey}`} className="rfi-launch-ring" aria-hidden />}

          {sendState === "success" &&
            CONFETTI_PIECES.map((p, i) => (
              <span
                key={i}
                className="rfi-confetti-dot"
                style={
                  {
                    "--angle": `${p.angle}deg`,
                    "--dist": `${p.distance}px`,
                    "--delay": `${p.delay}ms`,
                    "--dot-color": p.color,
                  } as CSSProperties
                }
              />
            ))}

          <span className="relative z-10 inline-flex items-center justify-center gap-1.5">
            {sendState === "sending" && (
              <>
                <span className="rfi-launch-track" aria-hidden>
                  <span className="rfi-launch-trail" />
                  <Send className="rfi-launch-plane h-3.5 w-3.5" />
                </span>
                <span>
                  Transmitting
                  <span className="rfi-dot">.</span>
                  <span className="rfi-dot">.</span>
                  <span className="rfi-dot">.</span>
                </span>
              </>
            )}
            {sendState === "success" && (
              <>
                <CheckCircle2 className="h-3.5 w-3.5 animate-rfi-pop" />
                <span>Sent!</span>
              </>
            )}
            {sendState === "error" && (
              <>
                <AlertCircle className="h-3.5 w-3.5 animate-rfi-pop" />
                <span>Failed — Try Again</span>
              </>
            )}
            {sendState === "idle" && (
              <>
                <Send className="rfi-send-plane h-3 w-3" />
                <span>Submit RFI</span>
              </>
            )}
          </span>
        </Button>

        <div className="flex items-center justify-center gap-1.5 text-[10px] text-muted-foreground/80 mt-1.5">
          <Mail className="h-3 w-3 text-emerald-500" />
          <span>Instant notification dispatched to recipient</span>
        </div>
      </div>
    </form>
  );
};