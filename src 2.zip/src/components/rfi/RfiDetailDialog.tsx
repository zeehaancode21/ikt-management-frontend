import { useCallback, useEffect, useState, type ReactNode } from "react";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { StatusBadge } from "@/components/StatusBadge";
import { Spinner } from "@/components/Spinner";
import { toast } from "@/hooks/use-toast";
import { Mail, User, Copy, Check } from "lucide-react";
import { AnimatedCheckRepliesIcon } from "@/components/icons/AnimatedCheckRepliesIcon";
import { AnimatedEyeIcon } from "@/components/icons/AnimatedEyeIcon";
import { downloadAttachment, previewAttachment } from "@/lib/attachmentActions";
import { getRfiById, getRfiHistory, syncRfiGmail, updateRfiPriority, getErrorMessage } from "@/lib/rfiApi";
import { toRfiPriority, type Rfi, type RfiPriority, type RfiTimelineEvent } from "@/types/rfi";
import { RfiPrioritySelector } from "@/components/rfi/RfiPrioritySelector";
import { PRIORITY_LABELS } from "@/lib/Rfivisuals";
import { RfiStatusActions } from "./RfiStatusActions";
import { RfiTimeline } from "./RfiTimeline";
import { DownloadProgressButton } from "@/components/DownloadProgressButton";

interface Props {
  projectName: string | null;
  rfiId: number | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onRfiUpdated: () => void;
}

const Field = ({ label, value }: { label: string; value?: ReactNode }) => (
  <div className="space-y-0.5">
    <div className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground">
      {label}
    </div>
    <div className="text-xs text-foreground break-words">{value ?? "—"}</div>
  </div>
);

export const RfiDetailDialog = ({
  projectName,
  rfiId,
  open,
  onOpenChange,
  onRfiUpdated,
}: Props) => {
  const [rfi, setRfi] = useState<Rfi | null>(null);
  const [history, setHistory] = useState<RfiTimelineEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [checkRepliesHovered, setCheckRepliesHovered] = useState(false);
  const [copiedCc, setCopiedCc] = useState(false);
  const [copiedRecipient, setCopiedRecipient] = useState(false);
  const [savingPriority, setSavingPriority] = useState(false);

  const loadAll = useCallback(() => {
    if (!projectName || rfiId == null) return;
    setLoading(true);
    Promise.all([getRfiById(projectName, rfiId), getRfiHistory(projectName, rfiId)])
      .then(([rfiData, historyData]) => {
        setRfi(rfiData);
        setHistory(historyData);
      })
      .catch((err) =>
        toast({
          title: "Failed to load RFI details",
          description: getErrorMessage(err),
          variant: "destructive",
        })
      )
      .finally(() => setLoading(false));
  }, [projectName, rfiId]);

  useEffect(() => {
    if (open) loadAll();
    if (!open) {
      setRfi(null);
      setHistory([]);
    }
  }, [open, loadAll]);

  // Monitor dark mode changes
  useEffect(() => {
    setIsDarkMode(document.documentElement.classList.contains("dark"));
    const observer = new MutationObserver(() =>
      setIsDarkMode(document.documentElement.classList.contains("dark"))
    );
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class"],
    });
    return () => observer.disconnect();
  }, []);

  const handleSync = async () => {
    if (!projectName || rfiId == null) return;
    setSyncing(true);
    try {
      const result = await syncRfiGmail(projectName, rfiId);
      if (result.success) {
        toast({
          title:
            result.newMessagesCount > 0
              ? `${result.newMessagesCount} new message(s) imported`
              : "No new replies",
          className: "bg-emerald-600 text-white border-none shadow-xl",
        });
        if (result.updatedRfi) setRfi(result.updatedRfi);
        loadAll();
        onRfiUpdated();
      } else {
        toast({
          title: "Sync failed",
          description: result.errorMessage ?? undefined,
          variant: "destructive",
        });
      }
    } catch (err) {
      toast({
        title: "Sync failed",
        description: getErrorMessage(err),
        variant: "destructive",
      });
    } finally {
      setSyncing(false);
    }
  };

  // Optimistic: the control moves immediately, and snaps back with an error toast
  // if the server rejects it (e.g. 403 for someone who isn't on the To/CC list).
  const handlePriorityChange = async (next: RfiPriority) => {
    if (!projectName || !rfi || savingPriority) return;
    const previous = toRfiPriority(rfi.priority);
    if (next === previous) return;

    setRfi({ ...rfi, priority: next });
    setSavingPriority(true);
    try {
      const updated = await updateRfiPriority(projectName, rfi.id, next);
      setRfi(updated);
      toast({
        title: `Priority set to ${PRIORITY_LABELS[next]}`,
        className: "bg-emerald-600 text-white border-none shadow-xl",
      });
      onRfiUpdated(); // refresh the list so its Priority column matches
    } catch (err) {
      setRfi((current) => (current ? { ...current, priority: previous } : current));
      toast({
        title: "Couldn't change priority",
        description: getErrorMessage(err),
        variant: "destructive",
      });
    } finally {
      setSavingPriority(false);
    }
  };

  const handleDownload = async () => {
    if (!rfi) return;
    try {
      await downloadAttachment(rfi.attachment.id, rfi.attachment.originalName);
    } catch (err) {
      toast({
        title: "Download failed",
        description: getErrorMessage(err),
        variant: "destructive",
      });
      throw err;
    }
  };

  const handleCopyCc = () => {
    if (rfi?.ccEmails) {
      navigator.clipboard.writeText(rfi.ccEmails);
      setCopiedCc(true);
      toast({
        title: "CC addresses copied to clipboard",
        className: "bg-emerald-600 text-white border-none shadow-xl",
      });
      setTimeout(() => setCopiedCc(false), 2000);
    }
  };

  const handleCopyRecipient = () => {
    if (rfi?.recipientEmail) {
      navigator.clipboard.writeText(rfi.recipientEmail);
      setCopiedRecipient(true);
      toast({
        title: "Recipient email copied to clipboard",
        className: "bg-emerald-600 text-white border-none shadow-xl",
      });
      setTimeout(() => setCopiedRecipient(false), 2000);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex flex-wrap items-center gap-2 text-sm">
            {rfi ? rfi.rfiNumber : "RFI Details"}
            {rfi && <StatusBadge status={rfi.status} />}
          </DialogTitle>
          <DialogDescription className="text-xs">{rfi?.subject}</DialogDescription>
        </DialogHeader>

        {loading || !rfi ? (
          <p className="py-8 text-center text-xs text-muted-foreground">Loading...</p>
        ) : (
          <div className="space-y-4">
            {/* Info grid */}
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              <Field label="Discipline" value={rfi.discipline} />
              <Field label="Team Type" value={rfi.teamType} />
              <div className="col-span-2 space-y-1 sm:col-span-3">
                <div className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground">
                  Priority
                </div>
                <RfiPrioritySelector
                  value={toRfiPriority(rfi.priority)}
                  onChange={handlePriorityChange}
                  // View-only participants can see the priority but not change it.
                  disabled={savingPriority || rfi.canModify === false}
                  size="md"
                  ariaLabel="RFI priority"
                />
              </div>
              <Field
                label="Created"
                value={format(new Date(rfi.createdAt), "dd MMM yyyy, HH:mm")}
              />
              <Field
                label="Sender"
                value={
                  <span className="flex items-center gap-1">
                    <User className="h-3 w-3 text-muted-foreground" />
                    {rfi.senderName || rfi.senderEmail || "—"}
                  </span>
                }
              />
              <Field
                label="Receiver"
                value={
                  <div className="flex items-center gap-2">
                    <span className="flex items-center gap-1">
                      <Mail className="h-3 w-3 text-muted-foreground" />
                      {rfi.recipientEmail}
                    </span>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="h-4 w-4 shrink-0"
                      title="Copy recipient email"
                      onClick={handleCopyRecipient}
                    >
                      {copiedRecipient ? (
                        <Check className="h-3 w-3 text-emerald-600" />
                      ) : (
                        <Copy className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                      )}
                    </Button>
                  </div>
                }
              />
              <Field
                label="CC Addresses"
                value={
                  rfi.ccEmails ? (
                    <div className="flex items-center gap-2">
                      <span className="flex items-center gap-1 break-words">
                        <Mail className="h-3 w-3 text-muted-foreground shrink-0" />
                        {rfi.ccEmails}
                      </span>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="h-4 w-4 shrink-0"
                        title="Copy CC addresses"
                        onClick={handleCopyCc}
                      >
                        {copiedCc ? (
                          <Check className="h-3 w-3 text-emerald-600" />
                        ) : (
                          <Copy className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                        )}
                      </Button>
                    </div>
                  ) : (
                    "None"
                  )
                }
              />
              <Field
                label="Response Received"
                value={
                  rfi.responseReceivedAt
                    ? format(new Date(rfi.responseReceivedAt), "dd MMM yyyy, HH:mm")
                    : "Not yet"
                }
              />
            </div>

            {rfi.responseNotes && (
              <Field label="Response Notes" value={rfi.responseNotes} />
            )}

            {/* Attachment row */}
            <div className="flex items-center gap-2 rounded-md border border-border/70 bg-muted/20 px-2.5 py-1.5">
              <span className="min-w-0 flex-1 truncate text-xs text-foreground">
                {rfi.attachment.originalName}
              </span>

              <div className="flex shrink-0 items-center gap-1.5">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="group h-7 w-7"
                  title="Preview"
                  onClick={() =>
                    previewAttachment(
                      rfi.attachment.id,
                      rfi.attachment.originalName
                    )
                  }
                >
                  <AnimatedEyeIcon className="h-3.5 w-3.5" />
                </Button>

                <DownloadProgressButton
                  title="Download"
                  width={92}
                  height={28}
                  onDownload={handleDownload}
                />
              </div>
            </div>

            {/* Communication history */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                  Communication History
                </div>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  className="h-6 gap-1 text-[10px]"
                  disabled={syncing}
                  onClick={handleSync}
                  onMouseEnter={() => setCheckRepliesHovered(true)}
                  onMouseLeave={() => setCheckRepliesHovered(false)}
                  title="Check Gmail for new replies in this RFI's thread"
                >
                  <AnimatedCheckRepliesIcon
                    size="sm"
                    isParentHovered={checkRepliesHovered && !syncing}
                    disabled={syncing}
                    forceWhite={isDarkMode}
                    className={syncing ? "animate-spin" : ""}
                  />
                  {syncing ? "Checking..." : "Check for Replies"}
                </Button>
              </div>
              <RfiTimeline events={history} loading={false} />
            </div>
            <Separator />

            {/* Status control */}
            <div className="space-y-1.5">
              <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                Status Actions
              </div>
              <RfiStatusActions
                projectName={projectName!}
                rfi={rfi}
                onChanged={(updated) => {
                  setRfi(updated);
                  loadAll();
                  onRfiUpdated();
                }}
              />
            </div>

            <Separator />

            {/* Bottom close button */}
            <DialogFooter>
              <DialogClose asChild>
                <Button type="button" variant="outline" size="sm" className="h-7 text-[11px]">
                  Close
                </Button>
              </DialogClose>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};