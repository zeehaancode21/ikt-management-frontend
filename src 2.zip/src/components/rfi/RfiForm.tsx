// import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
// import { Button } from "@/components/ui/button";
// import { Input } from "@/components/ui/input";
// import { Label } from "@/components/ui/label";
// import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
// import { Checkbox } from "@/components/ui/checkbox";
// import { Badge } from "@/components/ui/badge";
// import { toast } from "@/hooks/use-toast";
// import { Textarea } from "@/components/ui/textarea";
// import {
//   Send,
//   X,
//   Check,
//   FileCheck,
//   CheckCircle2,
//   AlertCircle,
//   Pencil,
//   RotateCcw,
//   Loader2,
//   Star,
//   ChevronDown,
//   Plus,
// } from "lucide-react";
// import { AnimatedUploadIcon } from "@/components/icons/AnimatedUploadIcon";
// import { AnimatedChecklistIcon } from "@/components/icons/Animatedchecklisticon";
// import { GlassSelect, type GlassSelectOption } from "@/components/GlassSelect";
// import {
//   DEFAULT_RFI_PRIORITY,
//   RFI_DISCIPLINES,
//   RFI_TEAM_TYPES,
//   type RfiDiscipline,
//   type RfiEmailContact,
//   type RfiPriority,
//   type RfiTeamType,
// } from "@/types/rfi";
// import {
//   createRfi,
//   getEmployees,
//   getErrorMessage,
//   getFavoriteRfiEmailContacts,
//   previewRfiEmail,
//   type EmployeeOption,
// } from "@/lib/rfiApi";
// import { useAuth } from "@/context/AuthContext";
// import {
//   getDisciplineTheme,
//   getDisciplineIcon,
//   getTeamTypeTheme,
//   getTeamTypeIcon,
//   getPriorityTheme,
//   PRIORITY_DESCRIPTIONS,
//   PRIORITY_LABELS,
//   RfiCircleIcon,
// } from "@/lib/Rfivisuals";

// // ─────────────────────────────────────────────────────────────────────
// // Types & Constants
// // ─────────────────────────────────────────────────────────────────────

// type SendState = "idle" | "sending" | "success" | "error";

// interface Props {
//   projectName: string | null;
//   initialRecipientEmail: string;
//   initialCcEmails?: string;
//   onSent: () => void;
// }

// const DEFAULT_DISCIPLINE: RfiDiscipline =
//   (RFI_DISCIPLINES.find((d) => d.toLowerCase().includes("structural")) ??
//     RFI_DISCIPLINES[0]) as RfiDiscipline;

// const CONFETTI_COLORS = ["#10b981", "#34d399", "#38bdf8", "#a78bfa"];
// const CONFETTI_PIECES = Array.from({ length: 10 }, (_, i) => ({
//   angle: (360 / 10) * i,
//   color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
//   delay: (i % 3) * 40,
//   distance: 30 + (i % 4) * 6,
// }));

// const LABEL_CLASS = "text-[11px] font-semibold tracking-wide text-muted-foreground";
// const FIELD_CLASS =
//   "h-10 rounded-xl rfi-bd bg-background/60 text-[13px] transition-colors focus-visible:bg-background";
// const BARE_INPUT_CLASS =
//   "h-9 flex-1 border-0 bg-transparent px-0 text-[13px] shadow-none focus-visible:ring-0 focus-visible:ring-offset-0";
// const GHOST_BTN_CLASS =
//   "flex shrink-0 items-center gap-1 whitespace-nowrap rounded-md px-2 py-1 text-[11px] font-semibold text-muted-foreground [&>svg]:shrink-0 transition-colors hover:bg-accent/60 hover:text-foreground disabled:pointer-events-none disabled:opacity-50";
// const OUTLINE_BTN_CLASS =
//   "flex shrink-0 items-center gap-1 whitespace-nowrap rounded-md border rfi-bd bg-background/60 px-2.5 py-1 text-[11px] font-semibold text-muted-foreground transition-colors hover:border-primary/40 hover:bg-accent/50 hover:text-foreground disabled:pointer-events-none disabled:opacity-50 [&>svg]:shrink-0";

// const SHAKE_KEYFRAMES: Keyframe[] = [
//   { transform: "translateX(0)" },
//   { transform: "translateX(-6px)" },
//   { transform: "translateX(5px)" },
//   { transform: "translateX(-4px)" },
//   { transform: "translateX(2px)" },
//   { transform: "translateX(0)" },
// ];

// const RFI_STYLES = `
//   /* ── Visible borders + polish ── */
//   .rfi-root { --rfi-border: hsl(var(--foreground) / 0.28); --rfi-border-hover: hsl(var(--primary) / 0.7); }
//   .dark .rfi-root { --rfi-border: hsl(var(--foreground) / 0.38); }
//   .rfi-bd { border-color: var(--rfi-border); }
//   .rfi-bd:hover { border-color: var(--rfi-border-hover); }

//   .rfi-form-card {
//     border-width: 1.5px;
//     border-color: hsl(var(--primary) / 0.45);
//     animation: rfi-form-in 300ms cubic-bezier(0.16, 1, 0.3, 1) both, rfi-card-glow 4s ease-in-out 400ms infinite;
//   }
//   .rfi-form-card:hover { border-color: hsl(var(--primary) / 0.45); }
//   @keyframes rfi-card-glow {
//     0%, 100% { box-shadow: 0 0 0 4px hsl(var(--primary) / 0.05), 0 18px 40px -18px hsl(var(--primary) / 0.30); }
//     50%      { box-shadow: 0 0 0 5px hsl(var(--primary) / 0.10), 0 22px 46px -16px hsl(var(--primary) / 0.50); }
//   }

//   .rfi-panel, .rfi-header-to { border-width: 1.5px; }
//   .rfi-panel { background: hsl(var(--background) / 0.85); transition: border-color 180ms ease, box-shadow 180ms ease, transform 180ms ease; }
//   .rfi-panel:hover { transform: translateY(-1px); box-shadow: 0 6px 16px -10px hsl(var(--primary) / 0.45); }
//   .rfi-header-to { border-color: hsl(var(--primary) / 0.5); background: hsl(var(--primary) / 0.08); }

//   .rfi-root input, .rfi-root textarea { transition: border-color 180ms ease, box-shadow 180ms ease, background-color 180ms ease; }
//   .rfi-root input:focus-visible, .rfi-root textarea:focus-visible {
//     border-color: hsl(var(--primary)); box-shadow: 0 0 0 3px hsl(var(--primary) / 0.15);
//   }
//   .rfi-drop { border-width: 2px; border-color: hsl(var(--primary) / 0.45); background: hsl(var(--primary) / 0.04); }
//   .rfi-drop:hover { border-color: hsl(var(--primary)); background: hsl(var(--primary) / 0.09); transform: translateY(-1px); }
//   .rfi-drag-active { border-color: hsl(var(--primary)); box-shadow: 0 0 0 4px hsl(var(--primary) / 0.15); animation: rfi-drop-pulse 1s ease-in-out infinite; }
//   @keyframes rfi-drop-pulse { 0%,100% { transform: scale(1); } 50% { transform: scale(1.015); } }

//   @keyframes rfi-section-in {
//     0%   { opacity: 0; transform: translateY(10px); }
//     100% { opacity: 1; transform: translateY(0); }
//   }
//   .rfi-stagger > div > * { animation: rfi-section-in 420ms cubic-bezier(0.16, 1, 0.3, 1) both; }
//   .rfi-stagger > div > *:nth-child(1) { animation-delay: 80ms; }
//   .rfi-stagger > div > *:nth-child(2) { animation-delay: 150ms; }
//   .rfi-stagger > div > *:nth-child(3) { animation-delay: 220ms; }
//   .rfi-stagger > div > *:nth-child(4) { animation-delay: 290ms; }

//   @media (prefers-reduced-motion: reduce) {
//     .rfi-form-card, .rfi-stagger > div > *, .rfi-drag-active { animation: none !important; }
//   }

//   .rfi-root { container-type: inline-size; container-name: rfi; width: 100%; height: 100%; min-height: 0; }
//   .rfi-scroll { scrollbar-width: thin; scrollbar-color: hsl(var(--border)) transparent; }

//   .rfi-cols {
//     display: grid;
//     grid-template-columns: minmax(0, 1fr);
//     gap: 0.75rem 1.25rem;
//     align-content: start;
//   }
//   @container rfi (min-width: 820px) {
//     .rfi-cols { grid-template-columns: minmax(0, 8fr) minmax(0, 5fr); }
//   }
//   @container rfi (max-width: 640px) {
//     .rfi-subtitle { display: none; }
//   }

//   @keyframes rfi-pop {
//     0%   { transform: scale(0.8); opacity: 0; }
//     100% { transform: scale(1); opacity: 1; }
//   }
//   .animate-rfi-pop { animation: rfi-pop 180ms cubic-bezier(0.34, 1.56, 0.64, 1) both; }

//   @keyframes rfi-form-in {
//     0%   { opacity: 0; transform: translateY(8px); }
//     100% { opacity: 1; transform: translateY(0); }
//   }
//   .rfi-form-enter { animation: rfi-form-in 300ms cubic-bezier(0.16, 1, 0.3, 1) both; }

//   @keyframes rfi-line-in {
//     0%   { transform: scaleX(0); }
//     100% { transform: scaleX(1); }
//   }
//   .rfi-header-bar {
//     height: 2px;
//     transform-origin: left;
//     background: linear-gradient(90deg, hsl(var(--primary)), hsl(var(--primary) / 0.05));
//     animation: rfi-line-in 600ms cubic-bezier(0.16, 1, 0.3, 1) both;
//   }

//   .rfi-drop { transition: border-color 180ms ease, background-color 180ms ease; }
//   .rfi-drag-active {
//     border-color: hsl(var(--primary));
//     background: hsl(var(--primary) / 0.08);
//   }

//   .rfi-panel { transition: border-color 180ms ease, box-shadow 180ms ease; }
//   .rfi-panel:focus-within {
//     border-color: hsl(var(--primary) / 0.45);
//     box-shadow: 0 0 0 3px hsl(var(--primary) / 0.08);
//   }

//   /* ── Header "To" field — inline with the title ── */
//   .rfi-header-to {
//     display: flex;
//     align-items: center;
//     gap: 0.5rem;
//     flex: 1 1 auto;
//     min-width: 0;
//     height: 34px;
//     padding: 0 0.5rem 0 0.75rem;
//     border-radius: 10px;
//     background: hsl(var(--primary) / 0.06);
//     border: 1px solid hsl(var(--primary) / 0.18);
//     transition: border-color 150ms ease, background-color 150ms ease, box-shadow 150ms ease;
//   }
//   .rfi-header-to:focus-within {
//     border-color: hsl(var(--primary) / 0.45);
//     background: hsl(var(--primary) / 0.08);
//     box-shadow: 0 0 0 3px hsl(var(--primary) / 0.08);
//   }
//   .rfi-header-to-label {
//     font-size: 10px;
//     font-weight: 700;
//     letter-spacing: 0.06em;
//     text-transform: uppercase;
//     color: hsl(var(--primary));
//     opacity: 0.75;
//     flex-shrink: 0;
//   }
//   .rfi-header-to-input {
//     flex: 1 1 auto;
//     min-width: 0;
//     height: 100%;
//     border: 0;
//     background: transparent;
//     font-size: 12.5px;
//     font-weight: 600;
//     color: hsl(var(--foreground));
//     outline: none;
//   }
//   .rfi-header-to-input::placeholder {
//     color: hsl(var(--muted-foreground) / 0.7);
//     font-weight: 500;
//   }
//   .rfi-header-to-input:disabled {
//     opacity: 0.6;
//     cursor: not-allowed;
//   }
//   .rfi-header-to-star {
//     display: flex;
//     align-items: center;
//     justify-content: center;
//     flex-shrink: 0;
//     height: 22px;
//     width: 22px;
//     border-radius: 9999px;
//     background: transparent;
//     transition: background-color 150ms ease;
//   }
//   .rfi-header-to-star:hover:not(:disabled) {
//     background: hsl(var(--primary) / 0.12);
//   }
//   .rfi-header-to-star:disabled {
//     opacity: 0.5;
//     cursor: not-allowed;
//   }

//   /* ── Resizable divider between body and attachment panel ── */
//   .rfi-resize-handle {
//     width: 6px;
//     cursor: col-resize;
//     background: transparent;
//     position: relative;
//     flex-shrink: 0;
//     transition: background-color 150ms ease;
//   }
//   .rfi-resize-handle::before {
//     content: "";
//     position: absolute;
//     top: 50%;
//     left: 50%;
//     transform: translate(-50%, -50%);
//     width: 2px;
//     height: 32px;
//     border-radius: 9999px;
//     background: hsl(var(--border));
//     transition: background-color 150ms ease, height 150ms ease;
//   }
//   .rfi-resize-handle:hover::before,
//   .rfi-resize-handle[data-resizing="true"]::before {
//     background: hsl(var(--primary));
//     height: 48px;
//   }

//   /* ── Side-by-side body + attachment panel ── */
//   .rfi-compose-row {
//     display: flex;
//     flex-direction: column;
//     gap: 0.75rem;
//     align-items: stretch;
//     width: 100%;
//   }
//   @container rfi (min-width: 640px) {
//     .rfi-compose-row {
//       flex-direction: row;
//       align-items: stretch;
//       gap: 0;
//     }
//   }

//   .rfi-compose-body {
//     display: flex;
//     flex-direction: column;
//     gap: 0.5rem;
//     min-width: 0;
//     flex: 1 1 auto;
//     container-type: inline-size;
//     container-name: rfibody;
//   }

//   /* Header buttons: when the body column gets narrow, show icon only
//      (never wrap, never force the page to scroll). */
//   @container rfibody (max-width: 250px) {
//     .rfi-btn-text { display: none; }
//   }

//   .rfi-attach-panel {
//     display: flex;
//     flex-direction: column;
//     gap: 0.5rem;
//     width: 100%;
//     flex-shrink: 0;
//   }
//   @container rfi (min-width: 640px) {
//     .rfi-attach-panel {
//       width: var(--rfi-attach-width, 220px);
//       min-width: 170px;
//       max-width: 380px;
//       padding-left: 0.75rem;
//       justify-content: flex-start;
//     }
//   }

//   /* Compact body box height — keeps body and attachment visually balanced */
//   .rfi-body-box {
//     position: relative;
//     min-height: 96px;
//     max-height: 160px;
//   }

//   /* ── Send button ── */
//   .rfi-send {
//     position: relative;
//     isolation: isolate;
//     overflow: hidden;
//     background: linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--primary) / 0.82) 100%);
//     transition: box-shadow 200ms ease, transform 150ms ease, filter 200ms ease;
//   }
//   .rfi-send:hover:not(:disabled) {
//     filter: brightness(1.07);
//     box-shadow: 0 8px 20px -6px hsl(var(--primary) / 0.55);
//     transform: translateY(-1px);
//   }
//   .rfi-send:active:not(:disabled) { transform: scale(0.98); }
//   .rfi-send-plane { transition: transform 200ms cubic-bezier(0.34, 1.56, 0.64, 1); }
//   .rfi-send:hover:not(:disabled) .rfi-send-plane { transform: translate(3px, -1px) rotate(-10deg); }

//   .rfi-send-overlay {
//     position: absolute;
//     inset: 0;
//     border-radius: inherit;
//     opacity: 0;
//     transition: opacity 250ms ease;
//     pointer-events: none;
//   }
//   .rfi-send-overlay-success { background: linear-gradient(135deg, #059669, #10b981 55%, #34d399); opacity: 1; }
//   .rfi-send-overlay-error   { background: linear-gradient(135deg, #b91c1c, #ef4444 55%, #f87171); opacity: 1; }

//   @keyframes rfi-launch-ring {
//     0%   { transform: scale(0.7); opacity: 0.5; }
//     100% { transform: scale(1.7); opacity: 0; }
//   }
//   .rfi-launch-ring {
//     position: absolute;
//     inset: 0;
//     border-radius: inherit;
//     border: 2px solid rgba(255, 255, 255, 0.7);
//     animation: rfi-launch-ring 600ms ease-out forwards;
//     pointer-events: none;
//   }

//   @keyframes rfi-plane-fly {
//     0%   { transform: translateX(-4px) rotate(-8deg); opacity: 0; }
//     20%  { opacity: 1; }
//     80%  { opacity: 1; }
//     100% { transform: translateX(22px) rotate(-8deg); opacity: 0; }
//   }
//   .rfi-launch-track { position: relative; display: inline-block; width: 26px; height: 16px; }
//   .rfi-launch-plane {
//     position: absolute;
//     top: 0;
//     left: 0;
//     animation: rfi-plane-fly 1s cubic-bezier(0.45, 0, 0.55, 1) infinite;
//   }

//   @keyframes rfi-dot-bounce {
//     0%, 80%, 100% { opacity: 0.25; }
//     40%           { opacity: 1; }
//   }
//   .rfi-dot { display: inline-block; animation: rfi-dot-bounce 1.2s ease-in-out infinite; }
//   .rfi-dot:nth-of-type(2) { animation-delay: 150ms; }
//   .rfi-dot:nth-of-type(3) { animation-delay: 300ms; }

//   @keyframes rfi-confetti {
//     0%   { transform: translate(-50%, -50%) rotate(var(--angle)) translateY(0) scale(1); opacity: 1; }
//     100% { transform: translate(-50%, -50%) rotate(var(--angle)) translateY(calc(-1 * var(--dist))) scale(0); opacity: 0; }
//   }
//   .rfi-confetti-dot {
//     position: absolute;
//     top: 50%;
//     left: 50%;
//     width: 5px;
//     height: 5px;
//     border-radius: 9999px;
//     background: var(--dot-color);
//     animation: rfi-confetti 650ms ease-out forwards;
//     animation-delay: var(--delay);
//     pointer-events: none;
//   }

//   @media (prefers-reduced-motion: reduce) {
//     .rfi-form-enter, .rfi-header-bar, .animate-rfi-pop, .rfi-launch-ring,
//     .rfi-launch-plane, .rfi-dot, .rfi-confetti-dot { animation: none !important; }
//     .rfi-send, .rfi-send-plane, .rfi-panel { transition: none !important; }
//     .rfi-confetti-dot { display: none; }
//   }
// `;

// // ─────────────────────────────────────────────────────────────────────
// // Helper Functions
// // ─────────────────────────────────────────────────────────────────────

// function formatDisplayName(username: string): string {
//   if (!username) return "";
//   return username
//     .replace(/([A-Z])/g, " $1")
//     .replace(/_/g, " ")
//     .trim()
//     .split(" ")
//     .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
//     .join(" ");
// }

// function parseEmailList(raw: string | undefined): string[] {
//   return (raw ?? "")
//     .split(/[,;]/)
//     .map((e) => e.trim())
//     .filter(Boolean);
// }

// // ─────────────────────────────────────────────────────────────────────
// // Component
// // ─────────────────────────────────────────────────────────────────────

// export const RfiForm = ({ projectName, initialRecipientEmail, initialCcEmails, onSent }: Props) => {
//   const { name: authName } = useAuth();

//   // ── Form State ──────────────────────────────────────────────────────
//   const [discipline, setDiscipline] = useState<RfiDiscipline>(DEFAULT_DISCIPLINE);
//   const [teamType, setTeamType] = useState<RfiTeamType>("EXTERNAL");
//   const [priority, setPriority] = useState<RfiPriority>(DEFAULT_RFI_PRIORITY);
//   const [subject, setSubject] = useState("");
//   const [file, setFile] = useState<File | null>(null);
//   const [isDragging, setIsDragging] = useState(false);
//   const [recipientEmail, setRecipientEmail] = useState(initialRecipientEmail);
//   const [employees, setEmployees] = useState<EmployeeOption[]>([]);

//   // ── Email Body State ────────────────────────────────────────────────
//   const [emailBody, setEmailBody] = useState("");
//   const [emailBodyDraft, setEmailBodyDraft] = useState("");
//   const [isEditingBody, setIsEditingBody] = useState(false);
//   const [isBodyCustomized, setIsBodyCustomized] = useState(false);
//   const [isBodyPreviewLoading, setIsBodyPreviewLoading] = useState(false);

//   // ── CC & Recipient Picker State ─────────────────────────────────────
//   const [favoriteToContacts, setFavoriteToContacts] = useState<RfiEmailContact[]>([]);
//   const [favoriteCcContacts, setFavoriteCcContacts] = useState<RfiEmailContact[]>([]);
//   const [ccPickerTab, setCcPickerTab] = useState<"favorites" | "employees">("favorites");
//   const [ccEmails, setCcEmails] = useState<string[]>(() => parseEmailList(initialCcEmails));
//   const [ccInput, setCcInput] = useState("");
//   const [isToPickerOpen, setIsToPickerOpen] = useState(false);
//   const [isCcPickerOpen, setIsCcPickerOpen] = useState(false);

//   // ── Send State & UI ─────────────────────────────────────────────────
//   const [sendState, setSendState] = useState<SendState>("idle");
//   const [launchKey, setLaunchKey] = useState(0);
//   const [isHeaderHovered, setIsHeaderHovered] = useState(false);
//   const [isUploadHovered, setIsUploadHovered] = useState(false);

//   // ── Attachment panel resize state ───────────────────────────────────
//   const [attachWidth, setAttachWidth] = useState(220);
//   const [isResizing, setIsResizing] = useState(false);
//   const composeRowRef = useRef<HTMLDivElement>(null);

//   // ── Refs ────────────────────────────────────────────────────────────
//   const fileInputRef = useRef<HTMLInputElement>(null);
//   const fieldsRef = useRef<HTMLDivElement>(null);
//   const successTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
//   const bodyPreviewTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
//   const bodyLoadedRef = useRef(false);
//   const previewRequestRef = useRef(0);

//   // ── Computed Values ─────────────────────────────────────────────────
//   const currentEmployee = useMemo(() => {
//     if (!authName || employees.length === 0) return null;
//     const normalized = authName.trim().toLowerCase();
//     return (
//       employees.find((e) => e.username.trim().toLowerCase() === normalized) ??
//       employees.find((e) => formatDisplayName(e.username).trim().toLowerCase() === normalized) ??
//       employees.find((e) => normalized.includes(e.username.trim().toLowerCase())) ??
//       null
//     );
//   }, [authName, employees]);

//   const isBusy = sendState === "sending" || sendState === "success";

//   const disciplineOptions = useMemo<GlassSelectOption<RfiDiscipline>[]>(
//     () =>
//       RFI_DISCIPLINES.map((d) => {
//         const Icon = getDisciplineIcon(d);
//         const theme = getDisciplineTheme(d);
//         return {
//           value: d as RfiDiscipline,
//           label: d,
//           accent: theme.accent,
//           leading: <RfiCircleIcon icon={Icon} theme={theme} size={18} filled />,
//         };
//       }),
//     []
//   );

//   const teamOptions = useMemo<GlassSelectOption<RfiTeamType>[]>(
//     () =>
//       RFI_TEAM_TYPES.map((type) => {
//         const Icon = getTeamTypeIcon(type);
//         const theme = getTeamTypeTheme(type);
//         return {
//           value: type,
//           label: type === "INTERNAL" ? "Internal" : "External",
//           accent: theme.accent,
//           leading: <RfiCircleIcon icon={Icon} theme={theme} size={18} filled />,
//         };
//       }),
//     []
//   );

//   const priorityOptions = useMemo<GlassSelectOption<RfiPriority>[]>(
//     () =>
//       (Object.keys(PRIORITY_LABELS) as RfiPriority[]).map((p) => {
//         const theme = getPriorityTheme(p);
//         return {
//           value: p,
//           label: PRIORITY_LABELS[p],
//           accent: theme.accent,
//           title: PRIORITY_DESCRIPTIONS[p],
//           leading: (
//             <span
//               className="h-2.5 w-2.5 shrink-0 rounded-full"
//               style={{ backgroundColor: theme.accent, boxShadow: `0 0 8px ${theme.accent}` }}
//               aria-hidden
//             />
//           ),
//         };
//       }),
//     []
//   );

//   // ── Effects ─────────────────────────────────────────────────────────

//   useEffect(() => {
//     getEmployees()
//       .then(setEmployees)
//       .catch((err) =>
//         toast({
//           title: "Failed to load sender list",
//           description: getErrorMessage(err),
//           variant: "destructive",
//         })
//       );
//   }, []);

//   useEffect(() => {
//     getFavoriteRfiEmailContacts("TO")
//       .then(setFavoriteToContacts)
//       .catch((err) =>
//         toast({
//           title: "Failed to load favorite Send To addresses",
//           description: getErrorMessage(err),
//           variant: "destructive",
//         })
//       );
//     getFavoriteRfiEmailContacts("CC")
//       .then(setFavoriteCcContacts)
//       .catch((err) =>
//         toast({
//           title: "Failed to load favorite CC addresses",
//           description: getErrorMessage(err),
//           variant: "destructive",
//         })
//       );
//   }, []);

//   useEffect(() => {
//     setRecipientEmail(initialRecipientEmail);
//   }, [initialRecipientEmail]);

//   useEffect(() => {
//     setCcEmails(parseEmailList(initialCcEmails));
//   }, [initialCcEmails]);

//   useEffect(() => {
//     if (!projectName || isBodyCustomized || isEditingBody) return;

//     if (bodyPreviewTimerRef.current) clearTimeout(bodyPreviewTimerRef.current);
//     const delay = bodyLoadedRef.current ? 400 : 0;
//     bodyPreviewTimerRef.current = setTimeout(() => {
//       const requestId = ++previewRequestRef.current;
//       setIsBodyPreviewLoading(true);
//       previewRfiEmail(projectName, subject)
//         .then((preview) => {
//           if (requestId !== previewRequestRef.current) return;
//           bodyLoadedRef.current = true;
//           setEmailBody(preview.emailBody);
//         })
//         .catch((err) => {
//           console.error("Failed to load default RFI email body:", getErrorMessage(err));
//         })
//         .finally(() => {
//           if (requestId === previewRequestRef.current) setIsBodyPreviewLoading(false);
//         });
//     }, delay);

//     return () => {
//       if (bodyPreviewTimerRef.current) clearTimeout(bodyPreviewTimerRef.current);
//     };
//   }, [projectName, subject, isBodyCustomized, isEditingBody]);

//   useEffect(() => {
//     setIsUploadHovered(false);
//   }, [file]);

//   useEffect(() => {
//     return () => {
//       if (successTimerRef.current) clearTimeout(successTimerRef.current);
//       if (bodyPreviewTimerRef.current) clearTimeout(bodyPreviewTimerRef.current);
//     };
//   }, []);

//   // ── Attachment panel resize handlers ────────────────────────────────
//   useEffect(() => {
//     if (!isResizing) return;

//     const handleMouseMove = (e: MouseEvent) => {
//       if (!composeRowRef.current) return;
//       const rect = composeRowRef.current.getBoundingClientRect();
//       const newWidth = rect.right - e.clientX;
//       setAttachWidth(Math.min(380, Math.max(170, newWidth)));
//     };

//     const handleMouseUp = () => {
//       setIsResizing(false);
//       document.body.style.cursor = "";
//       document.body.style.userSelect = "";
//     };

//     document.body.style.cursor = "col-resize";
//     document.body.style.userSelect = "none";
//     window.addEventListener("mousemove", handleMouseMove);
//     window.addEventListener("mouseup", handleMouseUp);

//     return () => {
//       window.removeEventListener("mousemove", handleMouseMove);
//       window.removeEventListener("mouseup", handleMouseUp);
//       document.body.style.cursor = "";
//       document.body.style.userSelect = "";
//     };
//   }, [isResizing]);

//   // ── Event Handlers ──────────────────────────────────────────────────

//   const startEditingBody = () => {
//     setEmailBodyDraft(emailBody);
//     setIsEditingBody(true);
//   };

//   const saveBodyEdit = () => {
//     setEmailBody(emailBodyDraft);
//     setIsBodyCustomized(true);
//     setIsEditingBody(false);
//   };

//   const cancelBodyEdit = () => setIsEditingBody(false);

//   const resetBodyToDefault = () => {
//     setIsBodyCustomized(false);
//     setIsEditingBody(false);
//     if (!projectName) return;
//     const requestId = ++previewRequestRef.current;
//     setIsBodyPreviewLoading(true);
//     previewRfiEmail(projectName, subject)
//       .then((preview) => {
//         if (requestId === previewRequestRef.current) setEmailBody(preview.emailBody);
//       })
//       .catch(() => undefined)
//       .finally(() => {
//         if (requestId === previewRequestRef.current) setIsBodyPreviewLoading(false);
//       });
//   };

//   const addCcEmail = (raw: string) => {
//     const trimmed = raw.trim();
//     if (!trimmed) return;
//     setCcEmails((prev) => (prev.some((c) => c.toLowerCase() === trimmed.toLowerCase()) ? prev : [...prev, trimmed]));
//     setCcInput("");
//   };

//   const removeCcEmail = (email: string) =>
//     setCcEmails((prev) => prev.filter((c) => c.toLowerCase() !== email.toLowerCase()));

//   const toggleCcFavorite = (email: string) =>
//     setCcEmails((prev) =>
//       prev.some((c) => c.toLowerCase() === email.toLowerCase())
//         ? prev.filter((c) => c.toLowerCase() !== email.toLowerCase())
//         : [...prev, email]
//     );

//   const handleCcPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
//     const text = e.clipboardData.getData("text");
//     if (!/[,;\s]/.test(text.trim())) return;
//     e.preventDefault();
//     text
//       .split(/[,;\s]+/)
//       .map((t) => t.trim())
//       .filter(Boolean)
//       .forEach(addCcEmail);
//   };

//   const triggerShake = () => {
//     if (typeof window === "undefined") return;
//     if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;
//     fieldsRef.current?.animate(SHAKE_KEYFRAMES, { duration: 380, easing: "ease-out" });
//   };

//   const failValidation = (title: string) => {
//     triggerShake();
//     toast({ title, variant: "destructive" });
//   };

//   const acceptFile = (selected: File | null) => {
//     if (!selected) return setFile(null);
//     const isPdf = selected.type === "application/pdf" || selected.name.toLowerCase().endsWith(".pdf");
//     if (!isPdf) {
//       toast({
//         title: "Only PDF files are allowed",
//         description: `"${selected.name}" isn't a PDF.`,
//         variant: "destructive",
//       });
//       return;
//     }
//     setFile(selected);
//   };

//   const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) =>
//     acceptFile(e.target.files?.[0] ?? null);

//   const handleDrop = (e: React.DragEvent<HTMLLabelElement>) => {
//     e.preventDefault();
//     setIsDragging(false);
//     acceptFile(e.dataTransfer.files?.[0] ?? null);
//   };

//   const clearFile = () => {
//     setFile(null);
//     if (fileInputRef.current) fileInputRef.current.value = "";
//   };

//   const resetForm = () => {
//     setDiscipline(DEFAULT_DISCIPLINE);
//     setTeamType("EXTERNAL");
//     setPriority(DEFAULT_RFI_PRIORITY);
//     setSubject("");
//     setFile(null);
//     if (fileInputRef.current) fileInputRef.current.value = "";
//     setEmailBody("");
//     setEmailBodyDraft("");
//     setIsEditingBody(false);
//     setIsBodyCustomized(false);
//     setCcEmails([]);
//     setCcInput("");
//   };

//   const handleSubmit = async (e: React.FormEvent) => {
//     e.preventDefault();
//     if (sendState === "sending" || sendState === "success") return;
//     if (!projectName) return failValidation("Select a project first");
//     if (!discipline) return failValidation("Discipline is required");
//     if (!subject.trim()) return failValidation("Subject is required");
//     if (!file) return failValidation("A PDF attachment is required");
//     if (!recipientEmail.trim()) return failValidation("Recipient email is required");
//     if (!currentEmployee || !currentEmployee.email) {
//       return failValidation("Your account isn't linked to an employee email — contact an admin");
//     }

//     const senderEmail = currentEmployee.email;
//     const senderName = currentEmployee.username;
//     const finalEmailBody = isEditingBody ? emailBodyDraft : emailBody;

//     const pendingCc = ccInput.trim();
//     const ccEmailsToSend = Array.from(
//       new Map(
//         [...ccEmails, ...(pendingCc ? [pendingCc] : [])]
//           .map((c) => c.trim())
//           .filter(Boolean)
//           .map((c) => [c.toLowerCase(), c] as const)
//       ).values()
//     );

//     setLaunchKey((k) => k + 1);
//     setSendState("sending");
//     try {
//       const created = await createRfi(projectName, {
//         discipline,
//         teamType,
//         priority,
//         subject: subject.trim(),
//         emailBody: finalEmailBody.trim() ? finalEmailBody : undefined,
//         attachment: file,
//         senderEmail,
//         senderName: senderName ? formatDisplayName(senderName) : undefined,
//         recipientEmail: recipientEmail.trim(),
//         ccEmails: ccEmailsToSend,
//       });
//       toast({
//         title: `${created.rfiNumber} sent successfully!`,
//         description: `Emailed to ${created.recipientEmail}`,
//         className: "bg-emerald-600 text-white border-none shadow-xl",
//       });
//       setSendState("success");
//       if (successTimerRef.current) clearTimeout(successTimerRef.current);
//       successTimerRef.current = setTimeout(() => {
//         resetForm();
//         setSendState("idle");
//         onSent();
//       }, 1200);
//     } catch (err) {
//       triggerShake();
//       setSendState("error");
//       toast({
//         title: "Failed to send RFI",
//         description: getErrorMessage(err),
//         variant: "destructive",
//       });
//       if (successTimerRef.current) clearTimeout(successTimerRef.current);
//       successTimerRef.current = setTimeout(() => setSendState("idle"), 900);
//     }
//   };

//   // ─────────────────────────────────────────────────────────────────────
//   // Render
//   // ─────────────────────────────────────────────────────────────────────

//   return (
//     <div className="rfi-root">
//       <style>{RFI_STYLES}</style>

//       <form
//         onSubmit={handleSubmit}
//         className="rfi-form-enter rfi-form-card relative flex h-full max-h-full min-h-0 w-full flex-col overflow-hidden rounded-2xl border rfi-bd bg-gradient-to-b from-primary/[0.06] via-background/95 to-background/95 p-3 shadow-2xl shadow-black/10 backdrop-blur-xl sm:p-4"
//       >
//         {/* ───────────── Header ─────────────
//             Left: title + inline "To" address input.
//             Right: Submit button — always visible. */}
//         <div className="flex shrink-0 items-center justify-between gap-3">
//           <div
//             className="flex min-w-0 flex-1 cursor-default items-center gap-3"
//             onMouseEnter={() => setIsHeaderHovered(true)}
//             onMouseLeave={() => setIsHeaderHovered(false)}
//           >
//             <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 ring-1 ring-primary/15">
//               <AnimatedChecklistIcon
//                 size="md"
//                 className="text-primary"
//                 triggerParentHover
//                 isParentHovered={isHeaderHovered}
//               />
//             </span>

//             <div className="flex min-w-0 flex-1 flex-col gap-1.5">
//               <h2 className="text-base font-bold leading-tight tracking-tight text-foreground">New RFI</h2>

//               {/* Inline "To" address input — takes the full row width, gives the
//                   user plenty of space to type or paste an address. The star
//                   button opens the favorites picker. */}
//               <div className="rfi-header-to min-w-0 max-w-[520px]">
//                 <span className="rfi-header-to-label">
//                   To<span className="text-destructive">*</span>
//                 </span>
//                 <input
//                   id="rfi-recipient"
//                   type="email"
//                   value={recipientEmail}
//                   onChange={(e) => setRecipientEmail(e.target.value)}
//                   placeholder="reviewer@client.com — or pick a favorite"
//                   disabled={isBusy}
//                   className="rfi-header-to-input"
//                   aria-label="Recipient email"
//                 />
//                 <Popover open={isToPickerOpen} onOpenChange={setIsToPickerOpen}>
//                   <PopoverTrigger asChild>
//                     <button
//                       type="button"
//                       disabled={isBusy}
//                       title="Pick a Send To address"
//                       aria-label="Pick a Send To address"
//                       className="rfi-header-to-star"
//                     >
//                       <Star className="h-3.5 w-3.5 text-amber-500" />
//                     </button>
//                   </PopoverTrigger>
//                   <PopoverContent align="end" className="w-72 p-2">
//                     {favoriteToContacts.length === 0 ? (
//                       <p className="px-2 py-2.5 text-xs text-muted-foreground">
//                         No favorites yet — star a Send To address in RFI Settings, or just type a new one.
//                       </p>
//                     ) : (
//                       <ul className="rfi-scroll max-h-56 space-y-0.5 overflow-y-auto">
//                         {favoriteToContacts.map((c) => (
//                           <li key={c.email}>
//                             <button
//                               type="button"
//                               onClick={() => {
//                                 setRecipientEmail(c.email);
//                                 setIsToPickerOpen(false);
//                               }}
//                               className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-xs font-medium text-foreground transition-colors hover:bg-accent/60"
//                             >
//                               <Star className="h-3.5 w-3.5 shrink-0 fill-amber-400 text-amber-500" />
//                               <span className="truncate">{c.email}</span>
//                             </button>
//                           </li>
//                         ))}
//                       </ul>
//                     )}
//                   </PopoverContent>
//                 </Popover>
//               </div>
//             </div>
//           </div>

//           <Button
//             type="submit"
//             disabled={isBusy}
//             className="rfi-send h-10 min-w-[150px] shrink-0 rounded-xl px-5 text-sm font-bold tracking-wide text-white shadow-md disabled:opacity-100"
//           >
//             <span
//               className={`rfi-send-overlay ${
//                 sendState === "success"
//                   ? "rfi-send-overlay-success"
//                   : sendState === "error"
//                     ? "rfi-send-overlay-error"
//                     : ""
//               }`}
//               aria-hidden
//             />

//             {sendState === "sending" && <span key={`launch-${launchKey}`} className="rfi-launch-ring" aria-hidden />}

//             {sendState === "success" &&
//               CONFETTI_PIECES.map((p, i) => (
//                 <span
//                   key={i}
//                   className="rfi-confetti-dot"
//                   style={
//                     {
//                       "--angle": `${p.angle}deg`,
//                       "--dist": `${p.distance}px`,
//                       "--delay": `${p.delay}ms`,
//                       "--dot-color": p.color,
//                     } as CSSProperties
//                   }
//                 />
//               ))}

//             <span className="relative z-10 inline-flex items-center justify-center gap-2 whitespace-nowrap">
//               {sendState === "sending" && (
//                 <>
//                   <span className="rfi-launch-track" aria-hidden>
//                     <Send className="rfi-launch-plane h-4 w-4" />
//                   </span>
//                   <span>
//                     Sending
//                     <span className="rfi-dot">.</span>
//                     <span className="rfi-dot">.</span>
//                     <span className="rfi-dot">.</span>
//                   </span>
//                 </>
//               )}
//               {sendState === "success" && (
//                 <>
//                   <CheckCircle2 className="animate-rfi-pop h-4 w-4" />
//                   <span>Sent!</span>
//                 </>
//               )}
//               {sendState === "error" && (
//                 <>
//                   <AlertCircle className="animate-rfi-pop h-4 w-4" />
//                   <span>Try again</span>
//                 </>
//               )}
//               {sendState === "idle" && (
//                 <>
//                   <Send className="rfi-send-plane h-4 w-4" />
//                   <span>Submit RFI</span>
//                 </>
//               )}
//             </span>
//           </Button>
//         </div>

//         <div className="rfi-header-bar my-2 w-full shrink-0 rounded-full" />

//         {/* ───────────── Fields ───────────── */}
//         <div ref={fieldsRef} className="rfi-scroll rfi-cols rfi-stagger min-h-0 flex-1 overflow-y-auto overscroll-contain pb-4 pr-0.5">
//           {/* ───────────── LEFT COLUMN ───────────── */}
//           <div className="space-y-3">
//             {/* CC only — the To field now lives in the header above. */}
//             <section className="rfi-panel rounded-xl border rfi-bd bg-background/60">
//               <div className="flex items-start gap-2 px-3">
//                 <Label htmlFor="rfi-cc" className={`${LABEL_CLASS} w-7 shrink-0 pt-3.5`}>
//                   CC
//                 </Label>
//                 <div className="flex min-h-11 flex-1 flex-wrap items-center gap-1.5 py-1.5">
//                   {ccEmails.map((email) => (
//                     <Badge
//                       key={email}
//                       variant="secondary"
//                       className="flex items-center gap-1 rounded-full py-0.5 pl-2.5 pr-1 text-xs font-medium"
//                     >
//                       <span className="max-w-[180px] truncate">{email}</span>
//                       <button
//                         type="button"
//                         disabled={isBusy}
//                         onClick={() => removeCcEmail(email)}
//                         aria-label={`Remove ${email}`}
//                         className="rounded-full p-0.5 text-muted-foreground/70 transition-colors hover:bg-destructive/10 hover:text-destructive disabled:pointer-events-none"
//                       >
//                         <X className="h-3 w-3" />
//                       </button>
//                     </Badge>
//                   ))}
//                   <input
//                     id="rfi-cc"
//                     type="email"
//                     value={ccInput}
//                     onChange={(e) => setCcInput(e.target.value)}
//                     onPaste={handleCcPaste}
//                     onKeyDown={(e) => {
//                       if (e.key === "Enter" || e.key === "," || e.key === ";") {
//                         e.preventDefault();
//                         addCcEmail(ccInput);
//                       } else if (e.key === "Backspace" && !ccInput && ccEmails.length > 0) {
//                         removeCcEmail(ccEmails[ccEmails.length - 1]);
//                       }
//                     }}
//                     onBlur={() => {
//                       if (ccInput.includes("@")) addCcEmail(ccInput);
//                     }}
//                     placeholder={ccEmails.length === 0 ? "cc@client.com — press Enter to add" : "Add another…"}
//                     disabled={isBusy}
//                     className="h-7 min-w-[140px] flex-1 border-none bg-transparent text-[13px] outline-none placeholder:text-muted-foreground/60"
//                   />
//                   {ccInput.trim() && (
//                     <button
//                       type="button"
//                       disabled={isBusy}
//                       onClick={() => addCcEmail(ccInput)}
//                       title="Add CC address"
//                       aria-label="Add CC address"
//                       className="rounded-full p-1 text-primary transition-colors hover:bg-primary/10"
//                     >
//                       <Plus className="h-3.5 w-3.5" />
//                     </button>
//                   )}
//                 </div>

//                 <Popover open={isCcPickerOpen} onOpenChange={setIsCcPickerOpen}>
//                   <PopoverTrigger asChild>
//                     <button
//                       type="button"
//                       disabled={isBusy}
//                       title="Pick CC addresses"
//                       className="mt-1.5 flex h-8 shrink-0 items-center gap-1 rounded-full border rfi-bd bg-background px-2.5 text-[11px] font-semibold text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground disabled:pointer-events-none disabled:opacity-50"
//                     >
//                       <Star className="h-3 w-3 text-amber-500" />
//                       Pick
//                       <ChevronDown className="h-3 w-3" />
//                     </button>
//                   </PopoverTrigger>
//                   <PopoverContent align="end" className="w-72 p-2">
//                     <div className="mb-2 flex gap-1 rounded-md bg-muted/50 p-0.5">
//                       {(["favorites", "employees"] as const).map((tab) => (
//                         <button
//                           key={tab}
//                           type="button"
//                           onClick={() => setCcPickerTab(tab)}
//                           className={[
//                             "flex-1 rounded-sm px-2 py-1.5 text-xs font-semibold capitalize transition-colors",
//                             ccPickerTab === tab
//                               ? "bg-background text-foreground shadow-sm"
//                               : "text-muted-foreground hover:text-foreground",
//                           ].join(" ")}
//                         >
//                           {tab}
//                         </button>
//                       ))}
//                     </div>

//                     {ccPickerTab === "employees" ? (
//                       (() => {
//                         const employeesWithEmail = employees.filter(
//                           (emp): emp is EmployeeOption & { email: string } => !!emp.email
//                         );
//                         if (employeesWithEmail.length === 0) {
//                           return <p className="px-2 py-2.5 text-xs text-muted-foreground">No employees found.</p>;
//                         }
//                         return (
//                           <ul className="rfi-scroll max-h-56 space-y-0.5 overflow-y-auto">
//                             {employeesWithEmail.map((emp) => {
//                               const checked = ccEmails.some((c) => c.toLowerCase() === emp.email.toLowerCase());
//                               return (
//                                 <li key={emp.id}>
//                                   <label className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 text-xs font-medium text-foreground transition-colors hover:bg-accent/60">
//                                     <Checkbox
//                                       checked={checked}
//                                       onCheckedChange={() => toggleCcFavorite(emp.email)}
//                                       className="h-4 w-4"
//                                     />
//                                     <span className="flex min-w-0 flex-col">
//                                       <span className="truncate">{formatDisplayName(emp.username)}</span>
//                                       <span className="truncate text-[11px] font-normal text-muted-foreground">
//                                         {emp.email}
//                                       </span>
//                                     </span>
//                                   </label>
//                                 </li>
//                               );
//                             })}
//                           </ul>
//                         );
//                       })()
//                     ) : favoriteCcContacts.length === 0 ? (
//                       <p className="px-2 py-2.5 text-xs text-muted-foreground">
//                         No favorites yet — star an employee's CC address in RFI Settings.
//                       </p>
//                     ) : (
//                       <ul className="rfi-scroll max-h-56 space-y-0.5 overflow-y-auto">
//                         {favoriteCcContacts.map((c) => {
//                           const checked = ccEmails.some((e) => e.toLowerCase() === c.email.toLowerCase());
//                           return (
//                             <li key={c.email}>
//                               <label className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 text-xs font-medium text-foreground transition-colors hover:bg-accent/60">
//                                 <Checkbox
//                                   checked={checked}
//                                   onCheckedChange={() => toggleCcFavorite(c.email)}
//                                   className="h-4 w-4"
//                                 />
//                                 {c.favorite && <Star className="h-3.5 w-3.5 shrink-0 fill-amber-400 text-amber-500" />}
//                                 <span className="truncate">{c.email}</span>
//                               </label>
//                             </li>
//                           );
//                         })}
//                       </ul>
//                     )}
//                   </PopoverContent>
//                 </Popover>
//               </div>
//             </section>

//             {/* Discipline · Team Scope · Priority */}
//             <section className="flex flex-wrap items-center gap-2.5" aria-label="RFI classification">
//               <GlassSelect
//                 label="Discipline"
//                 value={discipline}
//                 options={disciplineOptions}
//                 onChange={setDiscipline}
//                 disabled={isBusy}
//               />
//               <GlassSelect
//                 label="Team Scope"
//                 value={teamType}
//                 options={teamOptions}
//                 onChange={setTeamType}
//                 disabled={isBusy}
//               />
//               <GlassSelect
//                 label="Priority"
//                 value={priority}
//                 options={priorityOptions}
//                 onChange={setPriority}
//                 disabled={isBusy}
//               />
//             </section>

//             {/* Subject */}
//             <section className="space-y-2">
//               <div className="flex items-center justify-between">
//                 <Label htmlFor="rfi-subject" className={LABEL_CLASS}>
//                   Subject line <span className="text-destructive">*</span>
//                 </Label>
//                 <span className="font-mono text-[10.5px] text-muted-foreground/70">{subject.length}/200</span>
//               </div>
//               <Input
//                 id="rfi-subject"
//                 value={subject}
//                 onChange={(e) => setSubject(e.target.value)}
//                 placeholder="e.g. Structural Beam Connection Drawing Specs"
//                 maxLength={200}
//                 disabled={isBusy}
//                 className={FIELD_CLASS}
//               />
//             </section>
//           </div>

//           {/* ───────────── RIGHT COLUMN ───────────── */}
//           <div className="flex flex-col gap-3">
//             {/* Email body + Attachment, side by side on the SAME LINE. */}
//             <div
//               ref={composeRowRef}
//               className="rfi-compose-row"
//               style={{ "--rfi-attach-width": `${attachWidth}px` } as CSSProperties}
//             >
//               {/* Email Body — compact, fixed-height box that scrolls internally */}
//               <section className="rfi-compose-body">
//                 <div className="flex flex-nowrap items-center justify-between gap-2">
//                   <Label className={`${LABEL_CLASS} flex min-w-0 items-center gap-1.5 whitespace-nowrap`}>
//                     <span className="truncate">Email body</span>
//                     {isBodyPreviewLoading && <Loader2 className="h-3 w-3 animate-spin text-muted-foreground/60" />}
//                     {isBodyCustomized && !isEditingBody && (
//                       <span className="rounded-full bg-primary/10 px-2 py-px text-[10px] font-semibold text-primary">
//                         Edited
//                       </span>
//                     )}
//                   </Label>

//                   {!isEditingBody ? (
//                     <div className="flex shrink-0 items-center gap-1">
//                       {isBodyCustomized && (
//                         <button type="button" disabled={isBusy} onClick={resetBodyToDefault} className={GHOST_BTN_CLASS} title="Reset">
//                           <RotateCcw className="h-3 w-3" />
//                           <span className="rfi-btn-text">Reset</span>
//                         </button>
//                       )}
//                       <button type="button" disabled={isBusy} onClick={startEditingBody} className={OUTLINE_BTN_CLASS} title="Edit">
//                         <Pencil className="h-3 w-3" />
//                         <span className="rfi-btn-text">Edit</span>
//                       </button>
//                     </div>
//                   ) : (
//                     <div className="flex shrink-0 items-center gap-1">
//                       <button type="button" onClick={cancelBodyEdit} className={GHOST_BTN_CLASS} title="Cancel">
//                         <X className="h-3 w-3" />
//                         <span className="rfi-btn-text">Cancel</span>
//                       </button>
//                       <button
//                         type="button"
//                         onClick={saveBodyEdit}
//                         title="Save"
//                         className="flex shrink-0 items-center gap-1 whitespace-nowrap rounded-md bg-primary px-2.5 py-1 text-[11px] [&>svg]:shrink-0 font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
//                       >
//                         <Check className="h-3 w-3" />
//                         <span className="rfi-btn-text">Save</span>
//                       </button>
//                     </div>
//                   )}
//                 </div>

//                 {/* Compact box — matches attachment height, scrolls internally */}
//                 <div className="rfi-body-box">
//                   {!isEditingBody ? (
//                     <div
//                       onClick={() => !isBusy && startEditingBody()}
//                       className="rfi-scroll absolute inset-0 cursor-text overflow-y-auto whitespace-pre-wrap rounded-xl border rfi-bd bg-background/60 px-3.5 py-2.5 text-[13px] leading-relaxed text-foreground/80 transition-colors hover:border-primary/40 hover:bg-accent/20"
//                     >
//                       {emailBody || (isBodyPreviewLoading ? "Loading default email body…" : "—")}
//                     </div>
//                   ) : (
//                     <Textarea
//                       autoFocus
//                       value={emailBodyDraft}
//                       onChange={(e) => setEmailBodyDraft(e.target.value)}
//                       disabled={isBusy}
//                       placeholder="Email body sent along with the attachment…"
//                       className="rfi-scroll absolute inset-0 h-full w-full resize-none rounded-xl border-primary/40 bg-background px-3.5 py-2.5 text-[13px] leading-relaxed focus-visible:ring-1 focus-visible:ring-primary/50"
//                     />
//                   )}
//                 </div>
//               </section>

//               {/* Resize handle — visible only when side-by-side */}
//               <div
//                 role="separator"
//                 aria-orientation="vertical"
//                 aria-label="Resize attachment panel"
//                 onMouseDown={(e) => {
//                   e.preventDefault();
//                   setIsResizing(true);
//                 }}
//                 className="rfi-resize-handle hidden sm:block"
//                 data-resizing={isResizing ? "true" : "false"}
//               />

//               {/* Attachment — compact, adjustable side panel */}
//               <section className="rfi-attach-panel">
//                 <Label className={LABEL_CLASS}>
//                   Attachment (PDF) <span className="text-destructive">*</span>
//                 </Label>
//                 <input
//                   id="rfi-attachment"
//                   ref={fileInputRef}
//                   type="file"
//                   accept="application/pdf,.pdf"
//                   onChange={handleFileChange}
//                   disabled={isBusy}
//                   className="hidden"
//                 />
//                 {!file ? (
//                   <label
//                     htmlFor="rfi-attachment"
//                     onDragOver={(e) => {
//                       e.preventDefault();
//                       setIsDragging(true);
//                     }}
//                     onDragLeave={(e) => {
//                       if (!e.currentTarget.contains(e.relatedTarget as Node | null)) setIsDragging(false);
//                     }}
//                     onDrop={handleDrop}
//                     onMouseEnter={() => setIsUploadHovered(true)}
//                     onMouseLeave={() => setIsUploadHovered(false)}
//                     className={[
//                       "rfi-drop group relative flex h-[96px] cursor-pointer flex-col items-center justify-center gap-0.5 rounded-xl border border-dashed px-3 text-center",
//                       isBusy ? "pointer-events-none opacity-60" : "",
//                       isDragging
//                         ? "rfi-drag-active"
//                         : "rfi-bd bg-background/30 hover:border-primary/50 hover:bg-accent/20",
//                     ].join(" ")}
//                   >
//                     <AnimatedUploadIcon
//                       size="md"
//                       className="transition-transform duration-200 group-hover:-translate-y-0.5"
//                       triggerParentHover
//                       isParentHovered={isUploadHovered || isDragging}
//                     />
//                     <span className="text-xs font-medium text-foreground">
//                       <span className="font-semibold text-primary group-hover:underline">Click to upload</span> or drag
//                       a PDF here
//                     </span>
//                     <span className="text-[10.5px] text-muted-foreground/70">One file · PDF only</span>
//                   </label>
//                 ) : (
//                   <div className="animate-rfi-pop flex h-[96px] items-center justify-between rounded-xl border border-primary/40 bg-primary/10 px-3.5 shadow-sm">
//                     <div className="flex min-w-0 items-center gap-2.5">
//                       <FileCheck className="h-5 w-5 shrink-0 text-primary" />
//                       <div className="flex min-w-0 flex-col">
//                         <span className="truncate text-xs font-semibold text-foreground">{file.name}</span>
//                         <span className="text-[10.5px] text-muted-foreground">
//                           {(file.size / (1024 * 1024)).toFixed(2)} MB
//                         </span>
//                       </div>
//                     </div>
//                     <Button
//                       type="button"
//                       variant="ghost"
//                       size="icon"
//                       disabled={isBusy}
//                       onClick={clearFile}
//                       aria-label="Remove attachment"
//                       className="h-7 w-7 shrink-0 rounded-full text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
//                     >
//                       <X className="h-4 w-4" />
//                     </Button>
//                   </div>
//                 )}
//               </section>
//             </div>
//           </div>
//         </div>
//       </form>
//     </div>
//   );
// };
import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Textarea } from "@/components/ui/textarea";
import {
  Send,
  X,
  Check,
  FileCheck,
  CheckCircle2,
  AlertCircle,
  Pencil,
  RotateCcw,
  Loader2,
  Star,
  ChevronDown,
  Plus,
} from "lucide-react";
import { AnimatedUploadIcon } from "@/components/icons/AnimatedUploadIcon";
import { AnimatedChecklistIcon } from "@/components/icons/Animatedchecklisticon";
import { GlassSelect, type GlassSelectOption } from "@/components/GlassSelect";
import {
  DEFAULT_RFI_PRIORITY,
  RFI_DISCIPLINES,
  RFI_TEAM_TYPES,
  type RfiDiscipline,
  type RfiEmailContact,
  type RfiPriority,
  type RfiTeamType,
} from "@/types/rfi";
import {
  createRfi,
  getEmployees,
  getErrorMessage,
  getFavoriteRfiEmailContacts,
  previewRfiEmail,
  type EmployeeOption,
} from "@/lib/rfiApi";
import { useAuth } from "@/context/AuthContext";
import {
  getDisciplineTheme,
  getDisciplineIcon,
  getTeamTypeTheme,
  getTeamTypeIcon,
  getPriorityTheme,
  PRIORITY_DESCRIPTIONS,
  PRIORITY_LABELS,
  RfiCircleIcon,
} from "@/lib/Rfivisuals";

// ─────────────────────────────────────────────────────────────────────
// Types & Constants
// ─────────────────────────────────────────────────────────────────────

type SendState = "idle" | "sending" | "success" | "error";

interface Props {
  projectName: string | null;
  initialRecipientEmail: string;
  initialCcEmails?: string;
  onSent: () => void;
}

const DEFAULT_DISCIPLINE: RfiDiscipline =
  (RFI_DISCIPLINES.find((d) => d.toLowerCase().includes("structural")) ??
    RFI_DISCIPLINES[0]) as RfiDiscipline;

const CONFETTI_COLORS = ["#10b981", "#34d399", "#38bdf8", "#a78bfa"];
const CONFETTI_PIECES = Array.from({ length: 10 }, (_, i) => ({
  angle: (360 / 10) * i,
  color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
  delay: (i % 3) * 40,
  distance: 30 + (i % 4) * 6,
}));

const LABEL_CLASS = "text-[11px] font-semibold tracking-wide text-muted-foreground";
const FIELD_CLASS =
  "h-10 rounded-xl rfi-bd bg-background/60 text-[13px] transition-colors focus-visible:bg-background";
const BARE_INPUT_CLASS =
  "h-9 flex-1 border-0 bg-transparent px-0 text-[13px] shadow-none focus-visible:ring-0 focus-visible:ring-offset-0";
const GHOST_BTN_CLASS =
  "flex shrink-0 items-center gap-1 whitespace-nowrap rounded-md px-2 py-1 text-[11px] font-semibold text-muted-foreground [&>svg]:shrink-0 transition-colors hover:bg-accent/60 hover:text-foreground disabled:pointer-events-none disabled:opacity-50";
const OUTLINE_BTN_CLASS =
  "flex shrink-0 items-center gap-1 whitespace-nowrap rounded-md border rfi-bd bg-background/60 px-2.5 py-1 text-[11px] font-semibold text-muted-foreground transition-colors hover:border-primary/40 hover:bg-accent/50 hover:text-foreground disabled:pointer-events-none disabled:opacity-50 [&>svg]:shrink-0";

const SHAKE_KEYFRAMES: Keyframe[] = [
  { transform: "translateX(0)" },
  { transform: "translateX(-6px)" },
  { transform: "translateX(5px)" },
  { transform: "translateX(-4px)" },
  { transform: "translateX(2px)" },
  { transform: "translateX(0)" },
];

const RFI_STYLES = `
  /* ── Visible borders + polish ── */
  .rfi-root { --rfi-border: hsl(var(--foreground) / 0.28); --rfi-border-hover: hsl(var(--primary) / 0.7); }
  .dark .rfi-root { --rfi-border: hsl(var(--foreground) / 0.38); }
  .rfi-bd { border-color: var(--rfi-border); }
  .rfi-bd:hover { border-color: var(--rfi-border-hover); }

  .rfi-form-card {
    border-width: 1.5px;
    border-color: hsl(var(--primary) / 0.45);
    animation: rfi-form-in 300ms cubic-bezier(0.16, 1, 0.3, 1) both, rfi-card-glow 4s ease-in-out 400ms infinite;
  }
  .rfi-form-card:hover { border-color: hsl(var(--primary) / 0.45); }
  @keyframes rfi-card-glow {
    0%, 100% { box-shadow: 0 0 0 4px hsl(var(--primary) / 0.05), 0 18px 40px -18px hsl(var(--primary) / 0.30); }
    50%      { box-shadow: 0 0 0 5px hsl(var(--primary) / 0.10), 0 22px 46px -16px hsl(var(--primary) / 0.50); }
  }

  .rfi-panel, .rfi-header-to { border-width: 1.5px; }
  .rfi-panel { background: hsl(var(--background) / 0.85); transition: border-color 180ms ease, box-shadow 180ms ease, transform 180ms ease; }
  .rfi-panel:hover { transform: translateY(-1px); box-shadow: 0 6px 16px -10px hsl(var(--primary) / 0.45); }
  .rfi-header-to { border-color: hsl(var(--primary) / 0.5); background: hsl(var(--primary) / 0.08); }

  .rfi-root input, .rfi-root textarea { transition: border-color 180ms ease, box-shadow 180ms ease, background-color 180ms ease; }
  .rfi-root input:focus-visible, .rfi-root textarea:focus-visible {
    border-color: hsl(var(--primary)); box-shadow: 0 0 0 3px hsl(var(--primary) / 0.15);
  }
  .rfi-drop { border-width: 2px; border-color: hsl(var(--primary) / 0.45); background: hsl(var(--primary) / 0.04); }
  .rfi-drop:hover { border-color: hsl(var(--primary)); background: hsl(var(--primary) / 0.09); transform: translateY(-1px); }
  .rfi-drag-active { border-color: hsl(var(--primary)); box-shadow: 0 0 0 4px hsl(var(--primary) / 0.15); animation: rfi-drop-pulse 1s ease-in-out infinite; }
  @keyframes rfi-drop-pulse { 0%,100% { transform: scale(1); } 50% { transform: scale(1.015); } }

  @keyframes rfi-section-in {
    0%   { opacity: 0; transform: translateY(10px); }
    100% { opacity: 1; transform: translateY(0); }
  }
  .rfi-stagger > div > * { animation: rfi-section-in 420ms cubic-bezier(0.16, 1, 0.3, 1) both; }
  .rfi-stagger > div > *:nth-child(1) { animation-delay: 80ms; }
  .rfi-stagger > div > *:nth-child(2) { animation-delay: 150ms; }
  .rfi-stagger > div > *:nth-child(3) { animation-delay: 220ms; }
  .rfi-stagger > div > *:nth-child(4) { animation-delay: 290ms; }

  @media (prefers-reduced-motion: reduce) {
    .rfi-form-card, .rfi-stagger > div > *, .rfi-drag-active { animation: none !important; }
  }

  .rfi-root { container-type: inline-size; container-name: rfi; width: 100%; }
  .rfi-scroll { scrollbar-width: thin; scrollbar-color: hsl(var(--border)) transparent; }

  .rfi-cols {
    display: grid;
    grid-template-columns: minmax(0, 1fr);
    gap: 0.75rem 1.25rem;
    align-content: start;
  }
  @container rfi (min-width: 820px) {
    .rfi-cols { grid-template-columns: minmax(0, 8fr) minmax(0, 5fr); }
  }
  @container rfi (max-width: 640px) {
    .rfi-subtitle { display: none; }
  }

  @keyframes rfi-pop {
    0%   { transform: scale(0.8); opacity: 0; }
    100% { transform: scale(1); opacity: 1; }
  }
  .animate-rfi-pop { animation: rfi-pop 180ms cubic-bezier(0.34, 1.56, 0.64, 1) both; }

  @keyframes rfi-form-in {
    0%   { opacity: 0; transform: translateY(8px); }
    100% { opacity: 1; transform: translateY(0); }
  }
  .rfi-form-enter { animation: rfi-form-in 300ms cubic-bezier(0.16, 1, 0.3, 1) both; }

  @keyframes rfi-line-in {
    0%   { transform: scaleX(0); }
    100% { transform: scaleX(1); }
  }
  .rfi-header-bar {
    height: 2px;
    transform-origin: left;
    background: linear-gradient(90deg, hsl(var(--primary)), hsl(var(--primary) / 0.05));
    animation: rfi-line-in 600ms cubic-bezier(0.16, 1, 0.3, 1) both;
  }

  .rfi-drop { transition: border-color 180ms ease, background-color 180ms ease; }
  .rfi-drag-active {
    border-color: hsl(var(--primary));
    background: hsl(var(--primary) / 0.08);
  }

  .rfi-panel { transition: border-color 180ms ease, box-shadow 180ms ease; }
  .rfi-panel:focus-within {
    border-color: hsl(var(--primary) / 0.45);
    box-shadow: 0 0 0 3px hsl(var(--primary) / 0.08);
  }

  /* ── Header "To" field — inline with the title ── */
  .rfi-header-to {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    flex: 1 1 auto;
    min-width: 0;
    height: 34px;
    padding: 0 0.5rem 0 0.75rem;
    border-radius: 10px;
    background: hsl(var(--primary) / 0.06);
    border: 1px solid hsl(var(--primary) / 0.18);
    transition: border-color 150ms ease, background-color 150ms ease, box-shadow 150ms ease;
  }
  .rfi-header-to:focus-within {
    border-color: hsl(var(--primary) / 0.45);
    background: hsl(var(--primary) / 0.08);
    box-shadow: 0 0 0 3px hsl(var(--primary) / 0.08);
  }
  .rfi-header-to-label {
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    color: hsl(var(--primary));
    opacity: 0.75;
    flex-shrink: 0;
  }
  .rfi-header-to-input {
    flex: 1 1 auto;
    min-width: 0;
    height: 100%;
    border: 0;
    background: transparent;
    font-size: 12.5px;
    font-weight: 600;
    color: hsl(var(--foreground));
    outline: none;
  }
  .rfi-header-to-input::placeholder {
    color: hsl(var(--muted-foreground) / 0.7);
    font-weight: 500;
  }
  .rfi-header-to-input:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
  .rfi-header-to-star {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    height: 22px;
    width: 22px;
    border-radius: 9999px;
    background: transparent;
    transition: background-color 150ms ease;
  }
  .rfi-header-to-star:hover:not(:disabled) {
    background: hsl(var(--primary) / 0.12);
  }
  .rfi-header-to-star:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  /* ── Resizable divider between body and attachment panel ── */
  .rfi-resize-handle {
    width: 6px;
    cursor: col-resize;
    background: transparent;
    position: relative;
    flex-shrink: 0;
    transition: background-color 150ms ease;
  }
  .rfi-resize-handle::before {
    content: "";
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 2px;
    height: 32px;
    border-radius: 9999px;
    background: hsl(var(--border));
    transition: background-color 150ms ease, height 150ms ease;
  }
  .rfi-resize-handle:hover::before,
  .rfi-resize-handle[data-resizing="true"]::before {
    background: hsl(var(--primary));
    height: 48px;
  }

  /* ── Side-by-side body + attachment panel ── */
  .rfi-compose-row {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
    align-items: stretch;
    width: 100%;
  }
  @container rfi (min-width: 640px) {
    .rfi-compose-row {
      flex-direction: row;
      align-items: stretch;
      gap: 0;
    }
  }

  .rfi-compose-body {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    min-width: 0;
    flex: 1 1 auto;
    container-type: inline-size;
    container-name: rfibody;
  }

  /* Header buttons: when the body column gets narrow, show icon only
     (never wrap, never force the page to scroll). */
  @container rfibody (max-width: 250px) {
    .rfi-btn-text { display: none; }
  }

  .rfi-attach-panel {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    width: 100%;
    flex-shrink: 0;
  }
  @container rfi (min-width: 640px) {
    .rfi-attach-panel {
      width: var(--rfi-attach-width, 220px);
      min-width: 170px;
      max-width: 380px;
      padding-left: 0.75rem;
      justify-content: flex-start;
    }
  }

  /* Compact body box height — keeps body and attachment visually balanced */
  .rfi-body-box {
    position: relative;
    min-height: 96px;
    max-height: 160px;
  }

  /* ── Send button ── */
  .rfi-send {
    position: relative;
    isolation: isolate;
    overflow: hidden;
    background: linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--primary) / 0.82) 100%);
    transition: box-shadow 200ms ease, transform 150ms ease, filter 200ms ease;
  }
  .rfi-send:hover:not(:disabled) {
    filter: brightness(1.07);
    box-shadow: 0 8px 20px -6px hsl(var(--primary) / 0.55);
    transform: translateY(-1px);
  }
  .rfi-send:active:not(:disabled) { transform: scale(0.98); }
  .rfi-send-plane { transition: transform 200ms cubic-bezier(0.34, 1.56, 0.64, 1); }
  .rfi-send:hover:not(:disabled) .rfi-send-plane { transform: translate(3px, -1px) rotate(-10deg); }

  .rfi-send-overlay {
    position: absolute;
    inset: 0;
    border-radius: inherit;
    opacity: 0;
    transition: opacity 250ms ease;
    pointer-events: none;
  }
  .rfi-send-overlay-success { background: linear-gradient(135deg, #059669, #10b981 55%, #34d399); opacity: 1; }
  .rfi-send-overlay-error   { background: linear-gradient(135deg, #b91c1c, #ef4444 55%, #f87171); opacity: 1; }

  @keyframes rfi-launch-ring {
    0%   { transform: scale(0.7); opacity: 0.5; }
    100% { transform: scale(1.7); opacity: 0; }
  }
  .rfi-launch-ring {
    position: absolute;
    inset: 0;
    border-radius: inherit;
    border: 2px solid rgba(255, 255, 255, 0.7);
    animation: rfi-launch-ring 600ms ease-out forwards;
    pointer-events: none;
  }

  @keyframes rfi-plane-fly {
    0%   { transform: translateX(-4px) rotate(-8deg); opacity: 0; }
    20%  { opacity: 1; }
    80%  { opacity: 1; }
    100% { transform: translateX(22px) rotate(-8deg); opacity: 0; }
  }
  .rfi-launch-track { position: relative; display: inline-block; width: 26px; height: 16px; }
  .rfi-launch-plane {
    position: absolute;
    top: 0;
    left: 0;
    animation: rfi-plane-fly 1s cubic-bezier(0.45, 0, 0.55, 1) infinite;
  }

  @keyframes rfi-dot-bounce {
    0%, 80%, 100% { opacity: 0.25; }
    40%           { opacity: 1; }
  }
  .rfi-dot { display: inline-block; animation: rfi-dot-bounce 1.2s ease-in-out infinite; }
  .rfi-dot:nth-of-type(2) { animation-delay: 150ms; }
  .rfi-dot:nth-of-type(3) { animation-delay: 300ms; }

  @keyframes rfi-confetti {
    0%   { transform: translate(-50%, -50%) rotate(var(--angle)) translateY(0) scale(1); opacity: 1; }
    100% { transform: translate(-50%, -50%) rotate(var(--angle)) translateY(calc(-1 * var(--dist))) scale(0); opacity: 0; }
  }
  .rfi-confetti-dot {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 5px;
    height: 5px;
    border-radius: 9999px;
    background: var(--dot-color);
    animation: rfi-confetti 650ms ease-out forwards;
    animation-delay: var(--delay);
    pointer-events: none;
  }

  @media (prefers-reduced-motion: reduce) {
    .rfi-form-enter, .rfi-header-bar, .animate-rfi-pop, .rfi-launch-ring,
    .rfi-launch-plane, .rfi-dot, .rfi-confetti-dot { animation: none !important; }
    .rfi-send, .rfi-send-plane, .rfi-panel { transition: none !important; }
    .rfi-confetti-dot { display: none; }
  }
`;

// ─────────────────────────────────────────────────────────────────────
// Helper Functions
// ─────────────────────────────────────────────────────────────────────

function formatDisplayName(username: string): string {
  if (!username) return "";
  return username
    .replace(/([A-Z])/g, " $1")
    .replace(/_/g, " ")
    .trim()
    .split(" ")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(" ");
}

function parseEmailList(raw: string | undefined): string[] {
  return (raw ?? "")
    .split(/[,;]/)
    .map((e) => e.trim())
    .filter(Boolean);
}

// ─────────────────────────────────────────────────────────────────────
// Component
// ─────────────────────────────────────────────────────────────────────

export const RfiForm = ({ projectName, initialRecipientEmail, initialCcEmails, onSent }: Props) => {
  const { name: authName } = useAuth();

  // ── Form State ──────────────────────────────────────────────────────
  const [discipline, setDiscipline] = useState<RfiDiscipline>(DEFAULT_DISCIPLINE);
  const [teamType, setTeamType] = useState<RfiTeamType>("EXTERNAL");
  const [priority, setPriority] = useState<RfiPriority>(DEFAULT_RFI_PRIORITY);
  const [subject, setSubject] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [recipientEmail, setRecipientEmail] = useState(initialRecipientEmail);
  const [employees, setEmployees] = useState<EmployeeOption[]>([]);

  // ── Email Body State ────────────────────────────────────────────────
  const [emailBody, setEmailBody] = useState("");
  const [emailBodyDraft, setEmailBodyDraft] = useState("");
  const [isEditingBody, setIsEditingBody] = useState(false);
  const [isBodyCustomized, setIsBodyCustomized] = useState(false);
  const [isBodyPreviewLoading, setIsBodyPreviewLoading] = useState(false);

  // ── CC & Recipient Picker State ─────────────────────────────────────
  const [favoriteToContacts, setFavoriteToContacts] = useState<RfiEmailContact[]>([]);
  const [favoriteCcContacts, setFavoriteCcContacts] = useState<RfiEmailContact[]>([]);
  const [ccPickerTab, setCcPickerTab] = useState<"favorites" | "employees">("favorites");
  const [ccEmails, setCcEmails] = useState<string[]>(() => parseEmailList(initialCcEmails));
  const [ccInput, setCcInput] = useState("");
  const [isToPickerOpen, setIsToPickerOpen] = useState(false);
  const [isCcPickerOpen, setIsCcPickerOpen] = useState(false);

  // ── Send State & UI ─────────────────────────────────────────────────
  const [sendState, setSendState] = useState<SendState>("idle");
  const [launchKey, setLaunchKey] = useState(0);
  const [isHeaderHovered, setIsHeaderHovered] = useState(false);
  const [isUploadHovered, setIsUploadHovered] = useState(false);

  // ── Attachment panel resize state ───────────────────────────────────
  const [attachWidth, setAttachWidth] = useState(220);
  const [isResizing, setIsResizing] = useState(false);
  const composeRowRef = useRef<HTMLDivElement>(null);

  // ── Refs ────────────────────────────────────────────────────────────
  const fileInputRef = useRef<HTMLInputElement>(null);
  const fieldsRef = useRef<HTMLDivElement>(null);
  const successTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const bodyPreviewTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const bodyLoadedRef = useRef(false);
  const previewRequestRef = useRef(0);

  // ── Computed Values ─────────────────────────────────────────────────
  const currentEmployee = useMemo(() => {
    if (!authName || employees.length === 0) return null;
    const normalized = authName.trim().toLowerCase();
    return (
      employees.find((e) => e.username.trim().toLowerCase() === normalized) ??
      employees.find((e) => formatDisplayName(e.username).trim().toLowerCase() === normalized) ??
      employees.find((e) => normalized.includes(e.username.trim().toLowerCase())) ??
      null
    );
  }, [authName, employees]);

  const isBusy = sendState === "sending" || sendState === "success";

  const disciplineOptions = useMemo<GlassSelectOption<RfiDiscipline>[]>(
    () =>
      RFI_DISCIPLINES.map((d) => {
        const Icon = getDisciplineIcon(d);
        const theme = getDisciplineTheme(d);
        return {
          value: d as RfiDiscipline,
          label: d,
          accent: theme.accent,
          leading: <RfiCircleIcon icon={Icon} theme={theme} size={18} filled />,
        };
      }),
    []
  );

  const teamOptions = useMemo<GlassSelectOption<RfiTeamType>[]>(
    () =>
      RFI_TEAM_TYPES.map((type) => {
        const Icon = getTeamTypeIcon(type);
        const theme = getTeamTypeTheme(type);
        return {
          value: type,
          label: type === "INTERNAL" ? "Internal" : "External",
          accent: theme.accent,
          leading: <RfiCircleIcon icon={Icon} theme={theme} size={18} filled />,
        };
      }),
    []
  );

  const priorityOptions = useMemo<GlassSelectOption<RfiPriority>[]>(
    () =>
      (Object.keys(PRIORITY_LABELS) as RfiPriority[]).map((p) => {
        const theme = getPriorityTheme(p);
        return {
          value: p,
          label: PRIORITY_LABELS[p],
          accent: theme.accent,
          title: PRIORITY_DESCRIPTIONS[p],
          leading: (
            <span
              className="h-2.5 w-2.5 shrink-0 rounded-full"
              style={{ backgroundColor: theme.accent, boxShadow: `0 0 8px ${theme.accent}` }}
              aria-hidden
            />
          ),
        };
      }),
    []
  );

  // ── Effects ─────────────────────────────────────────────────────────

  useEffect(() => {
    getEmployees()
      .then(setEmployees)
      .catch((err) =>
        toast({
          title: "Failed to load sender list",
          description: getErrorMessage(err),
          variant: "destructive",
        })
      );
  }, []);

  useEffect(() => {
    getFavoriteRfiEmailContacts("TO")
      .then(setFavoriteToContacts)
      .catch((err) =>
        toast({
          title: "Failed to load favorite Send To addresses",
          description: getErrorMessage(err),
          variant: "destructive",
        })
      );
    getFavoriteRfiEmailContacts("CC")
      .then(setFavoriteCcContacts)
      .catch((err) =>
        toast({
          title: "Failed to load favorite CC addresses",
          description: getErrorMessage(err),
          variant: "destructive",
        })
      );
  }, []);

  useEffect(() => {
    setRecipientEmail(initialRecipientEmail);
  }, [initialRecipientEmail]);

  useEffect(() => {
    setCcEmails(parseEmailList(initialCcEmails));
  }, [initialCcEmails]);

  useEffect(() => {
    if (!projectName || isBodyCustomized || isEditingBody) return;

    if (bodyPreviewTimerRef.current) clearTimeout(bodyPreviewTimerRef.current);
    const delay = bodyLoadedRef.current ? 400 : 0;
    bodyPreviewTimerRef.current = setTimeout(() => {
      const requestId = ++previewRequestRef.current;
      setIsBodyPreviewLoading(true);
      previewRfiEmail(projectName, subject)
        .then((preview) => {
          if (requestId !== previewRequestRef.current) return;
          bodyLoadedRef.current = true;
          setEmailBody(preview.emailBody);
        })
        .catch((err) => {
          console.error("Failed to load default RFI email body:", getErrorMessage(err));
        })
        .finally(() => {
          if (requestId === previewRequestRef.current) setIsBodyPreviewLoading(false);
        });
    }, delay);

    return () => {
      if (bodyPreviewTimerRef.current) clearTimeout(bodyPreviewTimerRef.current);
    };
  }, [projectName, subject, isBodyCustomized, isEditingBody]);

  useEffect(() => {
    setIsUploadHovered(false);
  }, [file]);

  useEffect(() => {
    return () => {
      if (successTimerRef.current) clearTimeout(successTimerRef.current);
      if (bodyPreviewTimerRef.current) clearTimeout(bodyPreviewTimerRef.current);
    };
  }, []);

  // ── Attachment panel resize handlers ────────────────────────────────
  useEffect(() => {
    if (!isResizing) return;

    const handleMouseMove = (e: MouseEvent) => {
      if (!composeRowRef.current) return;
      const rect = composeRowRef.current.getBoundingClientRect();
      const newWidth = rect.right - e.clientX;
      setAttachWidth(Math.min(380, Math.max(170, newWidth)));
    };

    const handleMouseUp = () => {
      setIsResizing(false);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };

    document.body.style.cursor = "col-resize";
    document.body.style.userSelect = "none";
    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [isResizing]);

  // ── Event Handlers ──────────────────────────────────────────────────

  const startEditingBody = () => {
    setEmailBodyDraft(emailBody);
    setIsEditingBody(true);
  };

  const saveBodyEdit = () => {
    setEmailBody(emailBodyDraft);
    setIsBodyCustomized(true);
    setIsEditingBody(false);
  };

  const cancelBodyEdit = () => setIsEditingBody(false);

  const resetBodyToDefault = () => {
    setIsBodyCustomized(false);
    setIsEditingBody(false);
    if (!projectName) return;
    const requestId = ++previewRequestRef.current;
    setIsBodyPreviewLoading(true);
    previewRfiEmail(projectName, subject)
      .then((preview) => {
        if (requestId === previewRequestRef.current) setEmailBody(preview.emailBody);
      })
      .catch(() => undefined)
      .finally(() => {
        if (requestId === previewRequestRef.current) setIsBodyPreviewLoading(false);
      });
  };

  const addCcEmail = (raw: string) => {
    const trimmed = raw.trim();
    if (!trimmed) return;
    setCcEmails((prev) => (prev.some((c) => c.toLowerCase() === trimmed.toLowerCase()) ? prev : [...prev, trimmed]));
    setCcInput("");
  };

  const removeCcEmail = (email: string) =>
    setCcEmails((prev) => prev.filter((c) => c.toLowerCase() !== email.toLowerCase()));

  const toggleCcFavorite = (email: string) =>
    setCcEmails((prev) =>
      prev.some((c) => c.toLowerCase() === email.toLowerCase())
        ? prev.filter((c) => c.toLowerCase() !== email.toLowerCase())
        : [...prev, email]
    );

  const handleCcPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const text = e.clipboardData.getData("text");
    if (!/[,;\s]/.test(text.trim())) return;
    e.preventDefault();
    text
      .split(/[,;\s]+/)
      .map((t) => t.trim())
      .filter(Boolean)
      .forEach(addCcEmail);
  };

  const triggerShake = () => {
    if (typeof window === "undefined") return;
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;
    fieldsRef.current?.animate(SHAKE_KEYFRAMES, { duration: 380, easing: "ease-out" });
  };

  const failValidation = (title: string) => {
    triggerShake();
    toast({ title, variant: "destructive" });
  };

  const acceptFile = (selected: File | null) => {
    if (!selected) return setFile(null);
    const isPdf = selected.type === "application/pdf" || selected.name.toLowerCase().endsWith(".pdf");
    if (!isPdf) {
      toast({
        title: "Only PDF files are allowed",
        description: `"${selected.name}" isn't a PDF.`,
        variant: "destructive",
      });
      return;
    }
    setFile(selected);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) =>
    acceptFile(e.target.files?.[0] ?? null);

  const handleDrop = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    setIsDragging(false);
    acceptFile(e.dataTransfer.files?.[0] ?? null);
  };

  const clearFile = () => {
    setFile(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const resetForm = () => {
    setDiscipline(DEFAULT_DISCIPLINE);
    setTeamType("EXTERNAL");
    setPriority(DEFAULT_RFI_PRIORITY);
    setSubject("");
    setFile(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
    setEmailBody("");
    setEmailBodyDraft("");
    setIsEditingBody(false);
    setIsBodyCustomized(false);
    setCcEmails([]);
    setCcInput("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (sendState === "sending" || sendState === "success") return;
    if (!projectName) return failValidation("Select a project first");
    if (!discipline) return failValidation("Discipline is required");
    if (!subject.trim()) return failValidation("Subject is required");
    if (!file) return failValidation("A PDF attachment is required");
    if (!recipientEmail.trim()) return failValidation("Recipient email is required");
    if (!currentEmployee || !currentEmployee.email) {
      return failValidation("Your account isn't linked to an employee email — contact an admin");
    }

    const senderEmail = currentEmployee.email;
    const senderName = currentEmployee.username;
    const finalEmailBody = isEditingBody ? emailBodyDraft : emailBody;

    const pendingCc = ccInput.trim();
    const ccEmailsToSend = Array.from(
      new Map(
        [...ccEmails, ...(pendingCc ? [pendingCc] : [])]
          .map((c) => c.trim())
          .filter(Boolean)
          .map((c) => [c.toLowerCase(), c] as const)
      ).values()
    );

    setLaunchKey((k) => k + 1);
    setSendState("sending");
    try {
      const created = await createRfi(projectName, {
        discipline,
        teamType,
        priority,
        subject: subject.trim(),
        emailBody: finalEmailBody.trim() ? finalEmailBody : undefined,
        attachment: file,
        senderEmail,
        senderName: senderName ? formatDisplayName(senderName) : undefined,
        recipientEmail: recipientEmail.trim(),
        ccEmails: ccEmailsToSend,
      });
      toast({
        title: `${created.rfiNumber} sent successfully!`,
        description: `Emailed to ${created.recipientEmail}`,
        className: "bg-emerald-600 text-white border-none shadow-xl",
      });
      setSendState("success");
      if (successTimerRef.current) clearTimeout(successTimerRef.current);
      successTimerRef.current = setTimeout(() => {
        resetForm();
        setSendState("idle");
        onSent();
      }, 1200);
    } catch (err) {
      triggerShake();
      setSendState("error");
      toast({
        title: "Failed to send RFI",
        description: getErrorMessage(err),
        variant: "destructive",
      });
      if (successTimerRef.current) clearTimeout(successTimerRef.current);
      successTimerRef.current = setTimeout(() => setSendState("idle"), 900);
    }
  };

  // ─────────────────────────────────────────────────────────────────────
  // Render
  // ─────────────────────────────────────────────────────────────────────

  return (
    <div className="rfi-root">
      <style>{RFI_STYLES}</style>

      <form
        onSubmit={handleSubmit}
        className="rfi-form-enter rfi-form-card relative flex w-full flex-col rounded-2xl border rfi-bd bg-gradient-to-b from-primary/[0.06] via-background/95 to-background/95 p-3 shadow-2xl shadow-black/10 backdrop-blur-xl sm:p-4"
      >
        {/* ───────────── Header ─────────────
            Left: title + inline "To" address input.
            Right: Submit button — always visible. */}
        <div className="flex shrink-0 items-center justify-between gap-3">
          <div
            className="flex min-w-0 flex-1 cursor-default items-center gap-3"
            onMouseEnter={() => setIsHeaderHovered(true)}
            onMouseLeave={() => setIsHeaderHovered(false)}
          >
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 ring-1 ring-primary/15">
              <AnimatedChecklistIcon
                size="md"
                className="text-primary"
                triggerParentHover
                isParentHovered={isHeaderHovered}
              />
            </span>

            <div className="flex min-w-0 flex-1 flex-col gap-1.5">
              <h2 className="text-base font-bold leading-tight tracking-tight text-foreground">New RFI</h2>

              {/* Inline "To" address input — takes the full row width, gives the
                  user plenty of space to type or paste an address. The star
                  button opens the favorites picker. */}
              <div className="rfi-header-to min-w-0 max-w-[520px]">
                <span className="rfi-header-to-label">
                  To<span className="text-destructive">*</span>
                </span>
                <input
                  id="rfi-recipient"
                  type="email"
                  value={recipientEmail}
                  onChange={(e) => setRecipientEmail(e.target.value)}
                  placeholder="reviewer@client.com — or pick a favorite"
                  disabled={isBusy}
                  className="rfi-header-to-input"
                  aria-label="Recipient email"
                />
                <Popover open={isToPickerOpen} onOpenChange={setIsToPickerOpen}>
                  <PopoverTrigger asChild>
                    <button
                      type="button"
                      disabled={isBusy}
                      title="Pick a Send To address"
                      aria-label="Pick a Send To address"
                      className="rfi-header-to-star"
                    >
                      <Star className="h-3.5 w-3.5 text-amber-500" />
                    </button>
                  </PopoverTrigger>
                  <PopoverContent align="end" className="w-72 p-2">
                    {favoriteToContacts.length === 0 ? (
                      <p className="px-2 py-2.5 text-xs text-muted-foreground">
                        No favorites yet — star a Send To address in RFI Settings, or just type a new one.
                      </p>
                    ) : (
                      <ul className="rfi-scroll max-h-56 space-y-0.5 overflow-y-auto">
                        {favoriteToContacts.map((c) => (
                          <li key={c.email}>
                            <button
                              type="button"
                              onClick={() => {
                                setRecipientEmail(c.email);
                                setIsToPickerOpen(false);
                              }}
                              className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-xs font-medium text-foreground transition-colors hover:bg-accent/60"
                            >
                              <Star className="h-3.5 w-3.5 shrink-0 fill-amber-400 text-amber-500" />
                              <span className="truncate">{c.email}</span>
                            </button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </div>

          <Button
            type="submit"
            disabled={isBusy}
            className="rfi-send h-10 min-w-[150px] shrink-0 rounded-xl px-5 text-sm font-bold tracking-wide text-white shadow-md disabled:opacity-100"
          >
            <span
              className={`rfi-send-overlay ${
                sendState === "success"
                  ? "rfi-send-overlay-success"
                  : sendState === "error"
                    ? "rfi-send-overlay-error"
                    : ""
              }`}
              aria-hidden
            />

            {sendState === "sending" && <span key={`launch-${launchKey}`} className="rfi-launch-ring" aria-hidden />}

            {sendState === "success" &&
              CONFETTI_PIECES.map((p, i) => (
                <span
                  key={i}
                  className="rfi-confetti-dot"
                  style={
                    {
                      "--angle": `${p.angle}deg`,
                      "--dist": `${p.distance}px`,
                      "--delay": `${p.delay}ms`,
                      "--dot-color": p.color,
                    } as CSSProperties
                  }
                />
              ))}

            <span className="relative z-10 inline-flex items-center justify-center gap-2 whitespace-nowrap">
              {sendState === "sending" && (
                <>
                  <span className="rfi-launch-track" aria-hidden>
                    <Send className="rfi-launch-plane h-4 w-4" />
                  </span>
                  <span>
                    Sending
                    <span className="rfi-dot">.</span>
                    <span className="rfi-dot">.</span>
                    <span className="rfi-dot">.</span>
                  </span>
                </>
              )}
              {sendState === "success" && (
                <>
                  <CheckCircle2 className="animate-rfi-pop h-4 w-4" />
                  <span>Sent!</span>
                </>
              )}
              {sendState === "error" && (
                <>
                  <AlertCircle className="animate-rfi-pop h-4 w-4" />
                  <span>Try again</span>
                </>
              )}
              {sendState === "idle" && (
                <>
                  <Send className="rfi-send-plane h-4 w-4" />
                  <span>Submit RFI</span>
                </>
              )}
            </span>
          </Button>
        </div>

        <div className="rfi-header-bar my-2 w-full shrink-0 rounded-full" />

        {/* ───────────── Fields ───────────── */}
        <div ref={fieldsRef} className="rfi-scroll rfi-cols rfi-stagger pb-1 pr-0.5">
          {/* ───────────── LEFT COLUMN ───────────── */}
          <div className="space-y-3">
            {/* CC only — the To field now lives in the header above. */}
            <section className="rfi-panel rounded-xl border rfi-bd bg-background/60">
              <div className="flex items-start gap-2 px-3">
                <Label htmlFor="rfi-cc" className={`${LABEL_CLASS} w-7 shrink-0 pt-3.5`}>
                  CC
                </Label>
                <div className="flex min-h-11 flex-1 flex-wrap items-center gap-1.5 py-1.5">
                  {ccEmails.map((email) => (
                    <Badge
                      key={email}
                      variant="secondary"
                      className="flex items-center gap-1 rounded-full py-0.5 pl-2.5 pr-1 text-xs font-medium"
                    >
                      <span className="max-w-[180px] truncate">{email}</span>
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => removeCcEmail(email)}
                        aria-label={`Remove ${email}`}
                        className="rounded-full p-0.5 text-muted-foreground/70 transition-colors hover:bg-destructive/10 hover:text-destructive disabled:pointer-events-none"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                  <input
                    id="rfi-cc"
                    type="email"
                    value={ccInput}
                    onChange={(e) => setCcInput(e.target.value)}
                    onPaste={handleCcPaste}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" || e.key === "," || e.key === ";") {
                        e.preventDefault();
                        addCcEmail(ccInput);
                      } else if (e.key === "Backspace" && !ccInput && ccEmails.length > 0) {
                        removeCcEmail(ccEmails[ccEmails.length - 1]);
                      }
                    }}
                    onBlur={() => {
                      if (ccInput.includes("@")) addCcEmail(ccInput);
                    }}
                    placeholder={ccEmails.length === 0 ? "cc@client.com — press Enter to add" : "Add another…"}
                    disabled={isBusy}
                    className="h-7 min-w-[140px] flex-1 border-none bg-transparent text-[13px] outline-none placeholder:text-muted-foreground/60"
                  />
                  {ccInput.trim() && (
                    <button
                      type="button"
                      disabled={isBusy}
                      onClick={() => addCcEmail(ccInput)}
                      title="Add CC address"
                      aria-label="Add CC address"
                      className="rounded-full p-1 text-primary transition-colors hover:bg-primary/10"
                    >
                      <Plus className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>

                <Popover open={isCcPickerOpen} onOpenChange={setIsCcPickerOpen}>
                  <PopoverTrigger asChild>
                    <button
                      type="button"
                      disabled={isBusy}
                      title="Pick CC addresses"
                      className="mt-1.5 flex h-8 shrink-0 items-center gap-1 rounded-full border rfi-bd bg-background px-2.5 text-[11px] font-semibold text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground disabled:pointer-events-none disabled:opacity-50"
                    >
                      <Star className="h-3 w-3 text-amber-500" />
                      Pick
                      <ChevronDown className="h-3 w-3" />
                    </button>
                  </PopoverTrigger>
                  <PopoverContent align="end" className="w-72 p-2">
                    <div className="mb-2 flex gap-1 rounded-md bg-muted/50 p-0.5">
                      {(["favorites", "employees"] as const).map((tab) => (
                        <button
                          key={tab}
                          type="button"
                          onClick={() => setCcPickerTab(tab)}
                          className={[
                            "flex-1 rounded-sm px-2 py-1.5 text-xs font-semibold capitalize transition-colors",
                            ccPickerTab === tab
                              ? "bg-background text-foreground shadow-sm"
                              : "text-muted-foreground hover:text-foreground",
                          ].join(" ")}
                        >
                          {tab}
                        </button>
                      ))}
                    </div>

                    {ccPickerTab === "employees" ? (
                      (() => {
                        const employeesWithEmail = employees.filter(
                          (emp): emp is EmployeeOption & { email: string } => !!emp.email
                        );
                        if (employeesWithEmail.length === 0) {
                          return <p className="px-2 py-2.5 text-xs text-muted-foreground">No employees found.</p>;
                        }
                        return (
                          <ul className="rfi-scroll max-h-56 space-y-0.5 overflow-y-auto">
                            {employeesWithEmail.map((emp) => {
                              const checked = ccEmails.some((c) => c.toLowerCase() === emp.email.toLowerCase());
                              return (
                                <li key={emp.id}>
                                  <label className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 text-xs font-medium text-foreground transition-colors hover:bg-accent/60">
                                    <Checkbox
                                      checked={checked}
                                      onCheckedChange={() => toggleCcFavorite(emp.email)}
                                      className="h-4 w-4"
                                    />
                                    <span className="flex min-w-0 flex-col">
                                      <span className="truncate">{formatDisplayName(emp.username)}</span>
                                      <span className="truncate text-[11px] font-normal text-muted-foreground">
                                        {emp.email}
                                      </span>
                                    </span>
                                  </label>
                                </li>
                              );
                            })}
                          </ul>
                        );
                      })()
                    ) : favoriteCcContacts.length === 0 ? (
                      <p className="px-2 py-2.5 text-xs text-muted-foreground">
                        No favorites yet — star an employee's CC address in RFI Settings.
                      </p>
                    ) : (
                      <ul className="rfi-scroll max-h-56 space-y-0.5 overflow-y-auto">
                        {favoriteCcContacts.map((c) => {
                          const checked = ccEmails.some((e) => e.toLowerCase() === c.email.toLowerCase());
                          return (
                            <li key={c.email}>
                              <label className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 text-xs font-medium text-foreground transition-colors hover:bg-accent/60">
                                <Checkbox
                                  checked={checked}
                                  onCheckedChange={() => toggleCcFavorite(c.email)}
                                  className="h-4 w-4"
                                />
                                {c.favorite && <Star className="h-3.5 w-3.5 shrink-0 fill-amber-400 text-amber-500" />}
                                <span className="truncate">{c.email}</span>
                              </label>
                            </li>
                          );
                        })}
                      </ul>
                    )}
                  </PopoverContent>
                </Popover>
              </div>
            </section>

            {/* Discipline · Team Scope · Priority */}
            <section className="flex flex-wrap items-center gap-2.5" aria-label="RFI classification">
              <GlassSelect
                label="Discipline"
                value={discipline}
                options={disciplineOptions}
                onChange={setDiscipline}
                disabled={isBusy}
              />
              <GlassSelect
                label="Team Scope"
                value={teamType}
                options={teamOptions}
                onChange={setTeamType}
                disabled={isBusy}
              />
              <GlassSelect
                label="Priority"
                value={priority}
                options={priorityOptions}
                onChange={setPriority}
                disabled={isBusy}
              />
            </section>

            {/* Subject */}
            <section className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="rfi-subject" className={LABEL_CLASS}>
                  Subject line <span className="text-destructive">*</span>
                </Label>
                <span className="font-mono text-[10.5px] text-muted-foreground/70">{subject.length}/200</span>
              </div>
              <Input
                id="rfi-subject"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="e.g. Structural Beam Connection Drawing Specs"
                maxLength={200}
                disabled={isBusy}
                className={FIELD_CLASS}
              />
            </section>
          </div>

          {/* ───────────── RIGHT COLUMN ───────────── */}
          <div className="flex flex-col gap-3">
            {/* Email body + Attachment, side by side on the SAME LINE. */}
            <div
              ref={composeRowRef}
              className="rfi-compose-row"
              style={{ "--rfi-attach-width": `${attachWidth}px` } as CSSProperties}
            >
              {/* Email Body — compact, fixed-height box that scrolls internally */}
              <section className="rfi-compose-body">
                <div className="flex flex-nowrap items-center justify-between gap-2">
                  <Label className={`${LABEL_CLASS} flex min-w-0 items-center gap-1.5 whitespace-nowrap`}>
                    <span className="truncate">Email body</span>
                    {isBodyPreviewLoading && <Loader2 className="h-3 w-3 animate-spin text-muted-foreground/60" />}
                    {isBodyCustomized && !isEditingBody && (
                      <span className="rounded-full bg-primary/10 px-2 py-px text-[10px] font-semibold text-primary">
                        Edited
                      </span>
                    )}
                  </Label>

                  {!isEditingBody ? (
                    <div className="flex shrink-0 items-center gap-1">
                      {isBodyCustomized && (
                        <button type="button" disabled={isBusy} onClick={resetBodyToDefault} className={GHOST_BTN_CLASS} title="Reset">
                          <RotateCcw className="h-3 w-3" />
                          <span className="rfi-btn-text">Reset</span>
                        </button>
                      )}
                      <button type="button" disabled={isBusy} onClick={startEditingBody} className={OUTLINE_BTN_CLASS} title="Edit">
                        <Pencil className="h-3 w-3" />
                        <span className="rfi-btn-text">Edit</span>
                      </button>
                    </div>
                  ) : (
                    <div className="flex shrink-0 items-center gap-1">
                      <button type="button" onClick={cancelBodyEdit} className={GHOST_BTN_CLASS} title="Cancel">
                        <X className="h-3 w-3" />
                        <span className="rfi-btn-text">Cancel</span>
                      </button>
                      <button
                        type="button"
                        onClick={saveBodyEdit}
                        title="Save"
                        className="flex shrink-0 items-center gap-1 whitespace-nowrap rounded-md bg-primary px-2.5 py-1 text-[11px] [&>svg]:shrink-0 font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
                      >
                        <Check className="h-3 w-3" />
                        <span className="rfi-btn-text">Save</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Compact box — matches attachment height, scrolls internally */}
                <div className="rfi-body-box">
                  {!isEditingBody ? (
                    <div
                      onClick={() => !isBusy && startEditingBody()}
                      className="rfi-scroll absolute inset-0 cursor-text overflow-y-auto whitespace-pre-wrap rounded-xl border rfi-bd bg-background/60 px-3.5 py-2.5 text-[13px] leading-relaxed text-foreground/80 transition-colors hover:border-primary/40 hover:bg-accent/20"
                    >
                      {emailBody || (isBodyPreviewLoading ? "Loading default email body…" : "—")}
                    </div>
                  ) : (
                    <Textarea
                      autoFocus
                      value={emailBodyDraft}
                      onChange={(e) => setEmailBodyDraft(e.target.value)}
                      disabled={isBusy}
                      placeholder="Email body sent along with the attachment…"
                      className="rfi-scroll absolute inset-0 h-full w-full resize-none rounded-xl border-primary/40 bg-background px-3.5 py-2.5 text-[13px] leading-relaxed focus-visible:ring-1 focus-visible:ring-primary/50"
                    />
                  )}
                </div>
              </section>

              {/* Resize handle — visible only when side-by-side */}
              <div
                role="separator"
                aria-orientation="vertical"
                aria-label="Resize attachment panel"
                onMouseDown={(e) => {
                  e.preventDefault();
                  setIsResizing(true);
                }}
                className="rfi-resize-handle hidden sm:block"
                data-resizing={isResizing ? "true" : "false"}
              />

              {/* Attachment — compact, adjustable side panel */}
              <section className="rfi-attach-panel">
                <Label className={LABEL_CLASS}>
                  Attachment (PDF) <span className="text-destructive">*</span>
                </Label>
                <input
                  id="rfi-attachment"
                  ref={fileInputRef}
                  type="file"
                  accept="application/pdf,.pdf"
                  onChange={handleFileChange}
                  disabled={isBusy}
                  className="hidden"
                />
                {!file ? (
                  <label
                    htmlFor="rfi-attachment"
                    onDragOver={(e) => {
                      e.preventDefault();
                      setIsDragging(true);
                    }}
                    onDragLeave={(e) => {
                      if (!e.currentTarget.contains(e.relatedTarget as Node | null)) setIsDragging(false);
                    }}
                    onDrop={handleDrop}
                    onMouseEnter={() => setIsUploadHovered(true)}
                    onMouseLeave={() => setIsUploadHovered(false)}
                    className={[
                      "rfi-drop group relative flex h-[96px] cursor-pointer flex-col items-center justify-center gap-0.5 rounded-xl border border-dashed px-3 text-center",
                      isBusy ? "pointer-events-none opacity-60" : "",
                      isDragging
                        ? "rfi-drag-active"
                        : "rfi-bd bg-background/30 hover:border-primary/50 hover:bg-accent/20",
                    ].join(" ")}
                  >
                    <AnimatedUploadIcon
                      size="md"
                      className="transition-transform duration-200 group-hover:-translate-y-0.5"
                      triggerParentHover
                      isParentHovered={isUploadHovered || isDragging}
                    />
                    <span className="text-xs font-medium text-foreground">
                      <span className="font-semibold text-primary group-hover:underline">Click to upload</span> or drag
                      a PDF here
                    </span>
                    <span className="text-[10.5px] text-muted-foreground/70">One file · PDF only</span>
                  </label>
                ) : (
                  <div className="animate-rfi-pop flex h-[96px] items-center justify-between rounded-xl border border-primary/40 bg-primary/10 px-3.5 shadow-sm">
                    <div className="flex min-w-0 items-center gap-2.5">
                      <FileCheck className="h-5 w-5 shrink-0 text-primary" />
                      <div className="flex min-w-0 flex-col">
                        <span className="truncate text-xs font-semibold text-foreground">{file.name}</span>
                        <span className="text-[10.5px] text-muted-foreground">
                          {(file.size / (1024 * 1024)).toFixed(2)} MB
                        </span>
                      </div>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      disabled={isBusy}
                      onClick={clearFile}
                      aria-label="Remove attachment"
                      className="h-7 w-7 shrink-0 rounded-full text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </section>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};